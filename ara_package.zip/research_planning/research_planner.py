import os
import sys
import json
import requests
from datetime import datetime

class ResearchPlanner:
    """
    Research Planning Engine for the Autonomous Research Agent
    
    Responsible for:
    - Research question formulation and refinement
    - Methodology selection
    - Task decomposition and planning
    """
    
    def __init__(self):
        self.research_topic = None
        self.research_questions = []
        self.methodology = None
        self.tasks = []
        self.timeline = {}
        
    def set_research_topic(self, topic):
        """Set the main research topic"""
        self.research_topic = topic
        print(f"Research topic set: {topic}")
        return True
        
    def formulate_research_questions(self, topic=None):
        """Generate specific research questions based on the topic"""
        if topic:
            self.set_research_topic(topic)
            
        if not self.research_topic:
            return False
            
        # In a full implementation, this would use more sophisticated NLP
        # For the prototype, we'll use a template-based approach
        
        # Generate primary research question
        primary_question = f"What are the key factors influencing {self.research_topic}?"
        
        # Generate secondary research questions
        secondary_questions = [
            f"How has {self.research_topic} evolved over time?",
            f"What are the current challenges in {self.research_topic}?",
            f"What future developments are expected in {self.research_topic}?"
        ]
        
        self.research_questions = [primary_question] + secondary_questions
        
        print(f"Generated {len(self.research_questions)} research questions:")
        for i, question in enumerate(self.research_questions):
            print(f"{i+1}. {question}")
            
        return self.research_questions
        
    def select_methodology(self):
        """Select appropriate research methodology based on the topic and questions"""
        # In a full implementation, this would analyze the research questions
        # and select methodologies based on their nature
        
        # For the prototype, we'll use a simplified approach
        methodologies = {
            "literature_review": {
                "name": "Literature Review",
                "description": "Systematic analysis of existing research and publications",
                "steps": [
                    "Define search criteria",
                    "Identify relevant sources",
                    "Extract and analyze information",
                    "Synthesize findings"
                ]
            },
            "qualitative_analysis": {
                "name": "Qualitative Analysis",
                "description": "Analysis of non-numerical data to understand concepts and experiences",
                "steps": [
                    "Identify data sources",
                    "Collect qualitative data",
                    "Code and categorize information",
                    "Identify patterns and themes"
                ]
            },
            "quantitative_analysis": {
                "name": "Quantitative Analysis",
                "description": "Statistical analysis of numerical data",
                "steps": [
                    "Define variables and metrics",
                    "Collect numerical data",
                    "Perform statistical analysis",
                    "Interpret results"
                ]
            }
        }
        
        # For the prototype, default to literature review
        self.methodology = methodologies["literature_review"]
        
        print(f"Selected methodology: {self.methodology['name']}")
        print(f"Description: {self.methodology['description']}")
        print("Steps:")
        for step in self.methodology['steps']:
            print(f"- {step}")
            
        return self.methodology
        
    def create_research_plan(self):
        """Create a comprehensive research plan with tasks and timeline"""
        if not self.research_questions:
            print("Error: Research questions must be formulated first")
            return False
            
        if not self.methodology:
            self.select_methodology()
            
        # Create tasks based on methodology steps
        self.tasks = []
        
        # Add initial tasks
        self.tasks.append({
            "id": 1,
            "name": "Research question refinement",
            "description": "Refine and finalize research questions",
            "status": "pending",
            "dependencies": []
        })
        
        # Add methodology-specific tasks
        task_id = 2
        for step in self.methodology['steps']:
            self.tasks.append({
                "id": task_id,
                "name": step,
                "description": f"Complete the '{step}' step of the {self.methodology['name']} methodology",
                "status": "pending",
                "dependencies": [task_id-1]  # Depend on previous task
            })
            task_id += 1
            
        # Add final tasks
        self.tasks.append({
            "id": task_id,
            "name": "Draft research report",
            "description": "Create initial draft of research findings",
            "status": "pending",
            "dependencies": [task_id-1]
        })
        
        task_id += 1
        self.tasks.append({
            "id": task_id,
            "name": "Finalize research report",
            "description": "Review, refine, and finalize research report",
            "status": "pending",
            "dependencies": [task_id-1]
        })
        
        # Create simple timeline (in a full implementation, this would be more sophisticated)
        today = datetime.now()
        days_per_task = 2  # Simplified timeline allocation
        
        self.timeline = {}
        current_day = 0
        
        for task in self.tasks:
            start_day = current_day
            end_day = current_day + days_per_task
            
            start_date = today.replace(day=today.day + start_day)
            end_date = today.replace(day=today.day + end_day)
            
            self.timeline[task["id"]] = {
                "start_date": start_date.strftime("%Y-%m-%d"),
                "end_date": end_date.strftime("%Y-%m-%d")
            }
            
            current_day = end_day
            
        print(f"Created research plan with {len(self.tasks)} tasks")
        return {
            "tasks": self.tasks,
            "timeline": self.timeline
        }
        
    def export_research_plan(self, output_file):
        """Export the research plan to a JSON file"""
        plan = {
            "research_topic": self.research_topic,
            "research_questions": self.research_questions,
            "methodology": self.methodology,
            "tasks": self.tasks,
            "timeline": {k: v for k, v in self.timeline.items()}  # Convert datetime objects to strings
        }
        
        with open(output_file, 'w') as f:
            json.dump(plan, f, indent=2)
            
        print(f"Research plan exported to {output_file}")
        return output_file
        
    def update_task_status(self, task_id, status):
        """Update the status of a specific task"""
        for task in self.tasks:
            if task["id"] == task_id:
                task["status"] = status
                print(f"Updated task {task_id} status to '{status}'")
                return True
                
        print(f"Error: Task {task_id} not found")
        return False


# Example usage
if __name__ == "__main__":
    planner = ResearchPlanner()
    
    # Test with a sample research topic
    if len(sys.argv) > 1:
        topic = sys.argv[1]
    else:
        topic = "artificial intelligence in healthcare"
        
    planner.formulate_research_questions(topic)
    planner.select_methodology()
    planner.create_research_plan()
    
    # Export the plan
    output_dir = os.path.dirname(os.path.abspath(__file__))
    planner.export_research_plan(os.path.join(output_dir, "research_plan.json"))

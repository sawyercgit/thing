import os
import sys
import json
import re
from datetime import datetime

class ContentCreator:
    """
    Content Creation System for the Autonomous Research Agent
    
    Responsible for:
    - Narrative structure planning
    - Argument construction
    - Data visualization planning
    - Citation and reference management
    - Style adaptation
    """
    
    def __init__(self):
        self.research_plan = None
        self.collected_information = None
        self.processed_knowledge = None
        self.generated_insights = None
        self.document_structure = {}
        self.citations = []
        self.references = []
        
    def load_research_data(self, plan_file=None, information_file=None, knowledge_file=None, insights_file=None):
        """Load all research data from JSON files"""
        data_loaded = False
        
        if plan_file:
            try:
                with open(plan_file, 'r') as f:
                    self.research_plan = json.load(f)
                print(f"Loaded research plan")
                data_loaded = True
            except Exception as e:
                print(f"Error loading research plan: {e}")
        
        if information_file:
            try:
                with open(information_file, 'r') as f:
                    self.collected_information = json.load(f)
                print(f"Loaded collected information")
                data_loaded = True
            except Exception as e:
                print(f"Error loading collected information: {e}")
        
        if knowledge_file:
            try:
                with open(knowledge_file, 'r') as f:
                    self.processed_knowledge = json.load(f)
                print(f"Loaded processed knowledge")
                data_loaded = True
            except Exception as e:
                print(f"Error loading processed knowledge: {e}")
        
        if insights_file:
            try:
                with open(insights_file, 'r') as f:
                    self.generated_insights = json.load(f)
                print(f"Loaded generated insights")
                data_loaded = True
            except Exception as e:
                print(f"Error loading generated insights: {e}")
        
        return data_loaded
    
    def plan_document_structure(self):
        """
        Plan the structure of the research document
        
        In a full implementation, this would be more sophisticated
        For the prototype, we'll use a standard research paper structure
        """
        # Extract research topic from plan if available
        research_topic = "Research Topic"
        if self.research_plan and "research_topic" in self.research_plan:
            research_topic = self.research_plan["research_topic"]
        
        # Create document structure
        self.document_structure = {
            "title": f"Research Report: {research_topic}",
            "date": datetime.now().strftime("%Y-%m-%d"),
            "sections": [
                {
                    "id": "abstract",
                    "title": "Abstract",
                    "content_type": "summary",
                    "word_count": 200,
                    "description": "Brief summary of the research, findings, and implications"
                },
                {
                    "id": "introduction",
                    "title": "1. Introduction",
                    "content_type": "narrative",
                    "word_count": 500,
                    "description": "Introduction to the research topic, background, and research questions"
                },
                {
                    "id": "methodology",
                    "title": "2. Methodology",
                    "content_type": "procedural",
                    "word_count": 400,
                    "description": "Description of the research methodology and approach"
                },
                {
                    "id": "literature_review",
                    "title": "3. Literature Review",
                    "content_type": "analytical",
                    "word_count": 800,
                    "description": "Analysis of existing research and publications"
                },
                {
                    "id": "findings",
                    "title": "4. Findings",
                    "content_type": "analytical",
                    "word_count": 1000,
                    "description": "Presentation of research findings and analysis"
                },
                {
                    "id": "discussion",
                    "title": "5. Discussion",
                    "content_type": "argumentative",
                    "word_count": 800,
                    "description": "Discussion of findings, implications, and connections to existing knowledge"
                },
                {
                    "id": "conclusion",
                    "title": "6. Conclusion",
                    "content_type": "summary",
                    "word_count": 300,
                    "description": "Summary of key findings and implications for future research"
                },
                {
                    "id": "references",
                    "title": "References",
                    "content_type": "bibliography",
                    "word_count": 0,
                    "description": "List of references cited in the document"
                }
            ]
        }
        
        print(f"Planned document structure with {len(self.document_structure['sections'])} sections")
        return self.document_structure
    
    def prepare_citations(self):
        """Prepare citations from collected information"""
        if not self.collected_information or "information" not in self.collected_information:
            print("No collected information available for citations")
            return []
            
        citations = []
        
        # Process each information item
        for i, item in enumerate(self.collected_information["information"]):
            source = item.get("source", {})
            
            citation = {
                "id": f"ref{i+1}",
                "title": item.get("title", f"Source {i+1}"),
                "author": source.get("author", "Unknown"),
                "year": source.get("year", 2025),
                "source": source.get("domain", "Unknown Source"),
                "url": source.get("url", ""),
                "access_date": datetime.now().strftime("%Y-%m-%d")
            }
            
            citations.append(citation)
            
        self.citations = citations
        print(f"Prepared {len(citations)} citations")
        return citations
    
    def generate_section_content(self, section):
        """
        Generate content for a specific section
        
        In a full implementation, this would use sophisticated NLG
        For the prototype, we'll use a template-based approach
        """
        section_id = section["id"]
        content = ""
        
        # Generate content based on section type
        if section_id == "abstract":
            content = self._generate_abstract()
        elif section_id == "introduction":
            content = self._generate_introduction()
        elif section_id == "methodology":
            content = self._generate_methodology()
        elif section_id == "literature_review":
            content = self._generate_literature_review()
        elif section_id == "findings":
            content = self._generate_findings()
        elif section_id == "discussion":
            content = self._generate_discussion()
        elif section_id == "conclusion":
            content = self._generate_conclusion()
        elif section_id == "references":
            content = self._generate_references()
        
        return content
    
    def _generate_abstract(self):
        """Generate abstract content"""
        # Extract research topic from plan if available
        research_topic = "the research topic"
        if self.research_plan and "research_topic" in self.research_plan:
            research_topic = self.research_plan["research_topic"]
            
        # Extract key insights if available
        key_findings = "various aspects of the topic"
        if self.generated_insights and "insights" in self.generated_insights:
            insights = self.generated_insights["insights"]
            if insights:
                insight_descriptions = [insight["description"] for insight in insights[:2]]
                key_findings = " and ".join(insight_descriptions)
        
        abstract = f"""This research paper explores {research_topic} through a comprehensive analysis of existing literature and information sources. The study employs a systematic methodology to gather, process, and analyze information from multiple sources, identifying key patterns and relationships. The findings reveal {key_findings}. The research contributes to the understanding of {research_topic} by providing an integrated perspective that combines established knowledge with novel insights. Implications for future research and practical applications are discussed, highlighting the importance of continued investigation in this area."""
        
        return abstract
    
    def _generate_introduction(self):
        """Generate introduction content"""
        # Extract research topic and questions from plan if available
        research_topic = "the research topic"
        research_questions = ["What are the key aspects of this topic?", 
                             "How has this topic evolved over time?", 
                             "What are the implications for future developments?"]
                             
        if self.research_plan:
            if "research_topic" in self.research_plan:
                research_topic = self.research_plan["research_topic"]
            if "research_questions" in self.research_plan:
                research_questions = self.research_plan["research_questions"]
        
        # Format research questions as a list
        questions_text = "\n".join([f"- {q}" for q in research_questions])
        
        introduction = f"""# 1. Introduction

## 1.1 Background

{research_topic.capitalize()} represents an important area of study with significant implications for both theory and practice. The field has evolved considerably over recent years, with growing interest from researchers, practitioners, and policymakers. As technologies advance and new methodologies emerge, understanding the complexities of {research_topic} becomes increasingly important for addressing current challenges and anticipating future developments.

This research aims to contribute to the existing body of knowledge by providing a comprehensive analysis of {research_topic}, synthesizing information from diverse sources, and generating novel insights that may guide future research and applications.

## 1.2 Research Questions

This study addresses the following research questions:

{questions_text}

## 1.3 Significance of the Research

This research is significant for several reasons. First, it provides an integrated perspective on {research_topic} by synthesizing information from multiple sources and identifying patterns that may not be apparent when examining individual studies. Second, it employs a systematic methodology that combines traditional research approaches with advanced analytical techniques, demonstrating the value of such integrated methods. Finally, the insights generated through this research have practical implications for stakeholders involved in {research_topic}, offering guidance for decision-making and future developments.

## 1.4 Structure of the Report

This report is organized into six main sections. Following this introduction, Section 2 describes the methodology employed in the research. Section 3 presents a review of the existing literature on {research_topic}. Section 4 details the findings of the research, while Section 5 discusses these findings in relation to the research questions and existing knowledge. Finally, Section 6 concludes the report with a summary of key insights and implications for future research."""
        
        return introduction
    
    def _generate_methodology(self):
        """Generate methodology content"""
        # Extract methodology from plan if available
        methodology_name = "Literature Review"
        methodology_steps = ["Define search criteria", 
                            "Identify relevant sources", 
                            "Extract and analyze information", 
                            "Synthesize findings"]
                            
        if self.research_plan and "methodology" in self.research_plan:
            methodology = self.research_plan["methodology"]
            methodology_name = methodology.get("name", methodology_name)
            methodology_steps = methodology.get("steps", methodology_steps)
        
        # Format methodology steps as a list
        steps_text = "\n".join([f"- {s}" for s in methodology_steps])
        
        methodology_content = f"""# 2. Methodology

This research employs a {methodology_name} approach to address the research questions. This methodology was selected for its appropriateness in synthesizing existing knowledge, identifying patterns and relationships, and generating insights based on comprehensive analysis.

## 2.1 Research Approach

The {methodology_name} approach involves the following key steps:

{steps_text}

This systematic approach ensures comprehensive coverage of the research topic while maintaining rigor in the analysis and synthesis of information.

## 2.2 Information Sources

Information for this research was gathered from multiple sources, including academic journals, research publications, industry reports, and expert analyses. Sources were selected based on relevance to the research topic, credibility, and recency, with preference given to peer-reviewed publications and recognized authorities in the field.

## 2.3 Analysis Process

The analysis process involved several stages:

1. **Information Acquisition**: Gathering relevant information from identified sources
2. **Knowledge Processing**: Analyzing and synthesizing the collected information
3. **Pattern Identification**: Identifying key patterns, relationships, and themes
4. **Insight Generation**: Developing novel insights based on the integrated analysis

This multi-stage process allowed for both depth and breadth in the analysis, ensuring that the research findings are robust and comprehensive.

## 2.4 Limitations

It is important to acknowledge the limitations of this research. The analysis is based on available information, which may not represent the complete body of knowledge on the topic. Additionally, the research employs simulated processes for demonstration purposes, which may not capture the full complexity of real-world research methodologies. Despite these limitations, the systematic approach and rigorous analysis provide valuable insights into the research topic."""
        
        return methodology_content
    
    def _generate_literature_review(self):
        """Generate literature review content"""
        # Use collected information if available
        if not self.collected_information or "information" not in self.collected_information:
            # Generate generic literature review if no information is available
            return self._generate_generic_literature_review()
            
        information_items = self.collected_information["information"]
        
        # Organize by topic if available
        organized_topics = self.collected_information.get("organized_topics", {})
        
        literature_review = "# 3. Literature Review\n\n"
        
        if organized_topics:
            # Generate literature review by topic
            for i, (topic, items) in enumerate(organized_topics.items()):
                literature_review += f"## 3.{i+1} {topic}\n\n"
                
                for item in items[:3]:  # Limit to 3 items per topic
                    source = item.get("source", {})
                    author = source.get("author", "Unknown")
                    year = source.get("year", 2025)
                    
                    content = item.get("content", {})
                    intro = content.get("introduction", "")
                    findings = content.get("findings", "")
                    
                    literature_review += f"{author} ({year}) explored {item['title'].lower()}. {intro} {findings}\n\n"
        else:
            # Generate literature review by individual sources
            literature_review += "## 3.1 Overview of Existing Research\n\n"
            
            for i, item in enumerate(information_items[:10]):  # Limit to 10 items
                source = item.get("source", {})
                author = source.get("author", "Unknown")
                year = source.get("year", 2025)
                
                content = item.get("content", {})
                intro = content.get("introduction", "")
                
                literature_review += f"{author} ({year}) investigated {item['title'].lower()}. {intro}\n\n"
        
        literature_review += "## 3.2 Synthesis of Existing Knowledge\n\n"
        literature_review += "The literature review reveals several key themes and patterns across the existing research. There appears to be consensus on certain fundamental aspects of the topic, while other areas show divergent perspectives and approaches. The methodologies employed in existing research vary considerably, from theoretical analyses to empirical investigations, each contributing unique insights to the overall understanding of the topic.\n\n"
        literature_review += "This synthesis of existing knowledge provides a foundation for the current research, highlighting both what is known and what remains to be explored. The gaps and contradictions identified in the literature inform the focus of this study and underscore the potential contribution of the current research to the field."
        
        return literature_review
    
    def _generate_generic_literature_review(self):
        """Generate a generic literature review when no specific information is available"""
        literature_review = """# 3. Literature Review

## 3.1 Historical Development of the Field

The research topic has evolved significantly over the past several decades. Early work in this area focused primarily on theoretical frameworks and conceptual models, establishing the foundational principles that continue to influence current research. As the field matured, researchers began to develop more sophisticated methodologies and analytical approaches, leading to a more nuanced understanding of the complex factors involved.

## 3.2 Current State of Knowledge

Current research in this field demonstrates a growing recognition of the interconnected nature of various factors and dimensions. Recent studies have employed increasingly sophisticated analytical techniques to identify patterns and relationships that were not apparent in earlier research. There is now a substantial body of evidence supporting certain key principles, while other areas remain subjects of ongoing debate and investigation.

## 3.3 Emerging Trends and Directions

Several emerging trends are evident in the recent literature. First, there is increasing interest in interdisciplinary approaches that integrate insights from multiple fields. Second, researchers are exploring new methodologies that leverage advanced technologies and analytical techniques. Third, there is growing attention to practical applications and real-world implications of theoretical findings.

## 3.4 Gaps and Limitations in Existing Research

Despite the significant progress in this field, several important gaps remain in the existing literature. There is limited research on certain aspects of the topic, particularly those requiring longitudinal studies or access to specialized data. Additionally, some methodological limitations persist across much of the existing research, potentially affecting the generalizability and applicability of findings. These gaps and limitations provide opportunities for future research to make meaningful contributions to the field."""
        
        return literature_review
    
    def _generate_findings(self):
        """Generate findings content"""
        findings = "# 4. Findings\n\n"
        
        # Use processed knowledge if available
        if self.processed_knowledge:
            # Extract entities and relationships
            entities = self.processed_knowledge.get("entities", [])
            relationships = self.processed_knowledge.get("relationships", [])
            contradictions = self.processed_knowledge.get("contradictions", [])
            knowledge_gaps = self.processed_knowledge.get("knowledge_gaps", [])
            
            findings += "## 4.1 Key Entities and Concepts\n\n"
            if entities:
                findings += "The research identified several key entities and concepts central to the research topic:\n\n"
                for i, entity in enumerate(entities[:10]):  # Limit to 10 entities
                    findings += f"- **{entity}**: A significant concept in the research domain\n"
            else:
                findings += "The analysis identified several key concepts that appear consistently across the information sources. These concepts form the core vocabulary of the research domain and provide a framework for understanding the relationships and patterns observed.\n\n"
                
            findings += "\n## 4.2 Relationships and Patterns\n\n"
            if relationships:
                findings += "The analysis revealed important relationships between key entities:\n\n"
                for i, rel in enumerate(relationships[:5]):  # Limit to 5 relationships
                    findings += f"- **{rel['source']}** {rel['type']} **{rel['target']}** (Confidence: {rel['confidence']})\n"
            else:
                findings += "The research identified several significant patterns and relationships within the analyzed information. These patterns suggest underlying structures and dynamics that help explain observed phenomena and predict potential developments.\n\n"
                
            findings += "\n## 4.3 Contradictions and Inconsistencies\n\n"
            if contradictions:
                findings += "The analysis identified the following contradictions in the information sources:\n\n"
                for i, contradiction in enumerate(contradictions):
                    findings += f"- **{contradiction['type']}**: {contradiction['description']}\n"
            else:
                findings += "The research revealed several areas where information sources present contradictory or inconsistent perspectives. These contradictions highlight areas of ongoing debate and uncertainty within the field, suggesting opportunities for further investigation and clarification.\n\n"
                
            findings += "\n## 4.4 Knowledge Gaps\n\n"
            if knowledge_gaps:
                findings += "The analysis identified the following gaps in the existing knowledge:\n\n"
                for i, gap in enumerate(knowledge_gaps):
                    findings += f"- **{gap['area']}**: {gap['description']}\n"
            else:
                findings += "The research identified several significant gaps in the existing knowledge base. These gaps represent areas where current information is limited, uncertain, or entirely absent, suggesting important directions for future research and investigation.\n"
        
        # Use generated insights if available
        if self.generated_insights:
            insights = self.generated_insights.get("insights", [])
            
            findings += "\n## 4.5 Generated Insights\n\n"
            if insights:
                for i, insight in enumerate(insights[:5]):  # Limit to 5 insights
                    findings += f"### 4.5.{i+1} {insight['title']}\n\n"
                    findings += f"{insight['description']}\n\n"
                    findings += f"**Details**: {insight['details']}\n\n"
                    findings += f"**Implications**: {insight['implications']}\n\n"
            else:
                findings += "The analysis generated several novel insights that contribute to the understanding of the research topic. These insights emerge from the integration of information across sources and the identification of patterns and relationships that may not be apparent when examining individual sources in isolation.\n\n"
        
        return findings
    
    def _generate_discussion(self):
        """Generate discussion content"""
        discussion = """# 5. Discussion

## 5.1 Interpretation of Findings

The findings of this research provide valuable insights into the complex nature of the research topic. The identified patterns and relationships suggest underlying structures and dynamics that help explain observed phenomena and predict potential developments. The contradictions and inconsistencies highlight areas of ongoing debate and uncertainty, while the knowledge gaps indicate opportunities for further investigation.

The generated insights represent a significant contribution to the understanding of the research topic, offering novel perspectives that emerge from the integration of information across sources. These insights suggest new ways of conceptualizing the research domain and point to potential applications and implications that warrant further exploration.

## 5.2 Relation to Existing Knowledge

The findings of this research both confirm and extend existing knowledge in several important ways. The identified patterns and relationships generally align with established theories and models, providing additional evidence for their validity. However, the research also reveals nuances and complexities that are not fully captured by existing frameworks, suggesting the need for refinement and expansion of current theoretical models.

The contradictions and inconsistencies identified in this research reflect ongoing debates in the field and highlight areas where existing knowledge remains contested or uncertain. By systematically analyzing these contradictions, this research contributes to a more nuanced understanding of the limitations and boundaries of current knowledge.

## 5.3 Theoretical and Practical Implications

### Theoretical Implications

The findings of this research have several important theoretical implications. First, they suggest the need for more integrated theoretical frameworks that can account for the complex relationships and patterns identified in the analysis. Second, they highlight the importance of considering multiple perspectives and approaches when studying complex phenomena. Third, they point to specific areas where existing theories may need revision or extension to accommodate new insights and observations.

### Practical Implications

From a practical perspective, the findings of this research offer valuable guidance for decision-makers and practitioners. The identified patterns and relationships provide a basis for anticipating developments and planning appropriate responses. The generated insights suggest new approaches and strategies that may be more effective than current practices. The knowledge gaps highlight areas where additional information and research are needed to inform effective action.

## 5.4 Limitations and Future Research

While this research provides valuable insights, it is important to acknowledge its limitations. The analysis is based on available information, which may not represent the complete body of knowledge on the topic. The methodological approach, while systematic and rigorous, necessarily involves certain assumptions and simplifications that may affect the results.

Future research could address these limitations in several ways. First, more comprehensive data collection could provide a broader foundation for analysis. Second, alternative methodological approaches could offer complementary perspectives and insights. Third, focused investigations of specific aspects of the research topic could provide deeper understanding of particular phenomena and relationships.

Specific areas for future research include:

1. In-depth exploration of the identified knowledge gaps
2. Empirical testing of the hypotheses and predictions generated in this research
3. Development of more sophisticated theoretical models based on the identified patterns and relationships
4. Investigation of practical applications and implementations of the generated insights"""
        
        return discussion
    
    def _generate_conclusion(self):
        """Generate conclusion content"""
        conclusion = """# 6. Conclusion

This research has provided a comprehensive analysis of the research topic, employing a systematic methodology to gather, process, and analyze information from multiple sources. The findings reveal important patterns, relationships, and insights that contribute to the understanding of the research domain.

## 6.1 Summary of Key Findings

The key findings of this research include:

1. Identification of central entities and concepts that form the core vocabulary of the research domain
2. Discovery of significant relationships and patterns that suggest underlying structures and dynamics
3. Recognition of contradictions and inconsistencies that highlight areas of ongoing debate
4. Identification of knowledge gaps that represent opportunities for further investigation
5. Generation of novel insights that emerge from the integration of information across sources

These findings collectively provide a rich and nuanced understanding of the research topic, offering both confirmation of existing knowledge and new perspectives that extend current understanding.

## 6.2 Contributions to the Field

This research makes several important contributions to the field. First, it demonstrates the value of a systematic, integrated approach to information gathering and analysis, showing how such methods can reveal patterns and insights that might not be apparent through more traditional approaches. Second, it provides a comprehensive synthesis of existing knowledge, offering a foundation for future research and practice. Third, it generates novel insights and perspectives that suggest new directions for investigation and application.

## 6.3 Final Reflections

The research topic represents a rich and complex domain with significant implications for both theory and practice. This research has attempted to capture some of that complexity while also identifying patterns and structures that make it more comprehensible and manageable. The findings suggest that while much is known about the research topic, there remain important opportunities for discovery and innovation.

As technologies and methodologies continue to evolve, the capacity to gather, process, and analyze information will only increase, offering even greater potential for understanding complex phenomena. This research represents a step in that direction, demonstrating the value of systematic, integrated approaches to knowledge generation and synthesis.

The journey of discovery in this field is ongoing, with each study building upon previous work and contributing to a growing body of knowledge. It is hoped that this research will serve as a useful contribution to that journey, providing insights and perspectives that inform future investigations and applications."""
        
        return conclusion
    
    def _generate_references(self):
        """Generate references content"""
        references = "# References\n\n"
        
        if self.citations:
            for citation in self.citations:
                author = citation.get("author", "Unknown")
                year = citation.get("year", 2025)
                title = citation.get("title", "Untitled")
                source = citation.get("source", "Unknown Source")
                url = citation.get("url", "")
                access_date = citation.get("access_date", datetime.now().strftime("%Y-%m-%d"))
                
                references += f"{author} ({year}). {title}. {source}. Retrieved from {url} on {access_date}.\n\n"
        else:
            references += "No references available."
            
        return references
    
    def create_research_report(self, output_file):
        """Create a complete research report"""
        # Plan document structure if not already done
        if not self.document_structure:
            self.plan_document_structure()
            
        # Prepare citations if not already done
        if not self.citations:
            self.prepare_citations()
            
        # Generate content for each section
        report_content = ""
        
        # Add title
        report_content += f"# {self.document_structure['title']}\n\n"
        report_content += f"Date: {self.document_structure['date']}\n\n"
        
        # Generate content for each section
        for section in self.document_structure['sections']:
            section_content = self.generate_section_content(section)
            report_content += section_content + "\n\n"
            
        # Write to file
        with open(output_file, 'w') as f:
            f.write(report_content)
            
        print(f"Research report created at {output_file}")
        return output_file


# Example usage
if __name__ == "__main__":
    creator = ContentCreator()
    
    # Set up paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(script_dir)
    
    plan_file = os.path.join(parent_dir, "research_planning", "research_plan.json")
    information_file = os.path.join(parent_dir, "information_acquisition", "collected_information.json")
    knowledge_file = os.path.join(parent_dir, "knowledge_processing", "processed_knowledge.json")
    insights_file = os.path.join(parent_dir, "insight_generation", "generated_insights.json")
    
    # Load data if files exist
    creator.load_research_data(
        plan_file=plan_file if os.path.exists(plan_file) else None,
        information_file=information_file if os.path.exists(information_file) else None,
        knowledge_file=knowledge_file if os.path.exists(knowledge_file) else None,
        insights_file=insights_file if os.path.exists(insights_file) else None
    )
    
    # Create research report
    output_file = os.path.join(script_dir, "research_report.md")
    creator.create_research_report(output_file)

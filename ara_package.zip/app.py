from flask import Flask, render_template, request, jsonify, session
import os
import json
import time
from datetime import datetime
import sys

# Add the parent directory to sys.path to import modules from ara_prototype
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import ARA components
from ara_prototype.research_planning.research_planner import ResearchPlanner
from ara_prototype.information_acquisition.information_acquisition import InformationAcquisition
from ara_prototype.knowledge_processing.knowledge_processor import KnowledgeProcessor
from ara_prototype.insight_generation.insight_generator import InsightGenerator
from ara_prototype.content_creation.content_creator import ContentCreator
from ara_prototype.collaboration_interface.collaboration_interface import CollaborationInterface

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Create data directory if it doesn't exist
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# Initialize ARA components
def get_ara_components():
    if 'ara_components' not in session:
        session['ara_components'] = {
            'research_planner': ResearchPlanner(),
            'information_acquisition': InformationAcquisition(),
            'knowledge_processor': KnowledgeProcessor(),
            'insight_generator': InsightGenerator(),
            'content_creator': ContentCreator(),
            'collaboration_interface': CollaborationInterface()
        }
    return session['ara_components']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/research/start', methods=['POST'])
def start_research():
    data = request.json
    topic = data.get('topic')
    
    if not topic:
        return jsonify({'error': 'Research topic is required'}), 400
    
    # Create a unique project ID
    project_id = f"project_{int(time.time())}"
    
    # Initialize research project
    components = get_ara_components()
    
    # Initialize collaboration interface
    collaboration_interface = components['collaboration_interface']
    collaboration_interface.initialize_project(topic)
    
    # Formulate research questions
    research_planner = components['research_planner']
    research_questions = research_planner.formulate_research_questions(topic)
    
    # Select methodology
    methodology = research_planner.select_methodology()
    
    # Create research plan
    research_plan = research_planner.create_research_plan()
    
    # Save research plan
    plan_file = os.path.join(DATA_DIR, f"{project_id}_research_plan.json")
    research_planner.export_research_plan(plan_file)
    
    # Update research progress
    collaboration_interface.update_research_progress("planning", 100, "Research planning completed")
    
    return jsonify({
        'project_id': project_id,
        'topic': topic,
        'research_questions': research_questions,
        'methodology': methodology,
        'research_plan': research_plan,
        'status': 'planning_completed'
    })

@app.route('/api/research/gather_information', methods=['POST'])
def gather_information():
    data = request.json
    project_id = data.get('project_id')
    topic = data.get('topic')
    
    if not project_id or not topic:
        return jsonify({'error': 'Project ID and topic are required'}), 400
    
    components = get_ara_components()
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "information_acquisition", 
        10, 
        "Starting information gathering"
    )
    
    # Perform search
    information_acquisition = components['information_acquisition']
    results = information_acquisition.search(topic)
    
    # Evaluate sources
    evaluated_results = information_acquisition.evaluate_sources()
    
    # Extract information
    extracted_info = information_acquisition.extract_information(evaluated_results)
    
    # Organize by topic
    organized_info = information_acquisition.organize_by_topic()
    
    # Save collected information
    info_file = os.path.join(DATA_DIR, f"{project_id}_collected_information.json")
    information_acquisition.export_collected_information(info_file)
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "information_acquisition", 
        100, 
        "Information gathering completed"
    )
    
    return jsonify({
        'project_id': project_id,
        'search_results': len(results),
        'extracted_information': len(extracted_info),
        'organized_topics': organized_info,
        'status': 'information_acquisition_completed'
    })

@app.route('/api/research/process_knowledge', methods=['POST'])
def process_knowledge():
    data = request.json
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID is required'}), 400
    
    components = get_ara_components()
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "knowledge_processing", 
        10, 
        "Starting knowledge processing"
    )
    
    # Load collected information
    info_file = os.path.join(DATA_DIR, f"{project_id}_collected_information.json")
    knowledge_processor = components['knowledge_processor']
    raw_information = knowledge_processor.load_information(info_file)
    
    # Process information
    knowledge_processor.process_information(raw_information)
    
    # Extract entities
    entities = knowledge_processor.extract_entities()
    
    # Identify relationships
    relationships = knowledge_processor.identify_relationships()
    
    # Build knowledge graph
    knowledge_graph = knowledge_processor.build_knowledge_graph()
    
    # Identify contradictions
    contradictions = knowledge_processor.identify_contradictions()
    
    # Identify knowledge gaps
    knowledge_gaps = knowledge_processor.identify_knowledge_gaps()
    
    # Save processed knowledge
    knowledge_file = os.path.join(DATA_DIR, f"{project_id}_processed_knowledge.json")
    knowledge_processor.export_processed_knowledge(knowledge_file)
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "knowledge_processing", 
        100, 
        "Knowledge processing completed"
    )
    
    return jsonify({
        'project_id': project_id,
        'entities': len(entities),
        'relationships': len(relationships),
        'contradictions': len(contradictions),
        'knowledge_gaps': len(knowledge_gaps),
        'status': 'knowledge_processing_completed'
    })

@app.route('/api/research/generate_insights', methods=['POST'])
def generate_insights():
    data = request.json
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID is required'}), 400
    
    components = get_ara_components()
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "insight_generation", 
        10, 
        "Starting insight generation"
    )
    
    # Load processed knowledge
    knowledge_file = os.path.join(DATA_DIR, f"{project_id}_processed_knowledge.json")
    insight_generator = components['insight_generator']
    insight_generator.load_processed_knowledge(knowledge_file)
    
    # Generate insights
    insights = insight_generator.generate_insights()
    
    # Save insights
    insights_file = os.path.join(DATA_DIR, f"{project_id}_generated_insights.json")
    insight_generator.export_insights(insights_file)
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "insight_generation", 
        100, 
        "Insight generation completed"
    )
    
    return jsonify({
        'project_id': project_id,
        'insights': len(insights),
        'status': 'insight_generation_completed'
    })

@app.route('/api/research/create_content', methods=['POST'])
def create_content():
    data = request.json
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID is required'}), 400
    
    components = get_ara_components()
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "content_creation", 
        10, 
        "Starting content creation"
    )
    
    # Set up file paths
    plan_file = os.path.join(DATA_DIR, f"{project_id}_research_plan.json")
    info_file = os.path.join(DATA_DIR, f"{project_id}_collected_information.json")
    knowledge_file = os.path.join(DATA_DIR, f"{project_id}_processed_knowledge.json")
    insights_file = os.path.join(DATA_DIR, f"{project_id}_generated_insights.json")
    
    # Load research data
    content_creator = components['content_creator']
    content_creator.load_research_data(
        plan_file=plan_file if os.path.exists(plan_file) else None,
        information_file=info_file if os.path.exists(info_file) else None,
        knowledge_file=knowledge_file if os.path.exists(knowledge_file) else None,
        insights_file=insights_file if os.path.exists(insights_file) else None
    )
    
    # Plan document structure
    document_structure = content_creator.plan_document_structure()
    
    # Prepare citations
    citations = content_creator.prepare_citations()
    
    # Create research report
    report_file = os.path.join(DATA_DIR, f"{project_id}_research_report.md")
    content_creator.create_research_report(report_file)
    
    # Update research progress
    components['collaboration_interface'].update_research_progress(
        "content_creation", 
        100, 
        "Content creation completed"
    )
    
    # Read the generated report
    with open(report_file, 'r') as f:
        report_content = f.read()
    
    return jsonify({
        'project_id': project_id,
        'document_structure': document_structure,
        'citations': len(citations),
        'report_content': report_content,
        'status': 'content_creation_completed'
    })

@app.route('/api/research/status', methods=['GET'])
def get_research_status():
    project_id = request.args.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID is required'}), 400
    
    components = get_ara_components()
    
    # Get research status
    status = components['collaboration_interface'].get_research_status()
    
    return jsonify(status)

@app.route('/api/research/feedback', methods=['POST'])
def add_feedback():
    data = request.json
    project_id = data.get('project_id')
    feedback_type = data.get('type')
    content = data.get('content')
    
    if not project_id or not feedback_type or not content:
        return jsonify({'error': 'Project ID, feedback type, and content are required'}), 400
    
    components = get_ara_components()
    
    # Add feedback
    components['collaboration_interface'].add_feedback(feedback_type, content)
    
    # Process feedback
    response = components['collaboration_interface'].process_feedback()
    
    return jsonify({
        'project_id': project_id,
        'feedback_processed': True,
        'response': response
    })

@app.route('/api/research/report', methods=['GET'])
def get_research_report():
    project_id = request.args.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID is required'}), 400
    
    report_file = os.path.join(DATA_DIR, f"{project_id}_research_report.md")
    
    if not os.path.exists(report_file):
        return jsonify({'error': 'Research report not found'}), 404
    
    with open(report_file, 'r') as f:
        report_content = f.read()
    
    return jsonify({
        'project_id': project_id,
        'report_content': report_content
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

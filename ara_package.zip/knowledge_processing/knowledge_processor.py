import os
import sys
import json
import networkx as nx
from datetime import datetime

class KnowledgeProcessor:
    """
    Knowledge Processing Core for the Autonomous Research Agent
    
    Responsible for:
    - Cross-domain knowledge integration
    - Contradiction and inconsistency resolution
    - Gap identification
    - Knowledge graph construction
    """
    
    def __init__(self):
        self.knowledge_base = {}
        self.knowledge_graph = nx.DiGraph()
        self.entities = set()
        self.relationships = []
        self.contradictions = []
        self.knowledge_gaps = []
        
    def load_information(self, information_file):
        """Load collected information from a JSON file"""
        try:
            with open(information_file, 'r') as f:
                data = json.load(f)
                
            if "information" in data:
                raw_information = data["information"]
                print(f"Loaded {len(raw_information)} information items")
                return raw_information
            else:
                print("Error: No information found in the file")
                return []
        except Exception as e:
            print(f"Error loading information: {e}")
            return []
    
    def process_information(self, raw_information):
        """Process and integrate information into the knowledge base"""
        if not raw_information:
            print("No information to process")
            return False
            
        # Process each information item
        for item in raw_information:
            # Extract key metadata
            source_id = item["source"]["url"].split("/")[-1]
            title = item["title"]
            
            # Extract content sections
            content = item.get("content", {})
            
            # Add to knowledge base
            self.knowledge_base[source_id] = {
                "title": title,
                "source": item["source"],
                "content": content,
                "quality_score": item.get("quality_score", 0.5),
                "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
        print(f"Processed {len(self.knowledge_base)} information items into knowledge base")
        return True
    
    def extract_entities(self):
        """
        Extract key entities from the knowledge base
        
        In a full implementation, this would use NER and entity linking
        For the prototype, we'll use a simplified approach
        """
        if not self.knowledge_base:
            print("Knowledge base is empty")
            return set()
            
        entities = set()
        
        for source_id, item in self.knowledge_base.items():
            # Extract entities from title
            title_words = item["title"].split()
            for i in range(len(title_words)):
                # Consider single words and bigrams as potential entities
                if i < len(title_words) - 1:
                    bigram = f"{title_words[i]} {title_words[i+1]}"
                    if len(bigram) > 10:  # Only consider substantial bigrams
                        entities.add(bigram)
                
                # Add single words that might be entities (simplified approach)
                if len(title_words[i]) > 5 and title_words[i][0].isupper():
                    entities.add(title_words[i])
            
            # Extract entities from content
            for section, text in item["content"].items():
                words = text.split()
                for i in range(len(words)):
                    # Consider single words and bigrams as potential entities
                    if i < len(words) - 1:
                        bigram = f"{words[i]} {words[i+1]}"
                        if len(bigram) > 10:  # Only consider substantial bigrams
                            entities.add(bigram)
                    
                    # Add single words that might be entities (simplified approach)
                    if len(words[i]) > 5 and words[i][0].isupper():
                        entities.add(words[i])
        
        # Filter out common words that aren't likely to be entities
        common_words = {"research", "study", "analysis", "findings", "results", "conclusion"}
        filtered_entities = {e for e in entities if e.lower() not in common_words}
        
        self.entities = filtered_entities
        print(f"Extracted {len(self.entities)} entities from knowledge base")
        return filtered_entities
    
    def identify_relationships(self):
        """
        Identify relationships between entities
        
        In a full implementation, this would use relation extraction techniques
        For the prototype, we'll use a simplified co-occurrence approach
        """
        if not self.entities or not self.knowledge_base:
            print("Entities or knowledge base is empty")
            return []
            
        relationships = []
        
        for source_id, item in self.knowledge_base.items():
            # Combine all text content for analysis
            all_text = item["title"] + " "
            for section, text in item["content"].items():
                all_text += text + " "
                
            # Check for co-occurrence of entities
            for entity1 in self.entities:
                if entity1 in all_text:
                    for entity2 in self.entities:
                        if entity1 != entity2 and entity2 in all_text:
                            # Create a relationship based on co-occurrence
                            relationship = {
                                "source": entity1,
                                "target": entity2,
                                "type": "co-occurs-with",
                                "confidence": 0.7,  # Simplified confidence score
                                "evidence": source_id
                            }
                            relationships.append(relationship)
        
        # Remove duplicates (simplified approach)
        unique_relationships = []
        relationship_pairs = set()
        
        for rel in relationships:
            pair = (rel["source"], rel["target"], rel["type"])
            if pair not in relationship_pairs:
                relationship_pairs.add(pair)
                unique_relationships.append(rel)
        
        self.relationships = unique_relationships
        print(f"Identified {len(self.relationships)} relationships between entities")
        return unique_relationships
    
    def build_knowledge_graph(self):
        """Build a knowledge graph from entities and relationships"""
        if not self.entities or not self.relationships:
            print("Entities or relationships are empty")
            return None
            
        # Create a new directed graph
        G = nx.DiGraph()
        
        # Add entities as nodes
        for entity in self.entities:
            G.add_node(entity)
            
        # Add relationships as edges
        for rel in self.relationships:
            G.add_edge(
                rel["source"], 
                rel["target"], 
                type=rel["type"],
                confidence=rel["confidence"],
                evidence=rel["evidence"]
            )
            
        self.knowledge_graph = G
        print(f"Built knowledge graph with {len(G.nodes)} nodes and {len(G.edges)} edges")
        return G
    
    def identify_contradictions(self):
        """
        Identify contradictions in the knowledge base
        
        In a full implementation, this would use logical reasoning
        For the prototype, we'll use a simplified approach
        """
        # For the prototype, we'll simulate finding contradictions
        contradictions = []
        
        if len(self.knowledge_base) > 1:
            # Get a list of sources
            sources = list(self.knowledge_base.keys())
            
            # Simulate finding contradictions between some sources
            for i in range(min(2, len(sources))):
                source1 = sources[i]
                source2 = sources[(i+1) % len(sources)]
                
                # Create a simulated contradiction
                contradiction = {
                    "type": "factual_disagreement",
                    "sources": [source1, source2],
                    "description": f"Conflicting information between {self.knowledge_base[source1]['title']} and {self.knowledge_base[source2]['title']}",
                    "resolution": "Requires further investigation"
                }
                contradictions.append(contradiction)
        
        self.contradictions = contradictions
        print(f"Identified {len(contradictions)} potential contradictions")
        return contradictions
    
    def identify_knowledge_gaps(self):
        """
        Identify gaps in the knowledge base
        
        In a full implementation, this would use sophisticated gap analysis
        For the prototype, we'll use a simplified approach
        """
        # For the prototype, we'll simulate finding knowledge gaps
        gaps = []
        
        # Simulate identifying missing information areas
        gap_areas = ["historical context", "future implications", "comparative analysis"]
        
        for area in gap_areas:
            # Check if any content mentions this area
            area_covered = False
            for source_id, item in self.knowledge_base.items():
                all_text = item["title"] + " "
                for section, text in item["content"].items():
                    all_text += text + " "
                    
                if area in all_text.lower():
                    area_covered = True
                    break
                    
            if not area_covered:
                gap = {
                    "area": area,
                    "description": f"Limited or no information about {area}",
                    "suggested_queries": [f"research on {area}", f"{area} analysis"]
                }
                gaps.append(gap)
        
        self.knowledge_gaps = gaps
        print(f"Identified {len(gaps)} knowledge gaps")
        return gaps
    
    def export_processed_knowledge(self, output_file):
        """Export the processed knowledge to a JSON file"""
        # Convert knowledge graph to serializable format
        nodes = list(self.knowledge_graph.nodes())
        edges = []
        for u, v, data in self.knowledge_graph.edges(data=True):
            edge = {
                "source": u,
                "target": v,
                "type": data.get("type", "related-to"),
                "confidence": data.get("confidence", 0.5),
                "evidence": data.get("evidence", "unknown")
            }
            edges.append(edge)
            
        data = {
            "knowledge_base_summary": {
                "sources": len(self.knowledge_base),
                "entities": len(self.entities),
                "relationships": len(self.relationships)
            },
            "entities": list(self.entities),
            "relationships": self.relationships,
            "knowledge_graph": {
                "nodes": nodes,
                "edges": edges
            },
            "contradictions": self.contradictions,
            "knowledge_gaps": self.knowledge_gaps
        }
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
            
        print(f"Processed knowledge exported to {output_file}")
        return output_file


# Example usage
if __name__ == "__main__":
    processor = KnowledgeProcessor()
    
    # Check if information file is provided
    if len(sys.argv) > 1:
        information_file = sys.argv[1]
    else:
        # Default to a sample file path
        script_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(script_dir)
        information_file = os.path.join(parent_dir, "information_acquisition", "collected_information.json")
    
    # Load and process information
    raw_information = processor.load_information(information_file)
    if raw_information:
        processor.process_information(raw_information)
        processor.extract_entities()
        processor.identify_relationships()
        processor.build_knowledge_graph()
        processor.identify_contradictions()
        processor.identify_knowledge_gaps()
        
        # Export processed knowledge
        output_dir = os.path.dirname(os.path.abspath(__file__))
        processor.export_processed_knowledge(os.path.join(output_dir, "processed_knowledge.json"))

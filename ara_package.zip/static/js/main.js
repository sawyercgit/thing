// Main JavaScript for Autonomous Research Agent (ARA)

document.addEventListener('DOMContentLoaded', function() {
    // Global variables
    let currentProjectId = null;
    let researchTopic = null;
    let researchStatus = {};

    // DOM Elements
    const startResearchBtn = document.getElementById('start-research-btn');
    const researchTopicInput = document.getElementById('research-topic');
    const startResearchSection = document.getElementById('start-research-section');
    const researchWorkflowSection = document.getElementById('research-workflow-section');
    const researchReportSection = document.getElementById('research-report-section');
    const feedbackSection = document.getElementById('feedback-section');
    const projectDetails = document.getElementById('project-details');
    const reportContent = document.getElementById('report-content');
    
    // Workflow buttons
    const gatherInformationBtn = document.getElementById('gather-information-btn');
    const processKnowledgeBtn = document.getElementById('process-knowledge-btn');
    const generateInsightsBtn = document.getElementById('generate-insights-btn');
    const createContentBtn = document.getElementById('create-content-btn');
    const downloadReportBtn = document.getElementById('download-report-btn');
    const submitFeedbackBtn = document.getElementById('submit-feedback-btn');
    
    // Modal elements
    const detailsModal = document.getElementById('details-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalContent = document.getElementById('modal-content');
    const closeModal = document.querySelector('.close-modal');
    
    // Progress bars
    const planningProgress = document.getElementById('planning-progress');
    const planningPercent = document.getElementById('planning-percent');
    const infoAcquisitionProgress = document.getElementById('information-acquisition-progress');
    const infoAcquisitionPercent = document.getElementById('information-acquisition-percent');
    const knowledgeProcessingProgress = document.getElementById('knowledge-processing-progress');
    const knowledgeProcessingPercent = document.getElementById('knowledge-processing-percent');
    const insightGenerationProgress = document.getElementById('insight-generation-progress');
    const insightGenerationPercent = document.getElementById('insight-generation-percent');
    const contentCreationProgress = document.getElementById('content-creation-progress');
    const contentCreationPercent = document.getElementById('content-creation-percent');
    const overallProgress = document.getElementById('overall-progress');
    const overallPercent = document.getElementById('overall-percent');
    
    // Event Listeners
    startResearchBtn.addEventListener('click', startResearch);
    gatherInformationBtn.addEventListener('click', gatherInformation);
    processKnowledgeBtn.addEventListener('click', processKnowledge);
    generateInsightsBtn.addEventListener('click', generateInsights);
    createContentBtn.addEventListener('click', createContent);
    downloadReportBtn.addEventListener('click', downloadReport);
    submitFeedbackBtn.addEventListener('click', submitFeedback);
    
    // View details buttons
    document.querySelectorAll('.view-details-btn').forEach(button => {
        button.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            showDetails(section);
        });
    });
    
    // Close modal
    closeModal.addEventListener('click', function() {
        detailsModal.style.display = 'none';
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === detailsModal) {
            detailsModal.style.display = 'none';
        }
    });
    
    // Functions
    async function startResearch() {
        const topic = researchTopicInput.value.trim();
        
        if (!topic) {
            alert('Please enter a research topic');
            return;
        }
        
        try {
            // Show loading state
            startResearchBtn.disabled = true;
            startResearchBtn.textContent = 'Starting Research...';
            
            // Call API to start research
            const response = await fetch('/api/research/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ topic })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Update global variables
                currentProjectId = data.project_id;
                researchTopic = topic;
                
                // Update UI
                updateProjectInfo(data);
                updateResearchProgress();
                
                // Show workflow section
                startResearchSection.style.display = 'none';
                researchWorkflowSection.style.display = 'block';
                feedbackSection.style.display = 'block';
                
                // Update planning step content
                const planningContent = document.getElementById('planning-content');
                planningContent.innerHTML = `
                    <p><strong>Research Topic:</strong> ${data.topic}</p>
                    <p><strong>Research Questions:</strong></p>
                    <ul>
                        ${data.research_questions.map(q => `<li>${q}</li>`).join('')}
                    </ul>
                    <p><strong>Selected Methodology:</strong> ${data.methodology.name}</p>
                    <p>${data.methodology.description}</p>
                `;
                
                // Enable next step button
                gatherInformationBtn.disabled = false;
            } else {
                alert(`Error: ${data.error || 'Failed to start research'}`);
            }
        } catch (error) {
            console.error('Error starting research:', error);
            alert('An error occurred while starting research. Please try again.');
        } finally {
            // Reset button state
            startResearchBtn.disabled = false;
            startResearchBtn.textContent = 'Start Research';
        }
    }
    
    async function gatherInformation() {
        if (!currentProjectId) return;
        
        try {
            // Show loading state
            gatherInformationBtn.disabled = true;
            gatherInformationBtn.textContent = 'Gathering Information...';
            
            // Call API to gather information
            const response = await fetch('/api/research/gather_information', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    project_id: currentProjectId,
                    topic: researchTopic
                })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Update UI
                updateResearchProgress();
                
                // Update information acquisition step content
                const infoContent = document.getElementById('information-acquisition-content');
                infoContent.innerHTML = `
                    <p><strong>Information Gathered:</strong> ${data.search_results} sources</p>
                    <p><strong>Extracted Information:</strong> ${data.extracted_information} items</p>
                    <p><strong>Organized Topics:</strong></p>
                    <ul>
                        ${Object.keys(data.organized_topics).map(topic => 
                            `<li>${topic}: ${data.organized_topics[topic].length} items</li>`
                        ).join('')}
                    </ul>
                `;
                
                // Enable next step button
                processKnowledgeBtn.disabled = false;
            } else {
                alert(`Error: ${data.error || 'Failed to gather information'}`);
            }
        } catch (error) {
            console.error('Error gathering information:', error);
            alert('An error occurred while gathering information. Please try again.');
        } finally {
            // Reset button state
            gatherInformationBtn.disabled = false;
            gatherInformationBtn.textContent = 'Gather Information';
        }
    }
    
    async function processKnowledge() {
        if (!currentProjectId) return;
        
        try {
            // Show loading state
            processKnowledgeBtn.disabled = true;
            processKnowledgeBtn.textContent = 'Processing Knowledge...';
            
            // Call API to process knowledge
            const response = await fetch('/api/research/process_knowledge', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ project_id: currentProjectId })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Update UI
                updateResearchProgress();
                
                // Update knowledge processing step content
                const knowledgeContent = document.getElementById('knowledge-processing-content');
                knowledgeContent.innerHTML = `
                    <p><strong>Entities Extracted:</strong> ${data.entities}</p>
                    <p><strong>Relationships Identified:</strong> ${data.relationships}</p>
                    <p><strong>Contradictions Found:</strong> ${data.contradictions}</p>
                    <p><strong>Knowledge Gaps Identified:</strong> ${data.knowledge_gaps}</p>
                `;
                
                // Enable next step button
                generateInsightsBtn.disabled = false;
            } else {
                alert(`Error: ${data.error || 'Failed to process knowledge'}`);
            }
        } catch (error) {
            console.error('Error processing knowledge:', error);
            alert('An error occurred while processing knowledge. Please try again.');
        } finally {
            // Reset button state
            processKnowledgeBtn.disabled = false;
            processKnowledgeBtn.textContent = 'Process Knowledge';
        }
    }
    
    async function generateInsights() {
        if (!currentProjectId) return;
        
        try {
            // Show loading state
            generateInsightsBtn.disabled = true;
            generateInsightsBtn.textContent = 'Generating Insights...';
            
            // Call API to generate insights
            const response = await fetch('/api/research/generate_insights', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ project_id: currentProjectId })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Update UI
                updateResearchProgress();
                
                // Update insight generation step content
                const insightContent = document.getElementById('insight-generation-content');
                insightContent.innerHTML = `
                    <p><strong>Insights Generated:</strong> ${data.insights}</p>
                    <p>The system has analyzed the processed knowledge and generated valuable insights, hypotheses, and predictions based on the research topic.</p>
                `;
                
                // Enable next step button
                createContentBtn.disabled = false;
            } else {
                alert(`Error: ${data.error || 'Failed to generate insights'}`);
            }
        } catch (error) {
            console.error('Error generating insights:', error);
            alert('An error occurred while generating insights. Please try again.');
        } finally {
            // Reset button state
            generateInsightsBtn.disabled = false;
            generateInsightsBtn.textContent = 'Generate Insights';
        }
    }
    
    async function createContent() {
        if (!currentProjectId) return;
        
        try {
            // Show loading state
            createContentBtn.disabled = true;
            createContentBtn.textContent = 'Creating Content...';
            
            // Call API to create content
            const response = await fetch('/api/research/create_content', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ project_id: currentProjectId })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Update UI
                updateResearchProgress();
                
                // Update content creation step content
                const contentCreationContent = document.getElementById('content-creation-content');
                contentCreationContent.innerHTML = `
                    <p><strong>Document Structure:</strong> ${data.document_structure.sections.length} sections</p>
                    <p><strong>Citations:</strong> ${data.citations} sources</p>
                    <p><strong>Status:</strong> <span class="text-success">Research report completed</span></p>
                `;
                
                // Show research report
                researchReportSection.style.display = 'block';
                
                // Convert markdown to HTML (simple conversion)
                const markdownContent = data.report_content;
                const htmlContent = convertMarkdownToHTML(markdownContent);
                reportContent.innerHTML = htmlContent;
            } else {
                alert(`Error: ${data.error || 'Failed to create content'}`);
            }
        } catch (error) {
            console.error('Error creating content:', error);
            alert('An error occurred while creating content. Please try again.');
        } finally {
            // Reset button state
            createContentBtn.disabled = false;
            createContentBtn.textContent = 'Create Content';
        }
    }
    
    function downloadReport() {
        if (!currentProjectId) return;
        
        fetch(`/api/research/report?project_id=${currentProjectId}`)
            .then(response => response.json())
            .then(data => {
                if (data.report_content) {
                    // Create blob and download
                    const blob = new Blob([data.report_content], { type: 'text/markdown' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `research_report_${currentProjectId}.md`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                } else {
                    alert('No report content available');
                }
            })
            .catch(error => {
                console.error('Error downloading report:', error);
                alert('An error occurred while downloading the report');
            });
    }
    
    async function submitFeedback() {
        if (!currentProjectId) return;
        
        const feedbackType = document.getElementById('feedback-type').value;
        const feedbackContent = document.getElementById('feedback-content').value.trim();
        
        if (!feedbackContent) {
            alert('Please enter feedback content');
            return;
        }
        
        try {
            submitFeedbackBtn.disabled = true;
            submitFeedbackBtn.textContent = 'Submitting...';
            
            const response = await fetch('/api/research/feedback', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    project_id: currentProjectId,
                    type: feedbackType,
                    content: feedbackContent
                })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                alert('Feedback submitted successfully');
                document.getElementById('feedback-content').value = '';
            } else {
                alert(`Error: ${data.error || 'Failed to submit feedback'}`);
            }
        } catch (error) {
            console.error('Error submitting feedback:', error);
            alert('An error occurred while submitting feedback');
        } finally {
            submitFeedbackBtn.disabled = false;
            submitFeedbackBtn.textContent = 'Submit Feedback';
        }
    }
    
    function showDetails(section) {
        let title = '';
        let content = '';
        
        switch (section) {
            case 'planning':
                title = 'Research Planning Details';
                content = `
                    <p>The Research Planning Engine formulates specific research questions based on the provided topic and selects an appropriate research methodology.</p>
                    <p>Key components:</p>
                    <ul>
                        <li>Research question formulation and refinement</li>
                        <li>Methodology selection and customization</li>
                        <li>Task decomposition and sequencing</li>
                        <li>Timeline and milestone management</li>
                    </ul>
                `;
                break;
            case 'information-acquisition':
                title = 'Information Acquisition Details';
                content = `
                    <p>The Information Acquisition System gathers relevant information from diverse sources, evaluates source quality, and extracts structured information.</p>
                    <p>Key components:</p>
                    <ul>
                        <li>Multi-source search and retrieval</li>
                        <li>Source quality evaluation</li>
                        <li>Information extraction and structuring</li>
                        <li>Topic-based organization</li>
                    </ul>
                `;
                break;
            case 'knowledge-processing':
                title = 'Knowledge Processing Details';
                content = `
                    <p>The Knowledge Processing Core analyzes and synthesizes information into a coherent knowledge base, identifying entities, relationships, and patterns.</p>
                    <p>Key components:</p>
                    <ul>
                        <li>Cross-domain knowledge integration</li>
                        <li>Entity and relationship extraction</li>
                        <li>Knowledge graph construction</li>
                        <li>Contradiction and gap identification</li>
                    </ul>
                `;
                break;
            case 'insight-generation':
                title = 'Insight Generation Details';
                content = `
                    <p>The Insight Generation Engine identifies patterns in the knowledge graph, generates hypotheses, and creates predictions based on the integrated knowledge.</p>
                    <p>Key components:</p>
                    <ul>
                        <li>Pattern recognition across domains</li>
                        <li>Hypothesis generation and evaluation</li>
                        <li>Prediction and scenario modeling</li>
                        <li>Insight synthesis</li>
                    </ul>
                `;
                break;
            case 'content-creation':
                title = 'Content Creation Details';
                content = `
                    <p>The Content Creation System produces high-quality research outputs by planning document structure, generating content, and managing citations.</p>
                    <p>Key components:</p>
                    <ul>
                        <li>Document structure planning</li>
                        <li>Section content generation</li>
                        <li>Citation and reference management</li>
                        <li>Style adaptation</li>
                    </ul>
                `;
                break;
        }
        
        modalTitle.textContent = title;
        modalContent.innerHTML = content;
        detailsModal.style.display = 'block';
    }
    
    function updateProjectInfo(data) {
        if (!data) return;
        
        projectDetails.innerHTML = `
            <p><strong>Project ID:</strong> ${data.project_id}</p>
            <p><strong>Research Topic:</strong> ${data.topic}</p>
            <p><strong>Research Questions:</strong> ${data.research_questions.length}</p>
            <p><strong>Methodology:</strong> ${data.methodology.name}</p>
            <p><strong>Status:</strong> <span class="text-info">Active</span></p>
        `;
    }
    
    async function updateResearchProgress() {
        if (!currentProjectId) return;
        
        try {
            const response = await fetch(`/api/research/status?project_id=${currentProjectId}`);
            const data = await response.json();
            
            if (response.ok) {
                researchStatus = data;
                
                // Update progress bars
                const phases = data.phases || {};
                
                if (phases.planning) {
                    updateProgressBar(planningProgress, planningPercent, phases.planning.progress);
                }
                
                if (phases.information_acquisition) {
                    updateProgressBar(infoAcquisitionProgress, infoAcquisitionPercent, phases.information_acquisition.progress);
                }
                
                if (phases.knowledge_processing) {
                    updateProgressBar(knowledgeProcessingProgress, knowledgeProcessingPercent, phases.knowledge_processing.progress);
                }
                
                if (phases.insight_generation) {
                    updateProgressBar(insightGenerationProgress, insightGenerationPercent, phases.insight_generation.progress);
                }
                
                if (phases.content_creation) {
                    updateProgressBar(contentCreationProgress, contentCreationPercent, phases.content_creation.progress);
                }
                
                // Update overall progress
                updateProgressBar(overallProgress, overallPercent, data.progress || 0);
            }
        } catch (error) {
            console.error('Error updating research progress:', error);
        }
    }
    
    function updateProgressBar(progressBar, percentElement, value) {
        const progress = value || 0;
        progressBar.style.width = `${progress}%`;
        percentElement.textContent = `${progress}%`;
    }
    
    // Simple markdown to HTML converter
    function convertMarkdownToHTML(markdown) {
        if (!markdown) return '';
        
        // Replace headers
        let html = markdown
            .replace(/^# (.*$)/gm, '<h1>$1</h1>')
            .replace(/^## (.*$)/gm, '<h2>$1</h2>')
            .replace(/^### (.*$)/gm, '<h3>$1</h3>')
            .replace(/^#### (.*$)/gm, '<h4>$1</h4>')
            .replace(/^##### (.*$)/gm, '<h5>$1</h5>')
            .replace(/^###### (.*$)/gm, '<h6>$1</h6>');
        
        // Replace bold and italic
        html = html
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        // Replace lists
        html = html
            .replace(/^\- (.*$)/gm, '<li>$1</li>')
            .replace(/(<li>.*<\/li>\n)+/g, '<ul>$&</ul>');
        
        // Replace paragraphs
        html = html
            .replace(/^(?!<[hou]|<li|\s*$)(.*$)/gm, '<p>$1</p>');
        
        return html;
    }
    
    // Check for status updates every 5 seconds
    setInterval(function() {
        if (currentProjectId) {
            updateResearchProgress();
        }
    }, 5000);
});

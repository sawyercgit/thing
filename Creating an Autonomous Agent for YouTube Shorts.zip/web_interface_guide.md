# YouTube Shorts Agent Web Interface - Documentation

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Running the Web Interface](#running-the-web-interface)
4. [Using the Web Interface](#using-the-web-interface)
5. [Features](#features)
6. [Technical Architecture](#technical-architecture)
7. [Customization](#customization)
8. [Troubleshooting](#troubleshooting)

## Introduction

The YouTube Shorts Agent Web Interface provides a user-friendly browser-based interface to the YouTube Shorts autonomous agent. This web application allows users to create YouTube Shorts from simple text prompts without needing to use the command line or understand the underlying technical implementation.

The web interface wraps the core functionality of the YouTube Shorts agent in an intuitive UI that guides users through the process of creating, monitoring, and uploading YouTube Shorts.

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- All dependencies required by the YouTube Shorts agent

### Step 1: Install Required Packages

```bash
pip install flask
```

### Step 2: Set Up the Web Interface

The web interface is already included in the YouTube Shorts agent project. No additional setup is required beyond installing the Flask package.

## Running the Web Interface

To start the web interface, navigate to the YouTube Shorts agent directory and run:

```bash
cd youtube_shorts_agent
python web_interface/app.py
```

This will start a Flask development server on port 5000. You can access the web interface by opening a browser and navigating to:

```
http://localhost:5000
```

For production deployment, it's recommended to use a production WSGI server like Gunicorn:

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 web_interface.app:app
```

## Using the Web Interface

### Creating a YouTube Short

1. **Enter a Prompt**: On the home page, enter a descriptive prompt for your YouTube Short in the text area. For example: "Create a short about amazing space exploration facts"

2. **Configure Options**: 
   - Check the "Upload to YouTube" box if you want the video to be automatically uploaded to YouTube after creation
   - Expand the "Advanced Options" section to customize the visual style, content tone, and effect intensity

3. **Create the Short**: Click the "Create YouTube Short" button to start the generation process

4. **Monitor Progress**: You'll be redirected to the job status page where you can track the progress of your Short creation in real-time

5. **View Results**: Once the process is complete, you'll see the results including:
   - The title of your YouTube Short
   - A link to view the video on YouTube (if uploaded)
   - Options to create another Short

### Viewing Job History

1. Click on the "History" link in the navigation bar
2. View a list of all your previous jobs with their status and progress
3. Click "View" on any job to see its details
4. For completed jobs with uploaded videos, click "YouTube" to view the video on YouTube

## Features

### Home Page
- Simple prompt input form
- Advanced options for customization
- Clear explanation of the process

### Job Status Page
- Real-time progress tracking
- Status updates with detailed messages
- Automatic page updates without refreshing
- Results display with links to YouTube

### History Page
- Chronological list of all jobs
- Status indicators and progress bars
- Quick access to job details and YouTube videos

## Technical Architecture

The web interface follows a standard Flask application structure:

```
web_interface/
├── app.py                 # Main Flask application
├── static/                # Static assets
│   ├── css/               # CSS stylesheets
│   │   └── style.css      # Custom styles
│   └── js/                # JavaScript files
│       └── script.js      # Client-side functionality
└── templates/             # HTML templates
    ├── index.html         # Home page
    ├── job_status.html    # Job status page
    └── history.html       # Job history page
```

### Key Components

1. **Flask Application (app.py)**
   - Defines routes and request handlers
   - Manages job processing in background threads
   - Provides API endpoints for status updates

2. **YouTubeShortsAgentWeb Class**
   - Wraps the core agent functionality
   - Handles job processing logic
   - Manages the pipeline from prompt to video

3. **Templates**
   - Responsive Bootstrap-based UI
   - Real-time updates using JavaScript
   - Consistent styling and navigation

4. **In-Memory Job Storage**
   - Stores job information and status
   - Provides access to job history
   - Note: In a production environment, this would be replaced with a database

## Customization

### Styling

The web interface uses Bootstrap 5 for styling. You can customize the appearance by modifying the CSS in `static/css/style.css`.

### Adding New Features

To add new features to the web interface:

1. **New Routes**: Add new route handlers to `app.py`
2. **New Templates**: Create new HTML templates in the `templates` directory
3. **New Functionality**: Extend the `YouTubeShortsAgentWeb` class with additional methods

### Configuration

The web interface uses the same configuration system as the core agent. You can provide a custom configuration file when initializing the `YouTubeShortsAgentWeb` class.

## Troubleshooting

### Common Issues

#### Web Interface Won't Start

- **Error**: "Address already in use"
  - **Solution**: Another process is using port 5000. Change the port in `app.py` or stop the other process.

- **Error**: "No module named 'flask'"
  - **Solution**: Install Flask using `pip install flask`

#### Job Processing Errors

- **Error**: "Could not import agent modules"
  - **Solution**: This is normal when running in demo mode. For full functionality, ensure the agent modules are properly installed.

- **Error**: "Error processing job"
  - **Solution**: Check the server logs for detailed error information. Most issues are related to missing dependencies or configuration.

#### YouTube Upload Issues

- **Error**: "Authentication failed"
  - **Solution**: Verify your YouTube API credentials and ensure they have the correct permissions

- **Error**: "Upload failed"
  - **Solution**: Check your internet connection and YouTube API quota limits

### Getting Help

If you encounter issues not covered here:

1. Check the server logs for detailed error messages
2. Review the core agent documentation for configuration requirements
3. Ensure all dependencies are properly installed
4. Check for any firewall or network restrictions if accessing remotely

---

This documentation provides a comprehensive guide to the YouTube Shorts Agent Web Interface. For further assistance or to report issues, please contact the repository maintainers.

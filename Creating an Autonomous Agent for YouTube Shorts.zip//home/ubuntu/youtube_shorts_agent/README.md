# YouTube Shorts Autonomous Agent - README

## Overview

The YouTube Shorts Autonomous Agent is a comprehensive system that automates the creation and upload of YouTube Shorts videos from simple text prompts. This agent handles the entire pipeline from content generation to video editing to YouTube upload.

## Features

- **Text-to-Video Generation**: Create complete YouTube Shorts from simple text prompts
- **Vertical Video Format**: Automatically formats videos to YouTube Shorts specifications (9:16 aspect ratio)
- **Engaging Content**: Generates scripts, visuals, and audio optimized for short-form content
- **Captions & Effects**: Adds captions, transitions, and visual effects to increase engagement
- **YouTube Upload**: Automates metadata generation and video uploads to YouTube
- **Customizable**: Extensive configuration options for all aspects of the generation process

## System Components

The agent consists of three main modules:

1. **Content Generation Module**: Transforms text prompts into scripts, visual assets, and audio
2. **Video Editing Module**: Creates properly formatted videos with captions, transitions, and effects
3. **Upload Automation Module**: Generates metadata and uploads videos to YouTube

## Quick Start

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up YouTube API credentials (required for uploads):
   ```bash
   export YOUTUBE_API_KEY=your_api_key
   export YOUTUBE_CLIENT_ID=your_client_id
   export YOUTUBE_CLIENT_SECRET=your_client_secret
   ```

3. Run the test script:
   ```bash
   python test_agent.py --prompt "Create a short about amazing space exploration facts"
   ```

4. To upload to YouTube, add the `--upload` flag:
   ```bash
   python test_agent.py --prompt "Create a short about amazing space exploration facts" --upload
   ```

## Documentation

For detailed information, please refer to the following documentation:

- [User Guide](docs/user_guide.md): Complete instructions for installation, usage, and customization
- [Architecture](design/architecture.md): Overview of the system architecture and components
- [Module Specifications](design/module_specifications.md): Detailed specifications for each module

## Project Structure

```
youtube_shorts_agent/
├── code/
│   ├── content_generation/     # Content generation module
│   ├── video_editing/          # Video editing module
│   ├── upload_automation/      # Upload automation module
├── design/                     # Design documents
├── docs/                       # Documentation
├── research/                   # Research findings
├── test_agent.py               # Main test script
├── README.md                   # This file
└── requirements.txt            # Dependencies
```

## Requirements

- Python 3.8 or higher
- FFmpeg (for video processing)
- YouTube API credentials (for uploading)

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- This project was created as a demonstration of autonomous agent capabilities
- Special thanks to the Manus team for their support and guidance

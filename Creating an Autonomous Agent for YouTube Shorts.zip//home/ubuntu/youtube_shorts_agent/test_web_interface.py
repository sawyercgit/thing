#!/usr/bin/env python3
"""
Test script for the YouTube Shorts Agent Web Interface
"""

import os
import sys
import time
import unittest
from unittest.mock import patch, MagicMock
import tempfile
import json

# Add the web_interface directory to the Python path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_interface"))

# Import the Flask app
from app import app, jobs, YouTubeShortsAgentWeb

class YouTubeShortsAgentWebInterfaceTest(unittest.TestCase):
    """Test cases for the YouTube Shorts Agent Web Interface"""
    
    def setUp(self):
        """Set up test environment"""
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.app = app.test_client()
        
        # Clear jobs dictionary
        jobs.clear()
        
    def test_index_page(self):
        """Test that the index page loads correctly"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Create YouTube Short', response.data)
        self.assertIn(b'Enter your prompt', response.data)
        
    def test_history_page_empty(self):
        """Test that the history page loads correctly when empty"""
        response = self.app.get('/history')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Job History', response.data)
        self.assertIn(b'No jobs found', response.data)
        
    def test_create_short(self):
        """Test creating a new Short"""
        with patch.object(YouTubeShortsAgentWeb, 'process_job', return_value=None) as mock_process:
            response = self.app.post('/create', data={
                'prompt': 'Test prompt for YouTube Short',
                'upload': 'false'
            }, follow_redirects=True)
            
            self.assertEqual(response.status_code, 200)
            self.assertIn(b'Job Status', response.data)
            self.assertIn(b'Test prompt for YouTube Short', response.data)
            
            # Check that a job was created
            self.assertEqual(len(jobs), 1)
            job_id = list(jobs.keys())[0]
            self.assertEqual(jobs[job_id]['prompt'], 'Test prompt for YouTube Short')
            self.assertEqual(jobs[job_id]['status'], 'queued')
            
            # Check that process_job was called
            mock_process.assert_called_once()
            
    def test_job_status_page(self):
        """Test that the job status page loads correctly"""
        # Create a test job
        job_id = 'test_job_id'
        jobs[job_id] = {
            'id': job_id,
            'prompt': 'Test prompt',
            'upload': False,
            'status': 'processing',
            'progress': 50,
            'message': 'Processing job...',
            'created_at': time.time(),
            'result': None
        }
        
        response = self.app.get(f'/job/{job_id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Job Status', response.data)
        self.assertIn(b'Test prompt', response.data)
        self.assertIn(b'processing', response.data)
        self.assertIn(b'50%', response.data)
        
    def test_job_status_api(self):
        """Test the job status API endpoint"""
        # Create a test job
        job_id = 'test_job_id'
        jobs[job_id] = {
            'id': job_id,
            'prompt': 'Test prompt',
            'upload': False,
            'status': 'processing',
            'progress': 50,
            'message': 'Processing job...',
            'created_at': time.time(),
            'result': None
        }
        
        response = self.app.get(f'/api/job/{job_id}')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['id'], job_id)
        self.assertEqual(data['status'], 'processing')
        self.assertEqual(data['progress'], 50)
        
    def test_job_status_not_found(self):
        """Test accessing a non-existent job"""
        response = self.app.get('/job/nonexistent_id')
        self.assertEqual(response.status_code, 302)  # Redirect to index
        
    def test_job_api_not_found(self):
        """Test accessing a non-existent job via API"""
        response = self.app.get('/api/job/nonexistent_id')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
        
    def test_history_page_with_jobs(self):
        """Test that the history page shows jobs correctly"""
        # Create some test jobs
        jobs['job1'] = {
            'id': 'job1',
            'prompt': 'Test prompt 1',
            'upload': False,
            'status': 'completed',
            'progress': 100,
            'message': 'Job completed',
            'created_at': time.time() - 3600,  # 1 hour ago
            'result': {
                'title': 'Test Short 1',
                'content_id': 'content_1',
                'sequence_id': 'seq_1',
                'video_url': 'https://youtube.com/shorts/test1'
            }
        }
        
        jobs['job2'] = {
            'id': 'job2',
            'prompt': 'Test prompt 2',
            'upload': True,
            'status': 'processing',
            'progress': 60,
            'message': 'Processing job...',
            'created_at': time.time(),
            'result': None
        }
        
        response = self.app.get('/history')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Job History', response.data)
        self.assertIn(b'Test prompt 1', response.data)
        self.assertIn(b'Test prompt 2', response.data)
        self.assertIn(b'completed', response.data)
        self.assertIn(b'processing', response.data)
        
    def test_completed_job_status_page(self):
        """Test that a completed job shows results correctly"""
        # Create a completed test job
        job_id = 'completed_job_id'
        jobs[job_id] = {
            'id': job_id,
            'prompt': 'Test prompt',
            'upload': True,
            'status': 'completed',
            'progress': 100,
            'message': 'Job completed successfully!',
            'created_at': time.time(),
            'result': {
                'title': 'Amazing Test Short',
                'content_id': 'content_test',
                'sequence_id': 'seq_test',
                'video_id': 'video_test',
                'video_url': 'https://youtube.com/shorts/video_test'
            }
        }
        
        response = self.app.get(f'/job/{job_id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Job Status', response.data)
        self.assertIn(b'completed', response.data)
        self.assertIn(b'100%', response.data)
        self.assertIn(b'Amazing Test Short', response.data)
        self.assertIn(b'https://youtube.com/shorts/video_test', response.data)
        
    def test_error_job_status_page(self):
        """Test that an error job shows error message correctly"""
        # Create an error test job
        job_id = 'error_job_id'
        jobs[job_id] = {
            'id': job_id,
            'prompt': 'Test prompt',
            'upload': False,
            'status': 'error',
            'progress': 30,
            'message': 'Error: Something went wrong',
            'created_at': time.time(),
            'result': None
        }
        
        response = self.app.get(f'/job/{job_id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Job Status', response.data)
        self.assertIn(b'error', response.data)
        self.assertIn(b'Error: Something went wrong', response.data)
        self.assertIn(b'Try Again', response.data)

if __name__ == '__main__':
    unittest.main()

# YouTube Shorts Specifications Research

## Technical Specifications

### Video Format
- **Aspect Ratio**: 9:16 (vertical format)
- **Resolution**: 1080x1920 pixels (width x height)
- **Alternative Formats**: Square (1:1) videos can also be categorized as Shorts, but will have black bars at top and bottom
- **Format Restriction**: Videos wider than square (e.g., 16:9) will not be considered as Shorts

### Duration
- **Current Limit**: Up to 60 seconds traditionally
- **New Limit**: As of October 15, 2024, YouTube Shorts can be up to 3 minutes in length
- **Note**: Videos uploaded before October 15, 2024 remain as long-form videos even if they meet Shorts criteria

### Content Restrictions
- **Third-party Content**: Shorts over one minute with active Content ID claims will be blocked globally
- **Music Usage**: Special restrictions apply for music in Shorts (requires further research)

## API Upload Requirements

### YouTube API Integration
- Upload process is similar to regular YouTube videos
- Use the standard YouTube Data API v3 for uploads

### Shorts-Specific Parameters
- **Aspect Ratio**: Ensure 9:16 or 1:1 (square) aspect ratio
- **Duration**: Keep under 60 seconds (traditional) or 3 minutes (new limit)
- **Optional Hashtag**: Adding #shorts to title and/or description may help with discovery
  - `snippet.title`: Can include #shorts hashtag
  - `snippet.description`: Can include #shorts hashtag

### API Endpoints
- Use standard `videos` endpoint for uploads
- No special endpoint specifically for Shorts

## Video Generation Tools and Libraries

### Python Libraries for Video Processing
- **MoviePy**: Python library for video editing (cutting, cropping, effects)
- **Pytube**: Library for downloading YouTube videos (useful for content sourcing)
- **OpenCV**: Computer vision library for video processing and face detection
- **Faster-Whisper**: Optimized implementation of OpenAI's Whisper for transcription
- **WebRTC VAD**: Voice Activity Detection for identifying speaking segments

### AI Components for Shorts Generation
- **Transcription**: Using Whisper or similar models to generate video transcripts
- **Highlight Detection**: Using LLMs like GPT to identify viral-worthy segments
- **Speaker Detection**: Combining face detection and lip movement analysis
- **Auto-Cropping**: Identifying and focusing on speakers while maintaining 9:16 ratio

### Workflow Components
1. **Content Sourcing**: Downloading or generating source videos
2. **Transcription**: Converting speech to text for analysis
3. **Highlight Identification**: Finding engaging segments
4. **Format Conversion**: Cropping to 9:16 aspect ratio while focusing on important content
5. **Enhancement**: Adding captions, effects, transitions
6. **Upload Automation**: Using YouTube API to publish content

## Monetization Considerations
- Shorts can be monetized through the Shorts revenue sharing model
- Different monetization rules apply to Shorts vs. long-form content
- Content ID claims affect monetization eligibility

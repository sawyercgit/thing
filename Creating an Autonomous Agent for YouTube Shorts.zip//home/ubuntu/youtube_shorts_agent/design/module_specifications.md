# Module Specifications for YouTube Shorts Agent

This document provides detailed specifications for each module in the YouTube Shorts autonomous agent architecture.

## 1. Text Prompt Processing Module

### Class Structure

```python
class PromptProcessor:
    def __init__(self, config=None):
        self.config = config or {}
        # Initialize NLP tools and models
        
    def parse_prompt(self, prompt_text):
        """Extract key information from the user prompt"""
        # Implementation details
        
    def enhance_prompt(self, parsed_prompt):
        """Expand the prompt into a detailed content plan"""
        # Implementation details
        
    def analyze_theme(self, parsed_prompt):
        """Identify theme, tone, and style"""
        # Implementation details
        
    def generate_content_plan(self, prompt_text):
        """Main method that processes the prompt and returns a content plan"""
        parsed = self.parse_prompt(prompt_text)
        enhanced = self.enhance_prompt(parsed)
        theme_info = self.analyze_theme(parsed)
        
        return {
            "content_plan": enhanced,
            "theme": theme_info,
            "keywords": self._extract_keywords(parsed)
        }
```

### API Integration

- **OpenAI GPT API**: For prompt enhancement and script generation
- **NLP Libraries**: For keyword extraction and theme analysis

## 2. Content Generation Module

### Class Structure

```python
class ContentGenerator:
    def __init__(self, config=None):
        self.config = config or {}
        # Initialize generation tools and APIs
        
    def generate_script(self, content_plan):
        """Generate narration script from content plan"""
        # Implementation details
        
    def generate_visuals(self, content_plan, theme_info):
        """Generate or source visual assets"""
        # Implementation details
        
    def generate_audio(self, script, theme_info):
        """Generate voiceover and select background music"""
        # Implementation details
        
    def generate_content(self, content_plan, theme_info):
        """Main method that generates all necessary assets"""
        script = self.generate_script(content_plan)
        visuals = self.generate_visuals(content_plan, theme_info)
        audio = self.generate_audio(script, theme_info)
        
        return {
            "script": script,
            "visuals": visuals,
            "audio": audio
        }
```

### API Integration

- **Image Generation APIs**: DALL-E, Stable Diffusion, or Midjourney
- **Text-to-Speech APIs**: ElevenLabs, Google TTS, or Amazon Polly
- **Stock Asset APIs**: Pexels, Unsplash, or similar for stock footage/images

## 3. Video Editing Module

### Class Structure

```python
class VideoEditor:
    def __init__(self, config=None):
        self.config = config or {}
        # Initialize video editing tools
        
    def compose_assets(self, script, visuals, audio):
        """Combine visual and audio elements according to script"""
        # Implementation details
        
    def add_captions(self, video, script):
        """Add captions/subtitles to the video"""
        # Implementation details
        
    def apply_effects(self, video, theme_info):
        """Add transitions, effects based on theme"""
        # Implementation details
        
    def convert_format(self, video):
        """Ensure video meets YouTube Shorts specifications"""
        # Implementation details
        
    def create_video(self, content_assets):
        """Main method that creates the final video"""
        composed = self.compose_assets(
            content_assets["script"],
            content_assets["visuals"],
            content_assets["audio"]
        )
        
        with_captions = self.add_captions(composed, content_assets["script"])
        with_effects = self.apply_effects(with_captions, content_assets.get("theme"))
        final_video = self.convert_format(with_effects)
        
        return {
            "video_path": final_video,
            "duration": self._get_duration(final_video),
            "resolution": self._get_resolution(final_video)
        }
```

### Library Dependencies

- **MoviePy**: Core video editing functionality
- **OpenCV**: Image processing and effects
- **FFMPEG**: Video encoding and format conversion
- **Pillow**: Image manipulation for captions and overlays

## 4. Upload Automation Module

### Class Structure

```python
class YouTubeUploader:
    def __init__(self, config=None):
        self.config = config or {}
        # Initialize YouTube API client
        
    def authenticate(self):
        """Authenticate with YouTube API"""
        # Implementation details
        
    def generate_metadata(self, content_plan, keywords):
        """Generate title, description, and tags"""
        # Implementation details
        
    def upload_video(self, video_path, metadata):
        """Upload video to YouTube"""
        # Implementation details
        
    def track_status(self, upload_id):
        """Track upload progress and status"""
        # Implementation details
        
    def publish(self, video_info, content_plan, keywords):
        """Main method that handles the entire upload process"""
        self.authenticate()
        
        metadata = self.generate_metadata(content_plan, keywords)
        upload_id = self.upload_video(video_info["video_path"], metadata)
        status = self.track_status(upload_id)
        
        return {
            "video_url": f"https://youtube.com/shorts/{status['id']}",
            "status": status["status"],
            "metadata": metadata
        }
```

### API Integration

- **YouTube Data API v3**: For video uploads and metadata management
- **OAuth 2.0**: For authentication with YouTube

## 5. Main Controller

### Class Structure

```python
class YouTubeShortsAgent:
    def __init__(self, config_path=None):
        self.config = self._load_config(config_path)
        self.prompt_processor = PromptProcessor(self.config.get("prompt_processing"))
        self.content_generator = ContentGenerator(self.config.get("content_generation"))
        self.video_editor = VideoEditor(self.config.get("video_editing"))
        self.uploader = YouTubeUploader(self.config.get("upload"))
        
    def _load_config(self, config_path):
        """Load configuration from file"""
        # Implementation details
        
    def generate_short(self, prompt_text):
        """Generate a YouTube Short from a text prompt"""
        # Process the prompt
        processed = self.prompt_processor.generate_content_plan(prompt_text)
        
        # Generate content assets
        content_assets = self.content_generator.generate_content(
            processed["content_plan"], 
            processed["theme"]
        )
        
        # Create the video
        video_info = self.video_editor.create_video(content_assets)
        
        return {
            "prompt": prompt_text,
            "content_plan": processed["content_plan"],
            "video_path": video_info["video_path"],
            "keywords": processed["keywords"]
        }
    
    def upload_short(self, short_info):
        """Upload a generated Short to YouTube"""
        upload_result = self.uploader.publish(
            {"video_path": short_info["video_path"]},
            short_info["content_plan"],
            short_info["keywords"]
        )
        
        return upload_result
    
    def create_and_upload(self, prompt_text):
        """Generate and upload a YouTube Short in one operation"""
        short_info = self.generate_short(prompt_text)
        upload_result = self.upload_short(short_info)
        
        return {
            "prompt": prompt_text,
            "video_url": upload_result["video_url"],
            "status": upload_result["status"]
        }
```

## Configuration Schema

```json
{
  "prompt_processing": {
    "api_key": "your-openai-api-key",
    "model": "gpt-4",
    "enhancement_level": "detailed"
  },
  "content_generation": {
    "image_api": {
      "provider": "stable-diffusion",
      "api_key": "your-sd-api-key"
    },
    "tts_api": {
      "provider": "elevenlabs",
      "api_key": "your-elevenlabs-api-key",
      "voice_id": "voice-id"
    },
    "stock_assets": {
      "provider": "pexels",
      "api_key": "your-pexels-api-key"
    }
  },
  "video_editing": {
    "style": "dynamic",
    "caption_style": {
      "font": "Arial",
      "size": 24,
      "color": "#FFFFFF",
      "background": "#000000AA"
    },
    "transitions": ["fade", "slide"],
    "effects": ["zoom", "pan"]
  },
  "upload": {
    "credentials_file": "path/to/youtube-credentials.json",
    "default_privacy": "public",
    "category_id": "22",
    "auto_tags": true
  }
}
```

## Error Handling Strategy

- **Input Validation**: Validate all inputs before processing
- **Graceful Degradation**: Fall back to simpler methods if advanced features fail
- **Comprehensive Logging**: Log all operations for debugging
- **Retry Mechanism**: Implement retries for API calls and uploads
- **User Feedback**: Provide clear error messages and suggestions

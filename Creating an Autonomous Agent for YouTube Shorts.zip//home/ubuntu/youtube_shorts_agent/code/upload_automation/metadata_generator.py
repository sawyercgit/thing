"""
Metadata Generator Module for YouTube Shorts Agent

This module handles the generation of metadata (title, description, tags)
for YouTube Shorts videos based on the content.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

class MetadataGenerator:
    """
    Generates metadata for YouTube Shorts videos
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the MetadataGenerator with configuration
        
        Args:
            config: Configuration dictionary with settings for metadata generation
        """
        self.config = config or {}
        
        # Default metadata settings
        self.default_settings = {
            "title_max_length": 100,  # YouTube title limit
            "description_max_length": 5000,  # YouTube description limit
            "tags_max_count": 15,  # Reasonable limit for tags
            "hashtags_count": 3,  # Number of hashtags to include
            "include_call_to_action": True,
            "include_source_attribution": True
        }
        
        # Override defaults with config if provided
        self.settings = {**self.default_settings, **self.config.get("metadata_settings", {})}
        
        # Create output directory for metadata
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/metadata"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _generate_title(self, content_info: Dict[str, Any]) -> str:
        """
        Generate an engaging title for the YouTube Short
        
        Args:
            content_info: Information about the content
            
        Returns:
            Generated title
        """
        # Extract relevant information
        original_title = content_info.get("title", "")
        theme = content_info.get("theme", "")
        tone = content_info.get("tone", "")
        
        # If we already have a good title, use it with minor modifications
        if original_title:
            # Add attention-grabbing prefixes based on theme and tone
            prefixes = []
            
            if theme == "educational":
                prefixes = ["Did You Know: ", "Fascinating: ", "Mind-Blowing: ", "Unbelievable: "]
            elif theme == "entertainment":
                prefixes = ["Watch This: ", "OMG: ", "You Won't Believe: ", "Incredible: "]
            elif theme == "tutorial":
                prefixes = ["How To: ", "Quick Tip: ", "Easy Way To: ", "Learn This: "]
            elif theme == "comedy":
                prefixes = ["Hilarious: ", "LOL: ", "Funny: ", "Wait For It: "]
            else:
                prefixes = ["Amazing: ", "Wow: ", "Must See: ", "Check This Out: "]
                
            # Select a random prefix
            prefix = random.choice(prefixes) if random.random() > 0.3 else ""
            
            # Ensure title is within max length
            max_title_length = self.settings["title_max_length"]
            if len(prefix + original_title) > max_title_length:
                # Truncate the original title to fit with the prefix
                truncated_length = max_title_length - len(prefix) - 3  # 3 for "..."
                title = prefix + original_title[:truncated_length] + "..."
            else:
                title = prefix + original_title
                
            return title
            
        # If no original title, create a generic one
        return "Amazing Facts You Need to Know"
        
    def _generate_description(self, content_info: Dict[str, Any], script_content: str) -> str:
        """
        Generate a description for the YouTube Short
        
        Args:
            content_info: Information about the content
            script_content: Content of the script
            
        Returns:
            Generated description
        """
        # Extract relevant information
        title = content_info.get("title", "")
        theme = content_info.get("theme", "")
        tone = content_info.get("tone", "")
        key_points = content_info.get("key_points", [])
        
        # Start with a brief introduction
        description = f"🎬 {title}\n\n"
        
        # Add a brief summary based on the script
        if script_content:
            # Use the first few sentences of the script as a summary
            sentences = script_content.replace("!", ".").replace("?", ".").split(".")
            summary_sentences = [s.strip() for s in sentences[:3] if s.strip()]
            summary = ". ".join(summary_sentences)
            
            if summary:
                description += f"{summary}\n\n"
                
        # Add key points if available
        if key_points:
            description += "In this short video:\n"
            for point in key_points[:5]:  # Limit to 5 points
                description += f"• {point}\n"
            description += "\n"
            
        # Add call to action
        if self.settings["include_call_to_action"]:
            cta_options = [
                "👍 Like this video if you found it interesting!",
                "🔔 Subscribe for more amazing content!",
                "💬 Comment below with your thoughts!",
                "📱 Follow for daily shorts like this!",
                "🔄 Share with friends who would enjoy this!"
            ]
            
            # Select 2 random CTAs
            selected_ctas = random.sample(cta_options, 2)
            description += f"{selected_ctas[0]}\n{selected_ctas[1]}\n\n"
            
        # Add source attribution if enabled
        if self.settings["include_source_attribution"]:
            description += "🤖 This content was created by the YouTube Shorts Autonomous Agent.\n\n"
            
        # Add hashtags
        hashtags = self._generate_hashtags(content_info)
        description += " ".join(hashtags)
        
        # Ensure description is within max length
        max_desc_length = self.settings["description_max_length"]
        if len(description) > max_desc_length:
            # Truncate the description to fit
            description = description[:max_desc_length - 3] + "..."
            
        return description
        
    def _generate_tags(self, content_info: Dict[str, Any]) -> List[str]:
        """
        Generate tags for the YouTube Short
        
        Args:
            content_info: Information about the content
            
        Returns:
            List of tags
        """
        # Extract relevant information
        title = content_info.get("title", "")
        theme = content_info.get("theme", "")
        tone = content_info.get("tone", "")
        keywords = content_info.get("keywords", [])
        
        # Start with keywords if available
        tags = list(keywords)
        
        # Add theme and tone as tags
        if theme:
            tags.append(theme)
        if tone:
            tags.append(tone)
            
        # Add "shorts" related tags
        shorts_tags = ["shorts", "youtubeshorts", "shortsvideo"]
        tags.extend(shorts_tags)
        
        # Add generic popular tags based on theme
        if theme == "educational":
            generic_tags = ["facts", "didyouknow", "learning", "education", "knowledge"]
        elif theme == "entertainment":
            generic_tags = ["fun", "entertainment", "amazing", "wow", "viral"]
        elif theme == "tutorial":
            generic_tags = ["howto", "tutorial", "tips", "tricks", "learn"]
        elif theme == "comedy":
            generic_tags = ["funny", "comedy", "humor", "laugh", "jokes"]
        else:
            generic_tags = ["interesting", "viral", "trending", "popular", "mustwatch"]
            
        tags.extend(generic_tags)
        
        # Remove duplicates and convert to lowercase
        tags = list(set([tag.lower() for tag in tags]))
        
        # Limit to max count
        max_tags = self.settings["tags_max_count"]
        tags = tags[:max_tags]
        
        return tags
        
    def _generate_hashtags(self, content_info: Dict[str, Any]) -> List[str]:
        """
        Generate hashtags for the YouTube Short
        
        Args:
            content_info: Information about the content
            
        Returns:
            List of hashtags
        """
        # Get tags and convert to hashtags
        tags = self._generate_tags(content_info)
        
        # Select a subset of tags to convert to hashtags
        count = min(self.settings["hashtags_count"], len(tags))
        selected_tags = random.sample(tags, count)
        
        # Always include #shorts
        if "shorts" not in selected_tags:
            selected_tags.append("shorts")
            
        # Convert to hashtags
        hashtags = [f"#{tag.replace(' ', '')}" for tag in selected_tags]
        
        return hashtags
        
    def generate_metadata(self, content_package_path: str, script_path: str) -> Dict[str, Any]:
        """
        Generate metadata for a YouTube Short
        
        Args:
            content_package_path: Path to the content package JSON file
            script_path: Path to the script file
            
        Returns:
            Dictionary with metadata information
        """
        try:
            # Load the content package
            with open(content_package_path, 'r') as f:
                content_package = json.load(f)
                
            # Extract content information
            content_info = {
                "title": content_package.get("metadata", {}).get("title", ""),
                "theme": content_package.get("metadata", {}).get("theme", ""),
                "tone": content_package.get("metadata", {}).get("tone", ""),
                "key_points": content_package.get("content_plan", {}).get("content_plan", {}).get("key_points", []),
                "keywords": content_package.get("content_plan", {}).get("keywords", [])
            }
            
            # Read the script content
            script_content = ""
            try:
                with open(script_path, 'r') as f:
                    script_content = f.read()
            except Exception as e:
                print(f"Warning: Could not read script from {script_path}: {e}")
                
            # Generate metadata
            title = self._generate_title(content_info)
            description = self._generate_description(content_info, script_content)
            tags = self._generate_tags(content_info)
            hashtags = self._generate_hashtags(content_info)
            
            # Create metadata object
            metadata = {
                "title": title,
                "description": description,
                "tags": tags,
                "hashtags": hashtags,
                "category": "22",  # 22 is "People & Blogs" on YouTube
                "privacy_status": "public",
                "made_for_kids": False,
                "generated_at": datetime.now().isoformat()
            }
            
            # Save metadata to file
            sequence_id = content_package.get("id", f"short_{random.randint(1000, 9999)}")
            output_path = os.path.join(self.output_dir, f"{sequence_id}_metadata.json")
            
            with open(output_path, 'w') as f:
                json.dump(metadata, f, indent=2)
                
            print(f"Metadata saved to: {output_path}")
            
            return {
                "metadata_path": output_path,
                "sequence_id": sequence_id,
                "title": title,
                "description": description[:100] + "..." if len(description) > 100 else description,
                "tags_count": len(tags),
                "hashtags": hashtags
            }
        except Exception as e:
            print(f"Error generating metadata from {content_package_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{random.randint(1000, 9999)}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if paths were provided as command-line arguments
    if len(sys.argv) > 2:
        content_package_path = sys.argv[1]
        script_path = sys.argv[2]
    else:
        print("No paths provided. Using mock paths.")
        content_package_path = "/home/ubuntu/youtube_shorts_agent/generated_content/short_1234_content_package.json"
        script_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts/script_1234.txt"
        
        # Create mock files for testing
        os.makedirs(os.path.dirname(content_package_path), exist_ok=True)
        os.makedirs(os.path.dirname(script_path), exist_ok=True)
        
        # Create a mock script
        with open(script_path, 'w') as f:
            f.write("Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. ")
            f.write("A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. ")
            f.write("Like and follow for more amazing facts!")
            
        # Create a mock content package
        mock_content_package = {
            "id": "short_1234",
            "prompt": "Create a short about amazing space exploration facts",
            "content_plan": {
                "content_plan": {
                    "title": "Amazing Facts About Space Exploration",
                    "theme": "educational",
                    "tone": "fascinating",
                    "key_points": [
                        "The International Space Station travels at 17,500 mph",
                        "A day on Venus is longer than a year on Venus",
                        "The footprints on the Moon will last for 100 million years"
                    ]
                },
                "keywords": ["space", "exploration", "facts", "amazing", "educational"]
            },
            "metadata": {
                "title": "Amazing Facts About Space Exploration",
                "theme": "educational",
                "tone": "fascinating"
            }
        }
        
        with open(content_package_path, 'w') as f:
            json.dump(mock_content_package, f, indent=2)
        
    metadata_generator = MetadataGenerator()
    result = metadata_generator.generate_metadata(content_package_path, script_path)
    
    print("\nMetadata Generation Complete!")
    print(f"Sequence ID: {result.get('sequence_id')}")
    print(f"Title: {result.get('title')}")
    print(f"Description: {result.get('description')}")
    print(f"Tags Count: {result.get('tags_count', 0)}")
    print(f"Hashtags: {' '.join(result.get('hashtags', []))}")
    print(f"Metadata Path: {result.get('metadata_path', 'N/A')}")

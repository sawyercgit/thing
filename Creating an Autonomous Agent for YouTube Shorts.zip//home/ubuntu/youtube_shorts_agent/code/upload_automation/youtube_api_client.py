"""
YouTube API Client Module for YouTube Shorts Agent

This module handles the authentication and upload of videos to YouTube
using the YouTube Data API.
"""

import os
import json
import time
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

class YouTubeAPIClient:
    """
    Handles authentication and upload of videos to YouTube
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the YouTubeAPIClient with configuration
        
        Args:
            config: Configuration dictionary with settings for YouTube API
        """
        self.config = config or {}
        
        # Default API settings
        self.default_settings = {
            "credentials_file": os.environ.get("YOUTUBE_CREDENTIALS", ""),
            "token_file": os.environ.get("YOUTUBE_TOKEN", ""),
            "api_key": os.environ.get("YOUTUBE_API_KEY", ""),
            "client_id": os.environ.get("YOUTUBE_CLIENT_ID", ""),
            "client_secret": os.environ.get("YOUTUBE_CLIENT_SECRET", ""),
            "upload_retry_count": 3,
            "upload_chunk_size": 1024 * 1024 * 5  # 5MB
        }
        
        # Override defaults with config if provided
        self.settings = {**self.default_settings, **self.config.get("api_settings", {})}
        
        # Create output directory for upload logs
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/upload_logs"
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Flag to track authentication status
        self.authenticated = False
        
    def authenticate(self) -> bool:
        """
        Authenticate with the YouTube API
        
        Returns:
            True if authentication was successful, False otherwise
        """
        # In a real implementation, this would use the YouTube Data API
        # to authenticate with OAuth 2.0
        # For now, we'll just simulate the authentication process
        
        try:
            # Check if we have the necessary credentials
            if not self.settings["api_key"] and not (self.settings["client_id"] and self.settings["client_secret"]):
                print("Error: No API key or OAuth credentials provided")
                return False
                
            # Simulate authentication process
            print("Authenticating with YouTube API...")
            time.sleep(1)  # Simulate network delay
            
            # In a real implementation, this would verify the credentials
            # and obtain an access token
            
            # For now, just set the authenticated flag to True
            self.authenticated = True
            
            print("Authentication successful!")
            return True
        except Exception as e:
            print(f"Error authenticating with YouTube API: {e}")
            return False
            
    def _validate_metadata(self, metadata: Dict[str, Any]) -> bool:
        """
        Validate that the metadata has all required fields
        
        Args:
            metadata: Metadata dictionary
            
        Returns:
            True if valid, False otherwise
        """
        required_fields = ["title", "description", "tags", "category", "privacy_status"]
        for field in required_fields:
            if field not in metadata:
                print(f"Error: Missing required metadata field '{field}'")
                return False
                
        # Check title length
        if len(metadata["title"]) > 100:
            print(f"Error: Title exceeds maximum length of 100 characters")
            return False
            
        # Check description length
        if len(metadata["description"]) > 5000:
            print(f"Error: Description exceeds maximum length of 5000 characters")
            return False
            
        return True
        
    def upload_video(self, video_path: str, metadata_path: str) -> Dict[str, Any]:
        """
        Upload a video to YouTube
        
        Args:
            video_path: Path to the video file
            metadata_path: Path to the metadata JSON file
            
        Returns:
            Dictionary with upload information
        """
        try:
            # Check if we're authenticated
            if not self.authenticated:
                if not self.authenticate():
                    raise ValueError("Authentication failed")
                    
            # Load the metadata
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                
            # Validate the metadata
            if not self._validate_metadata(metadata):
                raise ValueError("Invalid metadata")
                
            # In a real implementation, this would use the YouTube Data API
            # to upload the video and set the metadata
            # For now, we'll just simulate the upload process
            
            print(f"Uploading video: {video_path}")
            print(f"Title: {metadata['title']}")
            print(f"Description: {metadata['description'][:50]}...")
            print(f"Tags: {', '.join(metadata['tags'][:5])}...")
            
            # Simulate upload process
            # In a real implementation, this would show progress
            upload_time = random.randint(5, 15)  # Simulate upload time in seconds
            print(f"Simulating upload (would take {upload_time} seconds in real implementation)...")
            
            # Generate a mock video ID
            video_id = f"YT{random.randint(10000000, 99999999)}"
            
            # Generate a mock video URL
            video_url = f"https://www.youtube.com/shorts/{video_id}"
            
            # Create upload log
            upload_log = {
                "video_id": video_id,
                "video_url": video_url,
                "title": metadata["title"],
                "description": metadata["description"],
                "tags": metadata["tags"],
                "category": metadata["category"],
                "privacy_status": metadata["privacy_status"],
                "upload_time": datetime.now().isoformat(),
                "status": "success"
            }
            
            # Save upload log to file
            sequence_id = os.path.basename(metadata_path).split("_")[0]
            if not sequence_id:
                sequence_id = f"upload_{random.randint(1000, 9999)}"
                
            output_path = os.path.join(self.output_dir, f"{sequence_id}_upload_log.json")
            
            with open(output_path, 'w') as f:
                json.dump(upload_log, f, indent=2)
                
            print(f"Upload log saved to: {output_path}")
            
            return {
                "upload_log_path": output_path,
                "video_id": video_id,
                "video_url": video_url,
                "title": metadata["title"],
                "status": "success"
            }
        except Exception as e:
            print(f"Error uploading video: {e}")
            
            # Create error log
            error_log = {
                "error": str(e),
                "video_path": video_path,
                "metadata_path": metadata_path,
                "upload_time": datetime.now().isoformat(),
                "status": "error"
            }
            
            # Save error log to file
            sequence_id = os.path.basename(metadata_path).split("_")[0] if metadata_path else "unknown"
            output_path = os.path.join(self.output_dir, f"{sequence_id}_upload_error.json")
            
            with open(output_path, 'w') as f:
                json.dump(error_log, f, indent=2)
                
            return {
                "error": str(e),
                "upload_log_path": output_path,
                "status": "error"
            }
            
    def check_upload_status(self, video_id: str) -> Dict[str, Any]:
        """
        Check the status of an uploaded video
        
        Args:
            video_id: YouTube video ID
            
        Returns:
            Dictionary with status information
        """
        try:
            # In a real implementation, this would use the YouTube Data API
            # to check the status of the uploaded video
            # For now, we'll just simulate the status check
            
            print(f"Checking status of video: {video_id}")
            
            # Simulate status check
            time.sleep(1)  # Simulate network delay
            
            # Generate a mock status
            statuses = ["processing", "processed", "published"]
            status = random.choice(statuses)
            
            return {
                "video_id": video_id,
                "status": status,
                "check_time": datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Error checking upload status: {e}")
            return {
                "video_id": video_id,
                "status": "error",
                "error": str(e),
                "check_time": datetime.now().isoformat()
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if paths were provided as command-line arguments
    if len(sys.argv) > 2:
        video_path = sys.argv[1]
        metadata_path = sys.argv[2]
    else:
        print("No paths provided. Using mock paths.")
        video_path = "/home/ubuntu/youtube_shorts_agent/final_videos/seq_1234_final_video.txt"
        metadata_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/metadata/short_1234_metadata.json"
        
        # Create mock files for testing
        os.makedirs(os.path.dirname(video_path), exist_ok=True)
        os.makedirs(os.path.dirname(metadata_path), exist_ok=True)
        
        # Create a mock video file (just a text file for simulation)
        with open(video_path, 'w') as f:
            f.write("MOCK VIDEO FILE\n")
            f.write("This is a placeholder for a real video file.\n")
            
        # Create a mock metadata file
        mock_metadata = {
            "title": "Amazing Facts About Space Exploration",
            "description": "Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. Like and follow for more amazing facts!",
            "tags": ["space", "exploration", "facts", "amazing", "educational", "shorts", "youtubeshorts"],
            "hashtags": ["#space", "#facts", "#shorts"],
            "category": "22",  # 22 is "People & Blogs" on YouTube
            "privacy_status": "public",
            "made_for_kids": False,
            "generated_at": datetime.now().isoformat()
        }
        
        with open(metadata_path, 'w') as f:
            json.dump(mock_metadata, f, indent=2)
        
    youtube_client = YouTubeAPIClient()
    
    # Authenticate
    if youtube_client.authenticate():
        # Upload video
        result = youtube_client.upload_video(video_path, metadata_path)
        
        print("\nUpload Result:")
        if result.get("status") == "success":
            print(f"Video ID: {result.get('video_id')}")
            print(f"Video URL: {result.get('video_url')}")
            print(f"Title: {result.get('title')}")
            print(f"Status: {result.get('status')}")
            
            # Check upload status
            status_result = youtube_client.check_upload_status(result.get('video_id'))
            print(f"\nStatus Check Result:")
            print(f"Status: {status_result.get('status')}")
            print(f"Check Time: {status_result.get('check_time')}")
        else:
            print(f"Error: {result.get('error')}")
            print(f"Upload Log: {result.get('upload_log_path')}")
    else:
        print("Authentication failed. Cannot upload video.")

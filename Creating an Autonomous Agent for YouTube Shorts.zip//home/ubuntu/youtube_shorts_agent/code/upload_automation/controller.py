"""
Upload Automation Controller Module for YouTube Shorts Agent

This module integrates the metadata generator and YouTube API client
to create a complete upload automation pipeline for YouTube Shorts.
"""

import os
import json
import sys
from typing import Dict, List, Any, Optional

# Import the upload automation components
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from metadata_generator import MetadataGenerator
from youtube_api_client import YouTubeAPIClient

class UploadAutomationController:
    """
    Main controller for the upload automation process
    Integrates metadata generation and YouTube API client
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the controller with configuration
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = self._load_config(config_path)
        
        # Initialize upload automation components
        self.metadata_generator = MetadataGenerator(self.config.get("metadata_generation"))
        self.youtube_client = YouTubeAPIClient(self.config.get("youtube_api"))
        
        # Create output directory for upload results
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/upload_results"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """
        Load configuration from file or use defaults
        
        Args:
            config_path: Path to configuration file
            
        Returns:
            Configuration dictionary
        """
        default_config = {
            "metadata_generation": {
                "metadata_settings": {
                    "title_max_length": 100,
                    "description_max_length": 5000,
                    "tags_max_count": 15,
                    "hashtags_count": 3,
                    "include_call_to_action": True,
                    "include_source_attribution": True
                }
            },
            "youtube_api": {
                "api_settings": {
                    "credentials_file": os.environ.get("YOUTUBE_CREDENTIALS", ""),
                    "token_file": os.environ.get("YOUTUBE_TOKEN", ""),
                    "api_key": os.environ.get("YOUTUBE_API_KEY", ""),
                    "client_id": os.environ.get("YOUTUBE_CLIENT_ID", ""),
                    "client_secret": os.environ.get("YOUTUBE_CLIENT_SECRET", ""),
                    "upload_retry_count": 3,
                    "upload_chunk_size": 1024 * 1024 * 5  # 5MB
                }
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    
                # Merge user config with defaults
                for section, settings in user_config.items():
                    if section in default_config:
                        if isinstance(default_config[section], dict) and isinstance(settings, dict):
                            for subsection, subsettings in settings.items():
                                if subsection in default_config[section]:
                                    if isinstance(default_config[section][subsection], dict) and isinstance(subsettings, dict):
                                        default_config[section][subsection].update(subsettings)
                                    else:
                                        default_config[section][subsection] = subsettings
                                else:
                                    default_config[section][subsection] = subsettings
                        else:
                            default_config[section] = settings
                    else:
                        default_config[section] = settings
            except Exception as e:
                print(f"Error loading config from {config_path}: {e}")
                print("Using default configuration")
                
        return default_config
    
    def upload_video(self, video_path: str, content_package_path: str, script_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Upload a YouTube Short video with generated metadata
        
        Args:
            video_path: Path to the video file
            content_package_path: Path to the content package JSON file
            script_path: Path to the script file (optional, will be extracted from content package if not provided)
            
        Returns:
            Dictionary with upload information
        """
        try:
            # Load the content package
            with open(content_package_path, 'r') as f:
                content_package = json.load(f)
                
            # Extract script path if not provided
            if not script_path:
                script_path = content_package.get("assets", {}).get("script", "")
                if not script_path:
                    raise ValueError("Script path not found in content package")
                    
            # Step 1: Generate metadata
            print("Step 1: Generating metadata...")
            metadata_info = self.metadata_generator.generate_metadata(content_package_path, script_path)
            
            if "error" in metadata_info:
                raise ValueError(f"Error in metadata generation: {metadata_info['error']}")
                
            metadata_path = metadata_info["metadata_path"]
            
            # Step 2: Authenticate with YouTube API
            print("Step 2: Authenticating with YouTube API...")
            if not self.youtube_client.authenticate():
                raise ValueError("YouTube API authentication failed")
                
            # Step 3: Upload video
            print("Step 3: Uploading video...")
            upload_result = self.youtube_client.upload_video(video_path, metadata_path)
            
            if upload_result.get("status") != "success":
                raise ValueError(f"Error in video upload: {upload_result.get('error')}")
                
            # Step 4: Check upload status
            print("Step 4: Checking upload status...")
            status_result = self.youtube_client.check_upload_status(upload_result.get("video_id"))
            
            # Create a summary of the upload process
            sequence_id = metadata_info["sequence_id"]
            output_filename = f"{sequence_id}_upload_result.json"
            output_path = os.path.join(self.output_dir, output_filename)
            
            upload_summary = {
                "sequence_id": sequence_id,
                "video_id": upload_result.get("video_id"),
                "video_url": upload_result.get("video_url"),
                "title": metadata_info["title"],
                "metadata": {
                    "path": metadata_path,
                    "hashtags": metadata_info["hashtags"],
                    "tags_count": metadata_info["tags_count"]
                },
                "upload_status": status_result.get("status"),
                "upload_time": upload_result.get("upload_time", ""),
                "content_package": content_package_path,
                "script": script_path,
                "video_file": video_path
            }
            
            with open(output_path, 'w') as f:
                json.dump(upload_summary, f, indent=2)
                
            print(f"Upload result saved to: {output_path}")
            
            return {
                "result_path": output_path,
                "video_id": upload_result.get("video_id"),
                "video_url": upload_result.get("video_url"),
                "title": metadata_info["title"],
                "status": status_result.get("status")
            }
        except Exception as e:
            print(f"Error uploading video: {e}")
            
            # Create error summary
            error_summary = {
                "error": str(e),
                "video_path": video_path,
                "content_package_path": content_package_path,
                "script_path": script_path
            }
            
            # Save error summary to file
            output_path = os.path.join(self.output_dir, f"error_{os.path.basename(video_path).split('_')[0]}.json")
            
            with open(output_path, 'w') as f:
                json.dump(error_summary, f, indent=2)
                
            return {
                "error": str(e),
                "result_path": output_path,
                "status": "error"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if paths were provided as command-line arguments
    if len(sys.argv) > 2:
        video_path = sys.argv[1]
        content_package_path = sys.argv[2]
        script_path = sys.argv[3] if len(sys.argv) > 3 else None
    else:
        print("No paths provided. Using mock paths.")
        video_path = "/home/ubuntu/youtube_shorts_agent/final_videos/seq_1234_final_video.txt"
        content_package_path = "/home/ubuntu/youtube_shorts_agent/generated_content/short_1234_content_package.json"
        script_path = None
        
        # Create mock files for testing
        os.makedirs(os.path.dirname(video_path), exist_ok=True)
        os.makedirs(os.path.dirname(content_package_path), exist_ok=True)
        
        # Create a mock video file (just a text file for simulation)
        with open(video_path, 'w') as f:
            f.write("MOCK VIDEO FILE\n")
            f.write("This is a placeholder for a real video file.\n")
            
        # Create a mock content package
        script_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts"
        os.makedirs(script_dir, exist_ok=True)
        script_path = os.path.join(script_dir, "script_1234.txt")
        
        with open(script_path, 'w') as f:
            f.write("Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. ")
            f.write("A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. ")
            f.write("Like and follow for more amazing facts!")
            
        mock_content_package = {
            "id": "short_1234",
            "prompt": "Create a short about amazing space exploration facts",
            "content_plan": {
                "content_plan": {
                    "title": "Amazing Facts About Space Exploration",
                    "theme": "educational",
                    "tone": "fascinating",
                    "key_points": [
                        "The International Space Station travels at 17,500 mph",
                        "A day on Venus is longer than a year on Venus",
                        "The footprints on the Moon will last for 100 million years"
                    ]
                },
                "keywords": ["space", "exploration", "facts", "amazing", "educational"]
            },
            "assets": {
                "script": script_path
            },
            "metadata": {
                "title": "Amazing Facts About Space Exploration",
                "theme": "educational",
                "tone": "fascinating"
            }
        }
        
        with open(content_package_path, 'w') as f:
            json.dump(mock_content_package, f, indent=2)
        
    controller = UploadAutomationController()
    result = controller.upload_video(video_path, content_package_path, script_path)
    
    print("\nUpload Process Complete!")
    if result.get("status") != "error":
        print(f"Video ID: {result.get('video_id')}")
        print(f"Video URL: {result.get('video_url')}")
        print(f"Title: {result.get('title')}")
        print(f"Status: {result.get('status')}")
        print(f"Result Path: {result.get('result_path')}")
    else:
        print(f"Error: {result.get('error')}")
        print(f"Result Path: {result.get('result_path')}")

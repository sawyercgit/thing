"""
Video Editing Controller Module for YouTube Shorts Agent

This module integrates all video editing components to create a complete
video editing pipeline for YouTube Shorts.
"""

import os
import json
import sys
from typing import Dict, List, Any, Optional

# Import the video editing components
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from asset_compositor import AssetCompositor
from format_converter import FormatConverter
from caption_generator import CaptionGenerator
from effect_applier import EffectApplier

class VideoEditingController:
    """
    Main controller for the video editing process
    Integrates all video editing components into a complete pipeline
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the controller with configuration
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = self._load_config(config_path)
        
        # Initialize video editing components
        self.asset_compositor = AssetCompositor(self.config.get("asset_composition"))
        self.format_converter = FormatConverter(self.config.get("format_conversion"))
        self.caption_generator = CaptionGenerator(self.config.get("caption_generation"))
        self.effect_applier = EffectApplier(self.config.get("effect_application"))
        
        # Create output directory for final videos
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/final_videos"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """
        Load configuration from file or use defaults
        
        Args:
            config_path: Path to configuration file
            
        Returns:
            Configuration dictionary
        """
        default_config = {
            "asset_composition": {},
            "format_conversion": {
                "format_settings": {
                    "aspect_ratio": "9:16",
                    "resolution": "1080x1920",
                    "fps": 30,
                    "bitrate": "8M",
                    "codec": "h264",
                    "format": "mp4"
                }
            },
            "caption_generation": {
                "caption_style": {
                    "font": "Arial",
                    "size": 36,
                    "color": "#FFFFFF",
                    "background": "#000000AA",
                    "position": "bottom",
                    "margin": 50,
                    "max_lines": 2,
                    "max_chars_per_line": 32,
                    "animation": "fade"
                }
            },
            "effect_application": {
                "effect_settings": {
                    "transitions": ["fade", "slide", "zoom"],
                    "visual_effects": ["zoom", "pan", "brightness", "contrast"],
                    "text_effects": ["fade", "slide", "pop"],
                    "intensity": "medium"
                }
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    
                # Merge user config with defaults
                for section, settings in user_config.items():
                    if section in default_config:
                        if isinstance(default_config[section], dict) and isinstance(settings, dict):
                            for subsection, subsettings in settings.items():
                                if subsection in default_config[section]:
                                    if isinstance(default_config[section][subsection], dict) and isinstance(subsettings, dict):
                                        default_config[section][subsection].update(subsettings)
                                    else:
                                        default_config[section][subsection] = subsettings
                                else:
                                    default_config[section][subsection] = subsettings
                        else:
                            default_config[section] = settings
                    else:
                        default_config[section] = settings
            except Exception as e:
                print(f"Error loading config from {config_path}: {e}")
                print("Using default configuration")
                
        return default_config
    
    def create_video(self, content_package_path: str, script_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a YouTube Short video from a content package
        
        Args:
            content_package_path: Path to the content package JSON file
            script_path: Path to the script file (optional, will be extracted from content package if not provided)
            
        Returns:
            Dictionary with final video information
        """
        try:
            # Load the content package
            with open(content_package_path, 'r') as f:
                content_package = json.load(f)
                
            # Extract script path if not provided
            if not script_path:
                script_path = content_package.get("assets", {}).get("script", "")
                if not script_path:
                    raise ValueError("Script path not found in content package")
                    
            # Step 1: Compose assets into a sequence
            print("Step 1: Composing assets into a sequence...")
            sequence_info = self.asset_compositor.compose_sequence(content_package_path)
            
            if "error" in sequence_info:
                raise ValueError(f"Error in asset composition: {sequence_info['error']}")
                
            sequence_plan_path = sequence_info["sequence_plan_path"]
            
            # Step 2: Convert sequence to correct format
            print("Step 2: Converting sequence to correct format...")
            conversion_info = self.format_converter.convert_sequence(sequence_plan_path)
            
            if "error" in conversion_info:
                raise ValueError(f"Error in format conversion: {conversion_info['error']}")
                
            adjusted_plan_path = conversion_info["adjusted_plan_path"]
            
            # Step 3: Add captions to the video
            print("Step 3: Adding captions to the video...")
            caption_info = self.caption_generator.add_captions(adjusted_plan_path, script_path)
            
            if "error" in caption_info:
                raise ValueError(f"Error in caption generation: {caption_info['error']}")
                
            captioned_plan_path = caption_info["captioned_plan_path"]
            
            # Step 4: Apply effects to the video
            print("Step 4: Applying effects to the video...")
            effect_info = self.effect_applier.apply_effects(captioned_plan_path)
            
            if "error" in effect_info:
                raise ValueError(f"Error in effect application: {effect_info['error']}")
                
            final_video_path = effect_info["final_video_path"]
            final_plan_path = effect_info["final_plan_path"]
            
            # In a real implementation, this would copy the final video to the output directory
            # For now, we'll just create a mock output file
            
            sequence_id = effect_info["sequence_id"]
            output_filename = f"{sequence_id}_final_video.txt"
            output_path = os.path.join(self.output_dir, output_filename)
            
            # Create a summary of the video creation process
            with open(output_path, 'w') as f:
                f.write(f"YOUTUBE SHORT VIDEO\n")
                f.write(f"Sequence ID: {sequence_id}\n")
                f.write(f"Title: {effect_info.get('title', 'YouTube Short')}\n")
                f.write(f"Duration: {effect_info.get('duration', 0):.1f} seconds\n")
                f.write(f"Resolution: {effect_info.get('resolution', '1080x1920')}\n")
                f.write(f"Aspect Ratio: {effect_info.get('aspect_ratio', '9:16')}\n\n")
                
                f.write(f"Creation Process:\n")
                f.write(f"1. Asset Composition: {sequence_info.get('segment_count', 0)} segments\n")
                f.write(f"2. Format Conversion: {conversion_info.get('format', 'mp4')} format\n")
                f.write(f"3. Caption Generation: {caption_info.get('caption_count', 0)} captions\n")
                f.write(f"4. Effect Application: {self.config.get('effect_application', {}).get('effect_settings', {}).get('intensity', 'medium')} intensity\n\n")
                
                f.write(f"Content Package: {content_package_path}\n")
                f.write(f"Script: {script_path}\n")
                f.write(f"Sequence Plan: {sequence_plan_path}\n")
                f.write(f"Adjusted Plan: {adjusted_plan_path}\n")
                f.write(f"Captioned Plan: {captioned_plan_path}\n")
                f.write(f"Final Plan: {final_plan_path}\n")
                
            print(f"Final video summary saved to: {output_path}")
            
            # Copy the final plan to the output directory
            output_plan_path = os.path.join(self.output_dir, f"{sequence_id}_final_plan.json")
            with open(final_plan_path, 'r') as f_in:
                with open(output_plan_path, 'w') as f_out:
                    f_out.write(f_in.read())
                    
            print(f"Final plan copied to: {output_plan_path}")
            
            return {
                "video_path": output_path,
                "plan_path": output_plan_path,
                "sequence_id": sequence_id,
                "title": effect_info.get("title", "YouTube Short"),
                "duration": effect_info.get("duration", 0),
                "resolution": effect_info.get("resolution", "1080x1920"),
                "aspect_ratio": effect_info.get("aspect_ratio", "9:16")
            }
        except Exception as e:
            print(f"Error creating video from {content_package_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{os.path.basename(content_package_path).split('_')[1] if '_' in os.path.basename(content_package_path) else 'unknown'}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if a content package path was provided as a command-line argument
    if len(sys.argv) > 1:
        content_package_path = sys.argv[1]
        script_path = sys.argv[2] if len(sys.argv) > 2 else None
    else:
        print("No content package path provided. Using a mock path.")
        content_package_path = "/home/ubuntu/youtube_shorts_agent/generated_content/short_1234_content_package.json"
        script_path = None
        
        # Create a mock content package for testing
        os.makedirs(os.path.dirname(content_package_path), exist_ok=True)
        
        # Create mock asset files
        script_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts"
        os.makedirs(script_dir, exist_ok=True)
        script_path = os.path.join(script_dir, "script_1234.txt")
        with open(script_path, 'w') as f:
            f.write("Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. ")
            f.write("A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. ")
            f.write("Like and follow for more amazing facts!")
            
        image_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/images"
        os.makedirs(image_dir, exist_ok=True)
        title_card_path = os.path.join(image_dir, "title_1234.txt")
        with open(title_card_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: Title card for 'Amazing Facts About Space' in dynamic style\n")
            f.write("STYLE: dynamic\n")
            
        point_image1_path = os.path.join(image_dir, "point1_1234.txt")
        with open(point_image1_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: The International Space Station travels at 17,500 mph in dynamic style\n")
            f.write("STYLE: dynamic\n")
            
        point_image2_path = os.path.join(image_dir, "point2_1234.txt")
        with open(point_image2_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: A day on Venus is longer than a year on Venus in dynamic style\n")
            f.write("STYLE: dynamic\n")
            
        point_image3_path = os.path.join(image_dir, "point3_1234.txt")
        with open(point_image3_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: The footprints on the Moon will last for 100 million years in dynamic style\n")
            f.write("STYLE: dynamic\n")
            
        audio_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/audio"
        os.makedirs(audio_dir, exist_ok=True)
        voiceover_path = os.path.join(audio_dir, "speech_1234.txt")
        with open(voiceover_path, 'w') as f:
            f.write("VOICE: default\n\n")
            f.write("Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. ")
            f.write("A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. ")
            f.write("Like and follow for more amazing facts!")
            
        music_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/music"
        os.makedirs(music_dir, exist_ok=True)
        music_path = os.path.join(music_dir, "music_1234.txt")
        with open(music_path, 'w') as f:
            f.write("BACKGROUND MUSIC\n")
            f.write("Mood: inspiring\n")
            f.write("Duration: 30 seconds\n")
            f.write("Volume: 20% (background level)\n")
            
        # Create the mock content package
        mock_content_package = {
            "id": "short_1234",
            "prompt": "Create a short about amazing space exploration facts",
            "content_plan": {
                "original_prompt": "Create a short about amazing space exploration facts",
                "content_plan": {
                    "title": "Amazing Facts About Space Exploration",
                    "theme": "educational",
                    "tone": "fascinating",
                    "key_points": [
                        "The International Space Station travels at 17,500 mph",
                        "A day on Venus is longer than a year on Venus",
                        "The footprints on the Moon will last for 100 million years"
                    ],
                    "visuals": ["space", "planets", "astronauts", "rockets"],
                    "audio_mood": "inspiring"
                },
                "theme_info": {
                    "theme": "educational",
                    "tone": "fascinating",
                    "style": "dynamic"
                },
                "keywords": ["space", "exploration", "facts", "amazing", "educational"]
            },
            "assets": {
                "script": script_path,
                "title_card": title_card_path,
                "point_images": [point_image1_path, point_image2_path, point_image3_path],
                "stock_images": [],
                "stock_videos": [],
                "voiceover": voiceover_path,
                "background_music": music_path
            },
            "metadata": {
                "title": "Amazing Facts About Space Exploration",
                "estimated_duration": 30,
                "theme": "educational",
                "tone": "fascinating"
            }
        }
        
        with open(content_package_path, 'w') as f:
            json.dump(m<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>
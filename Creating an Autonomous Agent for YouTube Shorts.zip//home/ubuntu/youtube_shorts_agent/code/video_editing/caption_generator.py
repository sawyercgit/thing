"""
Caption Generator Module for YouTube Shorts Agent

This module handles the generation and overlay of captions/subtitles
for YouTube Shorts videos.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

class CaptionGenerator:
    """
    Generates and overlays captions/subtitles for YouTube Shorts videos
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the CaptionGenerator with configuration
        
        Args:
            config: Configuration dictionary with settings for caption generation
        """
        self.config = config or {}
        
        # Default caption style settings
        self.default_style = {
            "font": "Arial",
            "size": 36,
            "color": "#FFFFFF",
            "background": "#000000AA",
            "position": "bottom",
            "margin": 50,
            "max_lines": 2,
            "max_chars_per_line": 32,
            "animation": "fade"
        }
        
        # Override defaults with config if provided
        self.style = {**self.default_style, **self.config.get("caption_style", {})}
        
        # Create output directory for captioned videos
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/captioned_videos"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _extract_captions_from_script(self, script_path: str, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract caption text from script and align with video segments
        
        Args:
            script_path: Path to the script file
            segments: List of video segments from the sequence plan
            
        Returns:
            List of caption segments with text and timing information
        """
        try:
            # Read the script
            with open(script_path, 'r') as f:
                script_content = f.read()
                
            # In a real implementation, this would use NLP to split the script
            # into segments that align with the video segments
            # For now, we'll create a simplified version
            
            # Split the script into sentences
            sentences = [s.strip() for s in script_content.replace('!', '.').replace('?', '.').split('.') if s.strip()]
            
            # Distribute sentences across segments
            caption_segments = []
            
            # If we have more segments than sentences, duplicate some sentences
            while len(sentences) < len(segments):
                sentences.append(sentences[-1] if sentences else "Caption text")
                
            # If we have more sentences than segments, combine some sentences
            while len(sentences) > len(segments) * 2:
                combined = []
                for i in range(0, len(sentences), 2):
                    if i + 1 < len(sentences):
                        combined.append(f"{sentences[i]} {sentences[i+1]}")
                    else:
                        combined.append(sentences[i])
                sentences = combined
                
            # Assign sentences to segments
            sentence_index = 0
            for i, segment in enumerate(segments):
                # Determine how many sentences to use for this segment
                # based on segment duration
                segment_duration = segment.get("duration", 5.0)
                sentences_per_segment = max(1, min(3, int(segment_duration / 5)))
                
                # Get the sentences for this segment
                segment_sentences = []
                for j in range(sentences_per_segment):
                    if sentence_index < len(sentences):
                        segment_sentences.append(sentences[sentence_index])
                        sentence_index += 1
                        
                # Create caption text for this segment
                caption_text = " ".join(segment_sentences)
                
                # Format caption text to fit within max_chars_per_line
                formatted_caption = self._format_caption_text(caption_text)
                
                # Add caption segment
                caption_segments.append({
                    "segment_index": i,
                    "start_time": segment.get("start_time", 0),
                    "duration": segment_duration,
                    "text": formatted_caption,
                    "style": self.style.copy()
                })
                
            return caption_segments
        except Exception as e:
            print(f"Error extracting captions from script {script_path}: {e}")
            # Return default captions if script processing fails
            return [
                {
                    "segment_index": i,
                    "start_time": segment.get("start_time", 0),
                    "duration": segment.get("duration", 5.0),
                    "text": f"Caption for segment {i+1}",
                    "style": self.style.copy()
                }
                for i, segment in enumerate(segments)
            ]
            
    def _format_caption_text(self, text: str) -> str:
        """
        Format caption text to fit within max_chars_per_line
        
        Args:
            text: Original caption text
            
        Returns:
            Formatted caption text with line breaks
        """
        max_chars = self.style["max_chars_per_line"]
        max_lines = self.style["max_lines"]
        
        # If text is already short enough, return as is
        if len(text) <= max_chars:
            return text
            
        # Split text into words
        words = text.split()
        
        # Build lines
        lines = []
        current_line = ""
        
        for word in words:
            # Check if adding this word would exceed max_chars
            if len(current_line) + len(word) + 1 <= max_chars:
                # Add word to current line
                if current_line:
                    current_line += " " + word
                else:
                    current_line = word
            else:
                # Start a new line
                lines.append(current_line)
                current_line = word
                
                # Check if we've reached max_lines
                if len(lines) >= max_lines - 1:
                    break
                    
        # Add the last line
        if current_line and len(lines) < max_lines:
            lines.append(current_line)
            
        # If we have more words but reached max_lines, add ellipsis
        if len(lines) == max_lines and words[-1] not in current_line:
            lines[-1] = lines[-1] + "..."
            
        # Join lines with newline characters
        return "\n".join(lines)
        
    def add_captions(self, adjusted_plan_path: str, script_path: str) -> Dict[str, Any]:
        """
        Add captions to a video based on the adjusted sequence plan
        
        Args:
            adjusted_plan_path: Path to the adjusted sequence plan JSON file
            script_path: Path to the script file
            
        Returns:
            Dictionary with captioned video information
        """
        try:
            # Load the adjusted sequence plan
            with open(adjusted_plan_path, 'r') as f:
                adjusted_plan = json.load(f)
                
            # Extract segments from the plan
            segments = adjusted_plan.get("segments", [])
            
            # Extract captions from the script
            caption_segments = self._extract_captions_from_script(script_path, segments)
            
            # Add captions to the sequence plan
            captioned_plan = adjusted_plan.copy()
            
            for i, segment in enumerate(captioned_plan["segments"]):
                # Find the corresponding caption segment
                caption = next((c for c in caption_segments if c["segment_index"] == i), None)
                
                if caption:
                    segment["caption"] = {
                        "text": caption["text"],
                        "style": caption["style"]
                    }
                    
            # In a real implementation, this would use MoviePy or similar
            # to actually overlay the captions on the video
            # For now, we'll just create a mock output file
            
            sequence_id = captioned_plan["id"]
            output_filename = f"{sequence_id}_captioned.txt"
            output_path = os.path.join(self.output_dir, output_filename)
            
            # Save the caption details to a file
            with open(output_path, 'w') as f:
                f.write(f"CAPTIONED VIDEO FOR YOUTUBE SHORTS\n")
                f.write(f"Sequence ID: {sequence_id}\n")
                f.write(f"Caption Style: {json.dumps(self.style, indent=2)}\n")
                f.write(f"Caption Segments: {len(caption_segments)}\n\n")
                
                for i, caption in enumerate(caption_segments):
                    f.write(f"Segment {i+1}:\n")
                    f.write(f"  Start Time: {caption['start_time']:.1f}s\n")
                    f.write(f"  Duration: {caption['duration']:.1f}s\n")
                    f.write(f"  Text: {caption['text']}\n\n")
                    
                f.write(f"Captioning Time: {datetime.now().isoformat()}\n")
                
            # Save the captioned plan
            captioned_plan_path = os.path.join(self.output_dir, f"{sequence_id}_captioned_plan.json")
            with open(captioned_plan_path, 'w') as f:
                json.dump(captioned_plan, f, indent=2)
                
            print(f"Caption details saved to: {output_path}")
            print(f"Captioned plan saved to: {captioned_plan_path}")
            
            return {
                "captioned_video_path": output_path,
                "captioned_plan_path": captioned_plan_path,
                "sequence_id": sequence_id,
                "caption_count": len(caption_segments),
                "caption_style": self.style
            }
        except Exception as e:
            print(f"Error adding captions to sequence from {adjusted_plan_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{random.randint(1000, 9999)}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if paths were provided as command-line arguments
    if len(sys.argv) > 2:
        adjusted_plan_path = sys.argv[1]
        script_path = sys.argv[2]
    else:
        print("No paths provided. Using mock paths.")
        adjusted_plan_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/converted_videos/seq_1234_adjusted_plan.json"
        script_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts/script_1234.txt"
        
        # Create mock files for testing
        os.makedirs(os.path.dirname(adjusted_plan_path), exist_ok=True)
        os.makedirs(os.path.dirname(script_path), exist_ok=True)
        
        # Create a mock script
        with open(script_path, 'w') as f:
            f.write("Did you know these amazing facts about space? The International Space Station travels at 17,500 mph. ")
            f.write("A day on Venus is longer than a year on Venus. The footprints on the Moon will last for 100 million years. ")
            f.write("Like and follow for more amazing facts!")
            
        # Create a mock adjusted plan
        mock_adjusted_plan = {
            "id": "seq_1234",
            "title": "Amazing Facts About Space",
            "total_duration": 30.0,
            "aspect_ratio": "9:16",
            "resolution": "1080x1920",
            "segments": [
                {
                    "type": "intro",
                    "start_time": 0,
                    "duration": 6.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/title_card.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                },
                {
                    "type": "main_point",
                    "start_time": 6.0,
                    "duration": 8.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/point_image1.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                },
                {
                    "type": "main_point",
                    "start_time": 14.0,
                    "duration": 8.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/point_image2.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                },
                {
                    "type": "outro",
                    "start_time": 22.0,
                    "duration": 8.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/outro_image.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                }
            ],
            "transitions": ["fade", "slide"],
            "created_at": datetime.now().isoformat()
        }
        
        with open(adjusted_plan_path, 'w') as f:
            json.dump(mock_adjusted_plan, f, indent=2)
        
    caption_generator = CaptionGenerator()
    result = caption_generator.add_captions(adjusted_plan_path, script_path)
    
    print("\nCaptioning Complete!")
    print(f"Sequence ID: {result.get('sequence_id')}")
    print(f"Caption Count: {result.get('caption_count', 0)}")
    print(f"Captioned Video: {result.get('captioned_video_path', 'N/A')}")
    print(f"Captioned Plan: {result.get('captioned_plan_path', 'N/A')}")

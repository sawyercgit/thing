"""
Format Converter Module for YouTube Shorts Agent

This module handles the conversion of video sequences to the correct format
for YouTube Shorts, ensuring proper aspect ratio, resolution, and encoding.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

class FormatConverter:
    """
    Converts video sequences to the correct format for YouTube Shorts
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the FormatConverter with configuration
        
        Args:
            config: Configuration dictionary with settings for format conversion
        """
        self.config = config or {}
        
        # Default settings for YouTube Shorts
        self.default_settings = {
            "aspect_ratio": "9:16",
            "resolution": "1080x1920",
            "fps": 30,
            "bitrate": "8M",
            "codec": "h264",
            "format": "mp4"
        }
        
        # Override defaults with config if provided
        self.settings = {**self.default_settings, **self.config.get("format_settings", {})}
        
        # Create output directory for converted videos
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/converted_videos"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _validate_sequence_plan(self, sequence_plan: Dict[str, Any]) -> bool:
        """
        Validate that the sequence plan has all required elements
        
        Args:
            sequence_plan: Sequence plan from AssetCompositor
            
        Returns:
            True if valid, False otherwise
        """
        required_keys = ["id", "segments", "total_duration"]
        for key in required_keys:
            if key not in sequence_plan:
                print(f"Error: Missing required key '{key}' in sequence plan")
                return False
                
        if not sequence_plan["segments"]:
            print("Error: Sequence plan has no segments")
            return False
            
        return True
        
    def _adjust_aspect_ratio(self, sequence_plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Adjust the sequence plan to ensure correct aspect ratio
        
        Args:
            sequence_plan: Sequence plan from AssetCompositor
            
        Returns:
            Updated sequence plan with adjusted aspect ratio
        """
        target_aspect_ratio = self.settings["aspect_ratio"]
        target_resolution = self.settings["resolution"]
        
        # Check if the sequence plan already has the correct aspect ratio
        if sequence_plan.get("aspect_ratio") == target_aspect_ratio and \
           sequence_plan.get("resolution") == target_resolution:
            return sequence_plan
            
        # Create a copy of the sequence plan to modify
        adjusted_plan = sequence_plan.copy()
        adjusted_plan["aspect_ratio"] = target_aspect_ratio
        adjusted_plan["resolution"] = target_resolution
        
        # Add cropping/padding instructions for each segment
        for segment in adjusted_plan["segments"]:
            # In a real implementation, this would calculate precise
            # cropping/padding values based on the asset dimensions
            # For now, we'll just add placeholder instructions
            
            visual = segment.get("visual", {})
            if visual:
                visual["format_adjustments"] = {
                    "crop_mode": "center",  # center, smart, face
                    "padding_color": "#000000",
                    "target_aspect_ratio": target_aspect_ratio,
                    "target_resolution": target_resolution
                }
                segment["visual"] = visual
                
        return adjusted_plan
        
    def convert_sequence(self, sequence_plan_path: str) -> Dict[str, Any]:
        """
        Convert a sequence to the correct format for YouTube Shorts
        
        Args:
            sequence_plan_path: Path to the sequence plan JSON file
            
        Returns:
            Dictionary with converted video information
        """
        try:
            # Load the sequence plan
            with open(sequence_plan_path, 'r') as f:
                sequence_plan = json.load(f)
                
            # Validate the sequence plan
            if not self._validate_sequence_plan(sequence_plan):
                raise ValueError("Invalid sequence plan")
                
            # Adjust the aspect ratio
            adjusted_plan = self._adjust_aspect_ratio(sequence_plan)
            
            # In a real implementation, this would use FFmpeg or similar
            # to actually convert the video to the correct format
            # For now, we'll just create a mock output file
            
            sequence_id = adjusted_plan["id"]
            output_filename = f"{sequence_id}_converted.txt"
            output_path = os.path.join(self.output_dir, output_filename)
            
            # Save the conversion details to a file
            with open(output_path, 'w') as f:
                f.write(f"CONVERTED VIDEO FOR YOUTUBE SHORTS\n")
                f.write(f"Sequence ID: {sequence_id}\n")
                f.write(f"Aspect Ratio: {self.settings['aspect_ratio']}\n")
                f.write(f"Resolution: {self.settings['resolution']}\n")
                f.write(f"FPS: {self.settings['fps']}\n")
                f.write(f"Bitrate: {self.settings['bitrate']}\n")
                f.write(f"Codec: {self.settings['codec']}\n")
                f.write(f"Format: {self.settings['format']}\n")
                f.write(f"Duration: {adjusted_plan['total_duration']:.1f} seconds\n")
                f.write(f"Segment Count: {len(adjusted_plan['segments'])}\n")
                f.write(f"Conversion Time: {datetime.now().isoformat()}\n")
                
            # Save the adjusted plan
            adjusted_plan_path = os.path.join(self.output_dir, f"{sequence_id}_adjusted_plan.json")
            with open(adjusted_plan_path, 'w') as f:
                json.dump(adjusted_plan, f, indent=2)
                
            print(f"Conversion details saved to: {output_path}")
            print(f"Adjusted plan saved to: {adjusted_plan_path}")
            
            return {
                "converted_video_path": output_path,
                "adjusted_plan_path": adjusted_plan_path,
                "sequence_id": sequence_id,
                "format": self.settings["format"],
                "resolution": self.settings["resolution"],
                "aspect_ratio": self.settings["aspect_ratio"],
                "duration": adjusted_plan["total_duration"]
            }
        except Exception as e:
            print(f"Error converting sequence from {sequence_plan_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{random.randint(1000, 9999)}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if a sequence plan path was provided as a command-line argument
    if len(sys.argv) > 1:
        sequence_plan_path = sys.argv[1]
    else:
        print("No sequence plan path provided. Using a mock path.")
        sequence_plan_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/sequences/seq_1234_sequence_plan.json"
        
        # Create a mock sequence plan for testing
        os.makedirs(os.path.dirname(sequence_plan_path), exist_ok=True)
        
        # Create the mock sequence plan
        mock_sequence_plan = {
            "id": "seq_1234",
            "title": "Test YouTube Short",
            "total_duration": 30.0,
            "aspect_ratio": "16:9",  # Intentionally wrong to test conversion
            "resolution": "1920x1080",  # Intentionally wrong to test conversion
            "segments": [
                {
                    "type": "intro",
                    "start_time": 0,
                    "duration": 6.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/title_card.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                },
                {
                    "type": "main_point",
                    "start_time": 6.0,
                    "duration": 18.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/point_image.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                },
                {
                    "type": "outro",
                    "start_time": 24.0,
                    "duration": 6.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/outro_image.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    }
                }
            ],
            "transitions": ["fade", "slide"],
            "created_at": datetime.now().isoformat()
        }
        
        with open(sequence_plan_path, 'w') as f:
            json.dump(mock_sequence_plan, f, indent=2)
        
    converter = FormatConverter()
    result = converter.convert_sequence(sequence_plan_path)
    
    print("\nConversion Complete!")
    print(f"Sequence ID: {result.get('sequence_id')}")
    print(f"Format: {result.get('format')}")
    print(f"Resolution: {result.get('resolution')}")
    print(f"Aspect Ratio: {result.get('aspect_ratio')}")
    print(f"Duration: {result.get('duration', 0):.1f} seconds")
    print(f"Converted Video: {result.get('converted_video_path', 'N/A')}")
    print(f"Adjusted Plan: {result.get('adjusted_plan_path', 'N/A')}")

"""
Asset Compositor Module for YouTube Shorts Agent

This module handles the composition of visual and audio assets
into a cohesive video sequence for YouTube Shorts.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional
import subprocess
from datetime import datetime

class AssetCompositor:
    """
    Composes visual and audio assets into a video sequence
    based on the script and content plan
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the AssetCompositor with configuration
        
        Args:
            config: Configuration dictionary with settings for asset composition
        """
        self.config = config or {}
        
        # Create output directory for composed sequences
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/sequences"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _read_script(self, script_path: str) -> str:
        """
        Read script content from file
        
        Args:
            script_path: Path to the script file
            
        Returns:
            Script content as string
        """
        try:
            with open(script_path, 'r') as f:
                return f.read()
        except Exception as e:
            print(f"Error reading script from {script_path}: {e}")
            return "Script content unavailable"
            
    def _read_asset_info(self, asset_path: str) -> Dict[str, Any]:
        """
        Read asset information from placeholder files
        
        Args:
            asset_path: Path to the asset file
            
        Returns:
            Dictionary with asset information
        """
        try:
            # For our mock implementation, assets are text files with descriptions
            with open(asset_path, 'r') as f:
                lines = f.readlines()
                
            # Parse basic info from the first few lines
            asset_info = {
                "path": asset_path,
                "type": lines[0].strip() if lines else "Unknown asset"
            }
            
            # Add additional info if available
            for line in lines[1:]:
                if ":" in line:
                    key, value = line.split(":", 1)
                    asset_info[key.strip().lower()] = value.strip()
                    
            return asset_info
        except Exception as e:
            print(f"Error reading asset info from {asset_path}: {e}")
            return {"path": asset_path, "type": "Unknown asset", "error": str(e)}
            
    def create_sequence_plan(self, content_package: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a sequence plan from the content package
        
        Args:
            content_package: Content package from the ContentGenerationController
            
        Returns:
            Dictionary with sequence plan information
        """
        # Extract assets from the content package
        assets = content_package.get("assets", {})
        metadata = content_package.get("metadata", {})
        
        # Read the script
        script_path = assets.get("script", "")
        script_content = self._read_script(script_path)
        
        # Get information about visual assets
        title_card_info = self._read_asset_info(assets.get("title_card", ""))
        
        point_images_info = []
        for img_path in assets.get("point_images", []):
            point_images_info.append(self._read_asset_info(img_path))
            
        stock_images_info = []
        for img_path in assets.get("stock_images", []):
            stock_images_info.append(self._read_asset_info(img_path))
            
        stock_videos_info = []
        for vid_path in assets.get("stock_videos", []):
            stock_videos_info.append(self._read_asset_info(vid_path))
            
        # Get information about audio assets
        voiceover_info = self._read_asset_info(assets.get("voiceover", ""))
        music_info = self._read_asset_info(assets.get("background_music", ""))
        
        # Create a sequence plan
        # In a real implementation, this would calculate precise timings
        # For now, we'll create a simplified plan
        
        # Estimate duration for each segment based on script
        total_duration = float(metadata.get("estimated_duration", 30))
        
        # Allocate time for intro, main content, and outro
        intro_duration = total_duration * 0.2  # 20% for intro
        outro_duration = total_duration * 0.1  # 10% for outro
        main_duration = total_duration - intro_duration - outro_duration
        
        # Divide main duration among key points
        num_points = len(assets.get("point_images", []))
        point_duration = main_duration / max(1, num_points)
        
        # Create sequence segments
        segments = []
        
        # Intro segment with title card
        segments.append({
            "type": "intro",
            "start_time": 0,
            "duration": intro_duration,
            "visual": {
                "type": "image",
                "asset": title_card_info
            },
            "audio": {
                "voiceover": voiceover_info,
                "music": music_info,
                "music_volume": 0.2
            },
            "caption": "Intro text from script"
        })
        
        # Main content segments with point images
        current_time = intro_duration
        for i, point_img in enumerate(point_images_info):
            segments.append({
                "type": "main_point",
                "start_time": current_time,
                "duration": point_duration,
                "visual": {
                    "type": "image",
                    "asset": point_img
                },
                "audio": {
                    "voiceover": voiceover_info,
                    "music": music_info,
                    "music_volume": 0.1
                },
                "caption": f"Point {i+1} text from script"
            })
            current_time += point_duration
            
        # Outro segment with stock image or video
        outro_visual = stock_videos_info[0] if stock_videos_info else (
            stock_images_info[0] if stock_images_info else title_card_info
        )
        
        segments.append({
            "type": "outro",
            "start_time": current_time,
            "duration": outro_duration,
            "visual": {
                "type": "image" if "IMAGE" in outro_visual.get("type", "").upper() else "video",
                "asset": outro_visual
            },
            "audio": {
                "voiceover": voiceover_info,
                "music": music_info,
                "music_volume": 0.3
            },
            "caption": "Call to action from script"
        })
        
        # Create the complete sequence plan
        sequence_plan = {
            "id": content_package.get("id", f"seq_{random.randint(1000, 9999)}"),
            "title": metadata.get("title", "YouTube Short"),
            "total_duration": total_duration,
            "aspect_ratio": "9:16",
            "resolution": "1080x1920",
            "segments": segments,
            "transitions": ["fade", "slide"],
            "created_at": datetime.now().isoformat()
        }
        
        # Save the sequence plan to a file
        output_path = os.path.join(self.output_dir, f"{sequence_plan['id']}_sequence_plan.json")
        with open(output_path, 'w') as f:
            json.dump(sequence_plan, f, indent=2)
            
        print(f"Sequence plan saved to: {output_path}")
        
        return {
            "sequence_plan_path": output_path,
            "sequence_id": sequence_plan["id"],
            "total_duration": total_duration,
            "segment_count": len(segments)
        }
        
    def compose_sequence(self, content_package_path: str) -> Dict[str, Any]:
        """
        Compose a sequence from a content package
        
        Args:
            content_package_path: Path to the content package JSON file
            
        Returns:
            Dictionary with sequence information
        """
        try:
            # Load the content package
            with open(content_package_path, 'r') as f:
                content_package = json.load(f)
                
            # Create a sequence plan
            sequence_info = self.create_sequence_plan(content_package)
            
            # In a real implementation, this would use MoviePy or similar
            # to actually compose the video sequence from the assets
            # For now, we'll just return the sequence plan
            
            return sequence_info
        except Exception as e:
            print(f"Error composing sequence from {content_package_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{random.randint(1000, 9999)}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if a content package path was provided as a command-line argument
    if len(sys.argv) > 1:
        content_package_path = sys.argv[1]
    else:
        print("No content package path provided. Using a mock path.")
        content_package_path = "/home/ubuntu/youtube_shorts_agent/generated_content/short_1234_content_package.json"
        
        # Create a mock content package for testing
        os.makedirs(os.path.dirname(content_package_path), exist_ok=True)
        
        # Create mock asset files
        script_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts"
        os.makedirs(script_dir, exist_ok=True)
        script_path = os.path.join(script_dir, "script_1234.txt")
        with open(script_path, 'w') as f:
            f.write("This is a test script for a YouTube Short.")
            
        image_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/images"
        os.makedirs(image_dir, exist_ok=True)
        title_card_path = os.path.join(image_dir, "title_1234.txt")
        with open(title_card_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: Title card for test\n")
            f.write("STYLE: dynamic\n")
            
        point_image_path = os.path.join(image_dir, "point_1234.txt")
        with open(point_image_path, 'w') as f:
            f.write("IMAGE GENERATION PROMPT: Test point image\n")
            f.write("STYLE: standard\n")
            
        audio_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/audio"
        os.makedirs(audio_dir, exist_ok=True)
        voiceover_path = os.path.join(audio_dir, "speech_1234.txt")
        with open(voiceover_path, 'w') as f:
            f.write("VOICE: default\n\n")
            f.write("This is a test voiceover for a YouTube Short.")
            
        music_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/music"
        os.makedirs(music_dir, exist_ok=True)
        music_path = os.path.join(music_dir, "music_1234.txt")
        with open(music_path, 'w') as f:
            f.write("BACKGROUND MUSIC\n")
            f.write("Mood: engaging\n")
            f.write("Duration: 30 seconds\n")
            
        # Create the mock content package
        mock_content_package = {
            "id": "short_1234",
            "prompt": "Create a test short",
            "content_plan": {},
            "assets": {
                "script": script_path,
                "title_card": title_card_path,
                "point_images": [point_image_path],
                "stock_images": [],
                "stock_videos": [],
                "voiceover": voiceover_path,
                "background_music": music_path
            },
            "metadata": {
                "title": "Test YouTube Short",
                "estimated_duration": 30,
                "theme": "test",
                "tone": "neutral"
            }
        }
        
        with open(content_package_path, 'w') as f:
            json.dump(mock_content_package, f, indent=2)
        
    compositor = AssetCompositor()
    result = compositor.compose_sequence(content_package_path)
    
    print("\nComposition Complete!")
    print(f"Sequence ID: {result.get('sequence_id')}")
    print(f"Total Duration: {result.get('total_duration', 0):.1f} seconds")
    print(f"Segment Count: {result.get('segment_count', 0)}")
    print(f"Sequence Plan: {result.get('sequence_plan_path', 'N/A')}")

"""
Effect Applier Module for YouTube Shorts Agent

This module handles the application of visual effects, transitions,
and enhancements to YouTube Shorts videos.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

class EffectApplier:
    """
    Applies visual effects, transitions, and enhancements to YouTube Shorts videos
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the EffectApplier with configuration
        
        Args:
            config: Configuration dictionary with settings for effects
        """
        self.config = config or {}
        
        # Default effect settings
        self.default_effects = {
            "transitions": ["fade", "slide", "zoom"],
            "visual_effects": ["zoom", "pan", "brightness", "contrast"],
            "text_effects": ["fade", "slide", "pop"],
            "intensity": "medium"  # low, medium, high
        }
        
        # Override defaults with config if provided
        self.effects = {**self.default_effects, **self.config.get("effect_settings", {})}
        
        # Create output directory for final videos
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/final_videos"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _select_transitions(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Select appropriate transitions between segments
        
        Args:
            segments: List of video segments from the sequence plan
            
        Returns:
            List of segments with added transition information
        """
        available_transitions = self.effects["transitions"]
        
        # Create a copy of segments to modify
        segments_with_transitions = []
        
        for i, segment in enumerate(segments):
            segment_copy = segment.copy()
            
            # Add transition to the next segment (except for the last one)
            if i < len(segments) - 1:
                # Select a random transition
                transition = random.choice(available_transitions)
                
                # Determine transition duration based on intensity
                if self.effects["intensity"] == "low":
                    duration = 0.5
                elif self.effects["intensity"] == "high":
                    duration = 1.5
                else:  # medium
                    duration = 1.0
                    
                segment_copy["transition_out"] = {
                    "type": transition,
                    "duration": duration
                }
                
            segments_with_transitions.append(segment_copy)
            
        return segments_with_transitions
        
    def _apply_visual_effects(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Apply visual effects to segments
        
        Args:
            segments: List of video segments with transitions
            
        Returns:
            List of segments with added visual effect information
        """
        available_effects = self.effects["visual_effects"]
        
        # Create a copy of segments to modify
        segments_with_effects = []
        
        for segment in segments:
            segment_copy = segment.copy()
            
            # Determine if this segment should have effects
            # Apply effects to some segments based on type
            should_apply = (
                segment_copy["type"] == "main_point" or
                (segment_copy["type"] == "intro" and random.random() > 0.5) or
                (segment_copy["type"] == "outro" and random.random() > 0.7)
            )
            
            if should_apply:
                # Select 1-2 random effects
                num_effects = random.randint(1, 2)
                selected_effects = random.sample(available_effects, min(num_effects, len(available_effects)))
                
                # Determine effect parameters based on intensity
                effect_params = {}
                for effect in selected_effects:
                    if effect == "zoom":
                        if self.effects["intensity"] == "low":
                            effect_params[effect] = {"scale": 1.1, "duration": segment_copy["duration"] * 0.8}
                        elif self.effects["intensity"] == "high":
                            effect_params[effect] = {"scale": 1.3, "duration": segment_copy["duration"] * 0.9}
                        else:  # medium
                            effect_params[effect] = {"scale": 1.2, "duration": segment_copy["duration"] * 0.85}
                    elif effect == "pan":
                        if self.effects["intensity"] == "low":
                            effect_params[effect] = {"direction": random.choice(["left", "right"]), "amount": 0.1}
                        elif self.effects["intensity"] == "high":
                            effect_params[effect] = {"direction": random.choice(["left", "right", "up", "down"]), "amount": 0.3}
                        else:  # medium
                            effect_params[effect] = {"direction": random.choice(["left", "right", "up", "down"]), "amount": 0.2}
                    elif effect == "brightness":
                        if self.effects["intensity"] == "low":
                            effect_params[effect] = {"adjustment": random.uniform(0.95, 1.05)}
                        elif self.effects["intensity"] == "high":
                            effect_params[effect] = {"adjustment": random.uniform(0.9, 1.1)}
                        else:  # medium
                            effect_params[effect] = {"adjustment": random.uniform(0.93, 1.07)}
                    elif effect == "contrast":
                        if self.effects["intensity"] == "low":
                            effect_params[effect] = {"adjustment": random.uniform(0.97, 1.03)}
                        elif self.effects["intensity"] == "high":
                            effect_params[effect] = {"adjustment": random.uniform(0.9, 1.1)}
                        else:  # medium
                            effect_params[effect] = {"adjustment": random.uniform(0.95, 1.05)}
                
                segment_copy["visual_effects"] = effect_params
                
            segments_with_effects.append(segment_copy)
            
        return segments_with_effects
        
    def _apply_text_effects(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Apply text effects to captions
        
        Args:
            segments: List of video segments with visual effects
            
        Returns:
            List of segments with added text effect information
        """
        available_effects = self.effects["text_effects"]
        
        # Create a copy of segments to modify
        segments_with_text_effects = []
        
        for segment in segments:
            segment_copy = segment.copy()
            
            # Check if segment has captions
            if "caption" in segment_copy:
                caption = segment_copy["caption"].copy()
                
                # Select a random text effect
                text_effect = random.choice(available_effects)
                
                # Determine effect parameters based on intensity
                if self.effects["intensity"] == "low":
                    duration = 0.5
                elif self.effects["intensity"] == "high":
                    duration = 1.0
                else:  # medium
                    duration = 0.7
                    
                caption["effect"] = {
                    "type": text_effect,
                    "duration": duration
                }
                
                segment_copy["caption"] = caption
                
            segments_with_text_effects.append(segment_copy)
            
        return segments_with_text_effects
        
    def apply_effects(self, captioned_plan_path: str) -> Dict[str, Any]:
        """
        Apply effects to a video based on the captioned sequence plan
        
        Args:
            captioned_plan_path: Path to the captioned sequence plan JSON file
            
        Returns:
            Dictionary with final video information
        """
        try:
            # Load the captioned sequence plan
            with open(captioned_plan_path, 'r') as f:
                captioned_plan = json.load(f)
                
            # Extract segments from the plan
            segments = captioned_plan.get("segments", [])
            
            # Apply transitions
            segments_with_transitions = self._select_transitions(segments)
            
            # Apply visual effects
            segments_with_visual_effects = self._apply_visual_effects(segments_with_transitions)
            
            # Apply text effects
            segments_with_all_effects = self._apply_text_effects(segments_with_visual_effects)
            
            # Create the final sequence plan
            final_plan = captioned_plan.copy()
            final_plan["segments"] = segments_with_all_effects
            final_plan["effects_applied"] = True
            final_plan["effect_settings"] = self.effects
            
            # In a real implementation, this would use MoviePy or similar
            # to actually apply the effects to the video
            # For now, we'll just create a mock output file
            
            sequence_id = final_plan["id"]
            output_filename = f"{sequence_id}_final.txt"
            output_path = os.path.join(self.output_dir, output_filename)
            
            # Save the effect details to a file
            with open(output_path, 'w') as f:
                f.write(f"FINAL VIDEO FOR YOUTUBE SHORTS\n")
                f.write(f"Sequence ID: {sequence_id}\n")
                f.write(f"Title: {final_plan.get('title', 'YouTube Short')}\n")
                f.write(f"Duration: {final_plan.get('total_duration', 0):.1f} seconds\n")
                f.write(f"Resolution: {final_plan.get('resolution', '1080x1920')}\n")
                f.write(f"Aspect Ratio: {final_plan.get('aspect_ratio', '9:16')}\n")
                f.write(f"Effect Intensity: {self.effects['intensity']}\n")
                f.write(f"Transitions: {', '.join(self.effects['transitions'])}\n")
                f.write(f"Visual Effects: {', '.join(self.effects['visual_effects'])}\n")
                f.write(f"Text Effects: {', '.join(self.effects['text_effects'])}\n\n")
                
                for i, segment in enumerate(segments_with_all_effects):
                    f.write(f"Segment {i+1} ({segment['type']}):\n")
                    f.write(f"  Duration: {segment.get('duration', 0):.1f}s\n")
                    
                    if "transition_out" in segment:
                        f.write(f"  Transition: {segment['transition_out']['type']} ")
                        f.write(f"({segment['transition_out']['duration']:.1f}s)\n")
                        
                    if "visual_effects" in segment:
                        f.write(f"  Visual Effects: {', '.join(segment['visual_effects'].keys())}\n")
                        
                    if "caption" in segment and "effect" in segment["caption"]:
                        f.write(f"  Caption Effect: {segment['caption']['effect']['type']} ")
                        f.write(f"({segment['caption']['effect']['duration']:.1f}s)\n")
                        
                    f.write("\n")
                    
                f.write(f"Rendering Time: {datetime.now().isoformat()}\n")
                
            # Save the final plan
            final_plan_path = os.path.join(self.output_dir, f"{sequence_id}_final_plan.json")
            with open(final_plan_path, 'w') as f:
                json.dump(final_plan, f, indent=2)
                
            print(f"Final video details saved to: {output_path}")
            print(f"Final plan saved to: {final_plan_path}")
            
            return {
                "final_video_path": output_path,
                "final_plan_path": final_plan_path,
                "sequence_id": sequence_id,
                "title": final_plan.get("title", "YouTube Short"),
                "duration": final_plan.get("total_duration", 0),
                "resolution": final_plan.get("resolution", "1080x1920"),
                "aspect_ratio": final_plan.get("aspect_ratio", "9:16")
            }
        except Exception as e:
            print(f"Error applying effects to sequence from {captioned_plan_path}: {e}")
            return {
                "error": str(e),
                "sequence_id": f"error_{random.randint(1000, 9999)}"
            }


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check if a captioned plan path was provided as a command-line argument
    if len(sys.argv) > 1:
        captioned_plan_path = sys.argv[1]
    else:
        print("No captioned plan path provided. Using a mock path.")
        captioned_plan_path = "/home/ubuntu/youtube_shorts_agent/generated_assets/captioned_videos/seq_1234_captioned_plan.json"
        
        # Create a mock captioned plan for testing
        os.makedirs(os.path.dirname(captioned_plan_path), exist_ok=True)
        
        # Create a mock captioned plan
        mock_captioned_plan = {
            "id": "seq_1234",
            "title": "Amazing Facts About Space",
            "total_duration": 30.0,
            "aspect_ratio": "9:16",
            "resolution": "1080x1920",
            "segments": [
                {
                    "type": "intro",
                    "start_time": 0,
                    "duration": 6.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/title_card.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    },
                    "caption": {
                        "text": "Did you know these amazing\nfacts about space?",
                        "style": {
                            "font": "Arial",
                            "size": 36,
                            "color": "#FFFFFF",
                            "background": "#000000AA",
                            "position": "bottom",
                            "margin": 50
                        }
                    }
                },
                {
                    "type": "main_point",
                    "start_time": 6.0,
                    "duration": 8.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/point_image1.txt",
                            "type": "IMAGE GENERATION PROMPT"
                        }
                    },
                    "caption": {
                        "text": "The International Space Station\ntravels at 17,500 mph",
                        "style": {
                            "font": "Arial",
                            "size": 36,
                            "color": "#FFFFFF",
                            "background": "#000000AA",
                            "position": "bottom",
                            "margin": 50
                        }
                    }
                },
                {
                    "type": "main_point",
                    "start_time": 14.0,
                    "duration": 8.0,
                    "visual": {
                        "type": "image",
                        "asset": {
                            "path": "/path/to/point_image2.txt",
                            "type": "IMAGE GENERATION PROMPT"
         <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>
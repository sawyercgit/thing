"""
Content Generator Module for YouTube Shorts Agent

This module handles the generation of content assets (script, visuals, audio)
for YouTube Shorts based on the content plan from the Prompt Processor.
"""

import os
import json
import random
from typing import Dict, List, Any, Optional, Tuple
import requests
from PIL import Image
from io import BytesIO

# Mock classes for external APIs - in production, these would use actual APIs
class ImageGenerationAPI:
    """Mock image generation API client"""
    
    def __init__(self, api_key: Optional[str] = None, provider: str = "stable-diffusion"):
        self.api_key = api_key or os.environ.get("IMAGE_API_KEY", "mock_key")
        self.provider = provider
        
        # Create a directory for storing generated images if it doesn't exist
        self.image_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/images"
        os.makedirs(self.image_dir, exist_ok=True)
        
    def generate_image(self, prompt: str, style: str = "realistic") -> str:
        """
        Mock image generation - in production, this would call an actual API
        
        For now, it creates a placeholder text file with image description
        
        Args:
            prompt: Text description of the image to generate
            style: Visual style for the image
            
        Returns:
            Path to the generated/downloaded image
        """
        # Extract a keyword from the prompt for the placeholder
        keywords = prompt.split()
        keyword = next((word for word in keywords if len(word) > 3), "abstract")
        
        # Generate a unique filename
        filename = f"{keyword}_{random.randint(1000, 9999)}.txt"
        filepath = os.path.join(self.image_dir, filename)
        
        # In a real implementation, this would generate an actual image
        # For now, we'll just save the prompt to a text file as a placeholder
        with open(filepath, 'w') as f:
            f.write(f"IMAGE GENERATION PROMPT: {prompt}\n")
            f.write(f"STYLE: {style}\n")
            f.write(f"PROVIDER: {self.provider}\n")
            f.write(f"RESOLUTION: 1080x1920 (vertical for YouTube Shorts)\n")
            
        return filepath


class TextToSpeechAPI:
    """Mock text-to-speech API client"""
    
    def __init__(self, api_key: Optional[str] = None, provider: str = "elevenlabs"):
        self.api_key = api_key or os.environ.get("TTS_API_KEY", "mock_key")
        self.provider = provider
        
        # Create a directory for storing generated audio if it doesn't exist
        self.audio_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/audio"
        os.makedirs(self.audio_dir, exist_ok=True)
        
    def generate_speech(self, text: str, voice_id: str = "default") -> str:
        """
        Mock text-to-speech generation - in production, this would call an actual API
        
        For now, it creates a placeholder text file with the script
        
        Args:
            text: Text to convert to speech
            voice_id: ID of the voice to use
            
        Returns:
            Path to the generated audio file (or placeholder)
        """
        # Generate a unique filename
        filename = f"speech_{random.randint(1000, 9999)}.txt"
        filepath = os.path.join(self.audio_dir, filename)
        
        # In a real implementation, this would generate an audio file
        # For now, we'll just save the text to a file as a placeholder
        with open(filepath, 'w') as f:
            f.write(f"VOICE: {voice_id}\n\n")
            f.write(text)
            
        return filepath


class StockAssetAPI:
    """Mock stock asset API client for fetching stock images and videos"""
    
    def __init__(self, api_key: Optional[str] = None, provider: str = "pexels"):
        self.api_key = api_key or os.environ.get("STOCK_API_KEY", "mock_key")
        self.provider = provider
        
        # Create directories for storing assets if they don't exist
        self.image_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/stock_images"
        self.video_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/stock_videos"
        os.makedirs(self.image_dir, exist_ok=True)
        os.makedirs(self.video_dir, exist_ok=True)
        
    def search_images(self, query: str, count: int = 3) -> List[str]:
        """
        Mock stock image search - in production, this would call an actual API
        
        For now, it creates placeholder text files with image descriptions
        
        Args:
            query: Search term for images
            count: Number of images to retrieve
            
        Returns:
            List of paths to the placeholder image files
        """
        image_paths = []
        
        for i in range(count):
            # Generate a unique filename
            filename = f"{query.replace(' ', '_')}_{i+1}_{random.randint(1000, 9999)}.txt"
            filepath = os.path.join(self.image_dir, filename)
            
            # In a real implementation, this would download actual image files
            # For now, we'll just create text files as placeholders
            with open(filepath, 'w') as f:
                f.write(f"STOCK IMAGE: {query}\n")
                f.write(f"Description: Stock image of {query}, image {i+1}\n")
                f.write(f"Resolution: 1080x1920 (vertical)\n")
                f.write(f"Provider: {self.provider}\n")
                
            image_paths.append(filepath)
                
        return image_paths
    
    def search_videos(self, query: str, count: int = 2) -> List[str]:
        """
        Mock stock video search - in production, this would call an actual API
        
        For now, it creates placeholder text files with video descriptions
        
        Args:
            query: Search term for videos
            count: Number of videos to retrieve
            
        Returns:
            List of paths to the placeholder video files
        """
        video_paths = []
        
        for i in range(count):
            # Generate a unique filename
            filename = f"{query.replace(' ', '_')}_{i+1}_{random.randint(1000, 9999)}.txt"
            filepath = os.path.join(self.video_dir, filename)
            
            # In a real implementation, this would download actual video files
            # For now, we'll just create text files as placeholders
            with open(filepath, 'w') as f:
                f.write(f"STOCK VIDEO: {query}\n")
                f.write(f"Description: Stock footage of {query}, clip {i+1}\n")
                f.write(f"Duration: {random.randint(5, 15)} seconds\n")
                f.write(f"Resolution: 1080x1920 (vertical)\n")
                f.write(f"Provider: {self.provider}\n")
                
            video_paths.append(filepath)
                
        return video_paths


class ContentGenerator:
    """
    Generates content assets (script, visuals, audio) for YouTube Shorts
    based on the content plan from the Prompt Processor
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the ContentGenerator with configuration
        
        Args:
            config: Configuration dictionary with settings for content generation
        """
        self.config = config or {}
        
        # Initialize API clients
        image_api_config = self.config.get("image_api", {})
        self.image_generator = ImageGenerationAPI(
            api_key=image_api_config.get("api_key"),
            provider=image_api_config.get("provider", "stable-diffusion")
        )
        
        tts_api_config = self.config.get("tts_api", {})
        self.tts_generator = TextToSpeechAPI(
            api_key=tts_api_config.get("api_key"),
            provider=tts_api_config.get("provider", "elevenlabs")
        )
        
        stock_api_config = self.config.get("stock_assets", {})
        self.stock_asset_api = StockAssetAPI(
            api_key=stock_api_config.get("api_key"),
            provider=stock_api_config.get("provider", "pexels")
        )
        
        # Create a directory for storing generated scripts if it doesn't exist
        self.script_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/scripts"
        os.makedirs(self.script_dir, exist_ok=True)
        
    def generate_script(self, content_plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate narration script from content plan
        
        Args:
            content_plan: Content plan from the Prompt Processor
            
        Returns:
            Dictionary with script information
        """
        # Extract relevant information from the content plan
        title = content_plan.get("title", "Interesting Facts")
        key_points = content_plan.get("key_points", ["Did you know?"])
        tone = content_plan.get("tone", "engaging")
        
        # Generate an introduction based on the title and tone
        if tone == "humorous":
            intro = f"Hey there! Want to hear something funny about {title}? "
        elif tone == "formal":
            intro = f"Today, we're exploring {title}. "
        elif tone == "informative":
            intro = f"Did you know these fascinating facts about {title}? "
        elif tone == "emotional":
            intro = f"You won't believe these incredible facts about {title}. "
        elif tone == "energetic":
            intro = f"Get ready for some mind-blowing facts about {title}! "
        else:  # Default to engaging
            intro = f"Check out these amazing facts about {title}! "
            
        # Generate the main content from key points
        main_content = ""
        for i, point in enumerate(key_points):
            # Add transitions between points
            if i > 0:
                transitions = [
                    "But that's not all. ",
                    "Here's another fact. ",
                    "Did you also know that ",
                    "Amazingly, ",
                    "Incredibly, "
                ]
                main_content += random.choice(transitions)
            
            # Add the point
            main_content += f"{point}. "
            
        # Generate a conclusion/call to action
        conclusions = [
            "Like and follow for more amazing facts!",
            "Which fact surprised you the most? Let me know in the comments!",
            "Share this with someone who needs to know these facts!",
            "Follow for more mind-blowing content like this!"
        ]
        conclusion = random.choice(conclusions)
        
        # Combine all parts into a complete script
        full_script = f"{intro}{main_content}{conclusion}"
        
        # Save the script to a file
        script_filename = f"script_{random.randint(1000, 9999)}.txt"
        script_filepath = os.path.join(self.script_dir, script_filename)
        
        with open(script_filepath, 'w') as f:
            f.write(full_script)
        
        # Return script information
        return {
            "text": full_script,
            "filepath": script_filepath,
            "word_count": len(full_script.split()),
            "estimated_duration": len(full_script.split()) / 2.5  # Rough estimate: 2.5 words per second
        }
        
    def generate_visuals(self, content_plan: Dict[str, Any], theme_info: Dict[str, Any]) -> Dict[str, List[str]]:
        """
        Generate or source visual assets
        
        Args:
            content_plan: Content plan from the Prompt Processor
            theme_info: Theme information from the Prompt Processor
            
        Returns:
            Dictionary with paths to visual assets
        """
        # Extract relevant information from the content plan
        title = content_plan.get("title", "Interesting Facts")
        key_points = content_plan.get("key_points", ["Did you know?"])
        visual_keywords = content_plan.get("visuals", [])
        
        # Generate a title card
        title_prompt = f"Title card for '{title}' in {theme_info.get('style', 'dynamic')} style"
        title_card = self.image_generator.generate_image(title_prompt)
        
        # Generate images for each key point
        point_images = []
        for i, point in enumerate(key_points):
            # Use visual keywords if available, otherwise use the point text
            if i < len(visual_keywords):
                image_prompt = f"{visual_keywords[i]} in {theme_info.get('style', 'dynamic')} style"
            else:
                image_prompt = f"{point} in {theme_info.get('style', 'dynamic')} style"
                
            image = self.image_generator.generate_image(image_prompt)
            point_images.append(image)
            
        # Get some stock images related to the theme
        stock_images = []
        if visual_keywords:
            # Use the first few visual keywords to search for stock images
            for keyword in visual_keywords[:2]:
                stock_imgs = self.stock_asset_api.search_images(keyword, count=1)
                stock_images.extend(stock_imgs)
                
        # Get stock videos if needed
        stock_videos = []
        if visual_keywords:
            # Use the first visual keyword to search for stock videos
            keyword = visual_keywords[0]
            stock_vids = self.stock_asset_api.search_videos(keyword, count=1)
            stock_videos.extend(stock_vids)
            
        # Return all visual assets
        return {
            "title_card": title_card,
            "point_images": point_images,
            "stock_images": stock_images,
            "stock_videos": stock_videos
        }
        
    def generate_audio(self, script: Dict[str, Any], theme_info: Dict[str, Any]) -> Dict[str, str]:
        """
        Generate voiceover and select background music
        
        Args:
            script: Script information from generate_script
            theme_info: Theme information from the Prompt Processor
            
        Returns:
            Dictionary with paths to audio assets
        """
        # Generate voiceover from the script
        voice_id = self.config.get("tts_api", {}).get("voice_id", "default")
        voiceover = self.tts_generator.generate_speech(script["text"], voice_id)
        
        # In a real implementation, this would select appropriate background music
        # For now, we'll just create a placeholder text file
        music_dir = "/home/ubuntu/youtube_shorts_agent/generated_assets/music"
        os.makedirs(music_dir, exist_ok=True)
        
        music_mood = theme_info.get("tone", "engaging")
        music_filename = f"music_{music_mood}_{random.randint(1000, 9999)}.txt"
        music_filepath = os.path.join(music_dir, music_filename)
        
        with open(music_filepath, 'w') as f:
            f.write(f"BACKGROUND MUSIC\n")
            f.write(f"Mood: {music_mood}\n")
            f.write(f"Duration: {int(script['estimated_duration'])} seconds\n")
            f.write(f"Volume: 20% (background level)\n")
            
        return {
            "voiceover": voiceover,
            "background_music": music_filepath
        }
        
    def generate_content(self, content_plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main method that generates all necessary assets
        
        Args:
            content_plan: Complete content plan from the Prompt Processor
            
        Returns:
            Dictionary with all generated content assets
        """
        # Extract the enhanced content plan and theme info
        enhanced_plan = content_plan.get("content_plan", {})
        theme_info = content_plan.get("theme_info", {})
        
        # Generate script
        script = self.generate_script(enhanced_plan)
        
        # Generate visuals
        visuals = self.gen<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>
"""
Main Controller Module for YouTube Shorts Agent

This module integrates the prompt processor and content generator
to create a complete content generation pipeline for YouTube Shorts.
"""

import os
import json
import sys
from typing import Dict, Any, Optional

# Import the other modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from prompt_processor import PromptProcessor
from content_generator import ContentGenerator

class ContentGenerationController:
    """
    Main controller for the content generation process
    Integrates prompt processing and content generation
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the controller with configuration
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = self._load_config(config_path)
        self.prompt_processor = PromptProcessor(self.config.get("prompt_processing"))
        self.content_generator = ContentGenerator(self.config.get("content_generation"))
        
        # Create output directory for generated content
        self.output_dir = "/home/ubuntu/youtube_shorts_agent/generated_content"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """
        Load configuration from file or use defaults
        
        Args:
            config_path: Path to configuration file
            
        Returns:
            Configuration dictionary
        """
        default_config = {
            "prompt_processing": {
                "api_key": os.environ.get("OPENAI_API_KEY", "mock_key"),
                "enhancement_level": "detailed"
            },
            "content_generation": {
                "image_api": {
                    "provider": "stable-diffusion",
                    "api_key": os.environ.get("IMAGE_API_KEY", "mock_key")
                },
                "tts_api": {
                    "provider": "elevenlabs",
                    "api_key": os.environ.get("TTS_API_KEY", "mock_key"),
                    "voice_id": "default"
                },
                "stock_assets": {
                    "provider": "pexels",
                    "api_key": os.environ.get("STOCK_API_KEY", "mock_key")
                }
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    
                # Merge user config with defaults
                for section, settings in user_config.items():
                    if section in default_config:
                        default_config[section].update(settings)
                    else:
                        default_config[section] = settings
            except Exception as e:
                print(f"Error loading config from {config_path}: {e}")
                print("Using default configuration")
                
        return default_config
    
    def generate_from_prompt(self, prompt_text: str) -> Dict[str, Any]:
        """
        Generate content for a YouTube Short from a text prompt
        
        Args:
            prompt_text: The raw text prompt from the user
            
        Returns:
            Dictionary with generated content information
        """
        # Process the prompt
        print(f"Processing prompt: {prompt_text}")
        content_plan = self.prompt_processor.generate_content_plan(prompt_text)
        
        # Generate content based on the plan
        print("Generating content assets...")
        content_assets = self.content_generator.generate_content(content_plan)
        
        # Save the complete content package
        output_id = f"short_{os.path.basename(content_assets['script']['filepath']).split('_')[1].split('.')[0]}"
        output_path = os.path.join(self.output_dir, f"{output_id}_content_package.json")
        
        content_package = {
            "id": output_id,
            "prompt": prompt_text,
            "content_plan": content_plan,
            "assets": {
                "script": content_assets["script"]["filepath"],
                "title_card": content_assets["visuals"]["title_card"],
                "point_images": content_assets["visuals"]["point_images"],
                "stock_images": content_assets["visuals"]["stock_images"],
                "stock_videos": content_assets["visuals"]["stock_videos"],
                "voiceover": content_assets["audio"]["voiceover"],
                "background_music": content_assets["audio"]["background_music"]
            },
            "metadata": content_assets["metadata"]
        }
        
        with open(output_path, 'w') as f:
            json.dump(content_package, f, indent=2)
            
        print(f"Content package saved to: {output_path}")
        
        return {
            "content_package_path": output_path,
            "content_id": output_id,
            "estimated_duration": content_assets["metadata"]["estimated_duration"],
            "title": content_assets["metadata"]["title"]
        }


# Example usage
if __name__ == "__main__":
    # Check if a prompt was provided as a command-line argument
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
    else:
        prompt = "Create a short about amazing space exploration facts"
        
    controller = ContentGenerationController()
    result = controller.generate_from_prompt(prompt)
    
    print("\nGeneration Complete!")
    print(f"Content ID: {result['content_id']}")
    print(f"Title: {result['title']}")
    print(f"Estimated Duration: {result['estimated_duration']:.1f} seconds")
    print(f"Content Package: {result['content_package_path']}")

"""
Prompt Processor Module for YouTube Shorts Agent

This module handles the processing of text prompts for YouTube Shorts generation.
It analyzes and enhances user prompts to create detailed content plans.
"""

import os
import json
import re
from typing import Dict, List, Any, Optional

# In a production environment, you would use the actual OpenAI API
# For this implementation, we'll create a mock version that can be replaced later
class OpenAIClient:
    """Mock OpenAI client for prompt processing"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "mock_key")
        
    def complete(self, prompt: str, max_tokens: int = 500) -> str:
        """
        Mock completion method - in production, this would call the OpenAI API
        
        For now, it returns predefined responses based on prompt keywords
        """
        # This is a simplified mock implementation
        if "space" in prompt.lower():
            return json.dumps({
                "title": "Amazing Facts About Space Exploration",
                "theme": "educational",
                "tone": "fascinating",
                "key_points": [
                    "The International Space Station travels at 17,500 mph",
                    "A day on Venus is longer than a year on Venus",
                    "The footprints on the Moon will last for 100 million years"
                ],
                "visuals": ["space", "planets", "astronauts", "rockets"],
                "audio_mood": "inspiring"
            })
        elif "recipe" in prompt.lower() or "food" in prompt.lower():
            return json.dumps({
                "title": "Quick and Easy Recipe Hack",
                "theme": "cooking",
                "tone": "helpful",
                "key_points": [
                    "Use this simple trick to cut onions without crying",
                    "The perfect pasta water ratio every time",
                    "How to make restaurant-quality meals in 10 minutes"
                ],
                "visuals": ["cooking", "kitchen", "food", "ingredients"],
                "audio_mood": "upbeat"
            })
        else:
            # Default response for other prompts
            return json.dumps({
                "title": "Interesting Facts You Never Knew",
                "theme": "informative",
                "tone": "engaging",
                "key_points": [
                    "The human brain processes images in just 13 milliseconds",
                    "The world's oldest known living tree is over 5,000 years old",
                    "Honey never spoils - edible honey has been found in ancient Egyptian tombs"
                ],
                "visuals": ["nature", "science", "history"],
                "audio_mood": "curious"
            })


class PromptProcessor:
    """
    Processes user text prompts to extract and enhance content for YouTube Shorts
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the PromptProcessor with configuration
        
        Args:
            config: Configuration dictionary with settings for prompt processing
        """
        self.config = config or {}
        self.openai_client = OpenAIClient(self.config.get("api_key"))
        
    def parse_prompt(self, prompt_text: str) -> Dict[str, Any]:
        """
        Extract key information from the user prompt
        
        Args:
            prompt_text: The raw text prompt from the user
            
        Returns:
            Dictionary with parsed prompt information
        """
        # Basic parsing - extract topic, style hints, and keywords
        topic_match = re.search(r"about\s+([^,\.]+)", prompt_text, re.IGNORECASE)
        topic = topic_match.group(1) if topic_match else prompt_text
        
        # Extract style hints if present
        style_hints = []
        for style in ["funny", "serious", "educational", "dramatic", "exciting"]:
            if style in prompt_text.lower():
                style_hints.append(style)
                
        # Extract potential keywords
        words = prompt_text.lower().split()
        keywords = [word for word in words if len(word) > 4 and word not in 
                   ["about", "create", "make", "video", "short", "youtube"]]
        
        return {
            "raw_prompt": prompt_text,
            "topic": topic.strip(),
            "style_hints": style_hints,
            "keywords": keywords[:5]  # Limit to top 5 keywords
        }
        
    def enhance_prompt(self, parsed_prompt: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expand the prompt into a detailed content plan using AI
        
        Args:
            parsed_prompt: The parsed prompt information
            
        Returns:
            Enhanced content plan
        """
        # Construct a prompt for the AI to generate a detailed content plan
        ai_prompt = f"""
        Create a detailed content plan for a YouTube Short about {parsed_prompt['topic']}.
        Style hints: {', '.join(parsed_prompt['style_hints']) if parsed_prompt['style_hints'] else 'engaging, informative'}
        Keywords: {', '.join(parsed_prompt['keywords']) if parsed_prompt['keywords'] else parsed_prompt['topic']}
        
        Format the response as a JSON object with the following structure:
        {{
            "title": "Catchy title for the Short",
            "theme": "Main theme/category",
            "tone": "Overall tone of the content",
            "key_points": ["Point 1", "Point 2", "Point 3"],
            "visuals": ["visual element 1", "visual element 2", "visual element 3"],
            "audio_mood": "Suggested mood for background music"
        }}
        """
        
        # Get completion from OpenAI (mock in this implementation)
        response = self.openai_client.complete(ai_prompt)
        
        try:
            # Parse the JSON response
            enhanced_plan = json.loads(response)
            return enhanced_plan
        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            return {
                "title": f"Facts about {parsed_prompt['topic']}",
                "theme": "informative",
                "tone": "engaging",
                "key_points": [f"Interesting fact about {parsed_prompt['topic']}"],
                "visuals": [parsed_prompt['topic']],
                "audio_mood": "neutral"
            }
        
    def analyze_theme(self, parsed_prompt: Dict[str, Any]) -> Dict[str, Any]:
        """
        Identify theme, tone, and style from the prompt
        
        Args:
            parsed_prompt: The parsed prompt information
            
        Returns:
            Theme analysis information
        """
        # Map keywords to potential themes
        theme_keywords = {
            "educational": ["learn", "fact", "know", "education", "teach", "science"],
            "entertainment": ["fun", "funny", "laugh", "entertain", "joke", "comedy"],
            "lifestyle": ["life", "living", "home", "decor", "fashion", "style"],
            "tech": ["technology", "tech", "computer", "digital", "software", "app"],
            "travel": ["travel", "destination", "trip", "vacation", "place", "country"],
            "food": ["food", "recipe", "cook", "meal", "dish", "ingredient"],
            "fitness": ["fitness", "workout", "exercise", "health", "gym", "training"]
        }
        
        # Determine the most likely theme
        theme_scores = {theme: 0 for theme in theme_keywords}
        for keyword in parsed_prompt["keywords"]:
            for theme, theme_kws in theme_keywords.items():
                if any(kw in keyword for kw in theme_kws):
                    theme_scores[theme] += 1
                    
        # Get the theme with the highest score, default to "general"
        theme = max(theme_scores.items(), key=lambda x: x[1])[0] if any(theme_scores.values()) else "general"
        
        # Determine tone based on style hints
        tone_map = {
            "funny": "humorous",
            "serious": "formal",
            "educational": "informative",
            "dramatic": "emotional",
            "exciting": "energetic"
        }
        
        tones = [tone_map.get(hint, "neutral") for hint in parsed_prompt["style_hints"]]
        tone = tones[0] if tones else "engaging"
        
        return {
            "theme": theme,
            "tone": tone,
            "style": "dynamic" if "exciting" in parsed_prompt["style_hints"] else "standard"
        }
        
    def _extract_keywords(self, parsed_prompt: Dict[str, Any]) -> List[str]:
        """
        Extract keywords for asset search and metadata
        
        Args:
            parsed_prompt: The parsed prompt information
            
        Returns:
            List of relevant keywords
        """
        # Start with the explicitly extracted keywords
        keywords = parsed_prompt["keywords"].copy()
        
        # Add the topic if not already included
        topic_words = parsed_prompt["topic"].split()
        for word in topic_words:
            if len(word) > 3 and word.lower() not in [k.lower() for k in keywords]:
                keywords.append(word)
                
        # Add style hints as keywords if relevant
        for hint in parsed_prompt["style_hints"]:
            if hint not in keywords:
                keywords.append(hint)
                
        return keywords[:10]  # Limit to 10 keywords
        
    def generate_content_plan(self, prompt_text: str) -> Dict[str, Any]:
        """
        Main method that processes the prompt and returns a content plan
        
        Args:
            prompt_text: The raw text prompt from the user
            
        Returns:
            Complete content plan with theme information and keywords
        """
        parsed = self.parse_prompt(prompt_text)
        enhanced = self.enhance_prompt(parsed)
        theme_info = self.analyze_theme(parsed)
        
        # Combine all information into a comprehensive content plan
        content_plan = {
            "original_prompt": prompt_text,
            "content_plan": enhanced,
            "theme_info": theme_info,
            "keywords": self._extract_keywords(parsed)
        }
        
        return content_plan


# Example usage
if __name__ == "__main__":
    processor = PromptProcessor()
    
    # Test with a sample prompt
    sample_prompt = "Create a short about amazing space exploration facts"
    content_plan = processor.generate_content_plan(sample_prompt)
    
    print(json.dumps(content_plan, indent=2))

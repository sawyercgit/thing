# YouTube Shorts Autonomous Agent - Documentation

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Usage Guide](#usage-guide)
4. [System Architecture](#system-architecture)
5. [Customization Options](#customization-options)
6. [Example Configurations](#example-configurations)
7. [Troubleshooting](#troubleshooting)

## Introduction

The YouTube Shorts Autonomous Agent is a comprehensive system that automates the creation and upload of YouTube Shorts videos from simple text prompts. The agent handles the entire pipeline:

1. **Content Generation**: Transforms text prompts into scripts, visual assets, and audio
2. **Video Editing**: Creates properly formatted videos with captions, transitions, and effects
3. **Upload Automation**: Generates metadata and uploads videos to YouTube

This documentation provides detailed instructions for installing, using, and customizing the agent.

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- FFmpeg (for video processing)
- YouTube API credentials (for uploading)

### Step 1: Clone the Repository

```bash
git clone https://github.com/yourusername/youtube-shorts-agent.git
cd youtube-shorts-agent
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 3: Set Up YouTube API Credentials

1. Go to the [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable the YouTube Data API v3
4. Create OAuth 2.0 credentials
5. Download the credentials JSON file
6. Set the environment variables:

```bash
export YOUTUBE_CREDENTIALS=/path/to/credentials.json
export YOUTUBE_API_KEY=your_api_key
export YOUTUBE_CLIENT_ID=your_client_id
export YOUTUBE_CLIENT_SECRET=your_client_secret
```

Alternatively, you can specify these in a configuration file (see [Customization Options](#customization-options)).

### Step 4: Install External Tools (Optional)

For enhanced functionality, you may want to install:

- **ImageMagick**: For advanced image processing
- **Sox**: For audio processing
- **FFMPEG**: For video processing (if not already installed)

```bash
# Ubuntu/Debian
sudo apt-get install imagemagick sox ffmpeg

# macOS
brew install imagemagick sox ffmpeg
```

## Usage Guide

### Basic Usage

The simplest way to use the agent is through the provided test script:

```bash
python test_agent.py --prompt "Create a short about amazing space exploration facts"
```

This will:
1. Generate content based on the prompt
2. Create a video with proper formatting for YouTube Shorts
3. Save the result without uploading

### Uploading to YouTube

To upload the generated video to YouTube:

```bash
python test_agent.py --prompt "Create a short about amazing space exploration facts" --upload
```

### Using a Custom Configuration

You can provide a custom configuration file:

```bash
python test_agent.py --prompt "Your prompt here" --config /path/to/config.json --upload
```

### Using the Agent in Your Code

You can also use the agent programmatically:

```python
from youtube_shorts_agent.test_agent import YouTubeShortsAgent

# Initialize the agent
agent = YouTubeShortsAgent()

# Create a Short from a prompt
result = agent.create_short_from_prompt(
    "Create a short about amazing space exploration facts",
    upload=True
)

# Save the result
agent.save_result(result)
```

### Command-Line Arguments

The test script supports the following arguments:

- `--prompt`: Text prompt for the Short (required)
- `--config`: Path to configuration file (optional)
- `--upload`: Flag to upload the video to YouTube (optional)

## System Architecture

The YouTube Shorts Autonomous Agent consists of three main modules:

### 1. Content Generation Module

This module processes text prompts into detailed content plans and generates script, visual, and audio assets.

Components:
- **Prompt Processor**: Enhances the original prompt into a detailed content plan
- **Content Generator**: Creates scripts, visual assets, and audio based on the content plan
- **Controller**: Manages the content generation pipeline

### 2. Video Editing Module

This module takes the generated assets and creates a properly formatted video for YouTube Shorts.

Components:
- **Asset Compositor**: Composes visual and audio assets into a sequence plan
- **Format Converter**: Ensures the video meets YouTube Shorts specifications
- **Caption Generator**: Adds captions to the video
- **Effect Applier**: Adds transitions and visual effects
- **Controller**: Manages the video editing pipeline

### 3. Upload Automation Module

This module handles the upload of videos to YouTube with appropriate metadata.

Components:
- **Metadata Generator**: Creates titles, descriptions, tags, and hashtags
- **YouTube API Client**: Handles authentication and uploads
- **Controller**: Manages the upload pipeline

## Customization Options

The agent can be customized through a configuration file. Here's an example structure:

```json
{
  "content_generation": {
    "prompt_processing": {
      "api_key": "your_openai_api_key",
      "enhancement_level": "detailed"
    },
    "content_generation": {
      "image_api": {
        "provider": "stable-diffusion",
        "api_key": "your_image_api_key"
      },
      "tts_api": {
        "provider": "elevenlabs",
        "api_key": "your_tts_api_key",
        "voice_id": "default"
      },
      "stock_assets": {
        "provider": "pexels",
        "api_key": "your_stock_api_key"
      }
    }
  },
  "video_editing": {
    "format_conversion": {
      "format_settings": {
        "aspect_ratio": "9:16",
        "resolution": "1080x1920",
        "fps": 30,
        "bitrate": "8M",
        "codec": "h264",
        "format": "mp4"
      }
    },
    "caption_generation": {
      "caption_style": {
        "font": "Arial",
        "size": 36,
        "color": "#FFFFFF",
        "background": "#000000AA",
        "position": "bottom",
        "margin": 50,
        "max_lines": 2,
        "max_chars_per_line": 32,
        "animation": "fade"
      }
    },
    "effect_application": {
      "effect_settings": {
        "transitions": ["fade", "slide", "zoom"],
        "visual_effects": ["zoom", "pan", "brightness", "contrast"],
        "text_effects": ["fade", "slide", "pop"],
        "intensity": "medium"
      }
    }
  },
  "upload_automation": {
    "metadata_generation": {
      "metadata_settings": {
        "title_max_length": 100,
        "description_max_length": 5000,
        "tags_max_count": 15,
        "hashtags_count": 3,
        "include_call_to_action": true,
        "include_source_attribution": true
      }
    },
    "youtube_api": {
      "api_settings": {
        "credentials_file": "/path/to/credentials.json",
        "token_file": "/path/to/token.json",
        "api_key": "your_youtube_api_key",
        "client_id": "your_client_id",
        "client_secret": "your_client_secret",
        "upload_retry_count": 3,
        "upload_chunk_size": 5242880
      }
    }
  }
}
```

### Content Generation Options

- **enhancement_level**: Controls how much the prompt is enhanced (basic, standard, detailed)
- **image_api.provider**: Provider for image generation (stable-diffusion, dall-e, etc.)
- **tts_api.provider**: Provider for text-to-speech (elevenlabs, google, etc.)
- **tts_api.voice_id**: Voice ID to use for narration
- **stock_assets.provider**: Provider for stock assets (pexels, unsplash, etc.)

### Video Editing Options

- **format_settings.aspect_ratio**: Aspect ratio for the video (9:16 for Shorts)
- **format_settings.resolution**: Resolution for the video (1080x1920 recommended)
- **format_settings.fps**: Frames per second
- **caption_style**: Customization options for captions
- **effect_settings.intensity**: Intensity of effects (low, medium, high)
- **effect_settings.transitions**: List of transitions to use
- **effect_settings.visual_effects**: List of visual effects to use
- **effect_settings.text_effects**: List of text effects to use

### Upload Automation Options

- **metadata_settings.title_max_length**: Maximum length for titles
- **metadata_settings.description_max_length**: Maximum length for descriptions
- **metadata_settings.tags_max_count**: Maximum number of tags
- **metadata_settings.hashtags_count**: Number of hashtags to include
- **metadata_settings.include_call_to_action**: Whether to include calls to action
- **metadata_settings.include_source_attribution**: Whether to include attribution
- **api_settings**: YouTube API settings

## Example Configurations

### Educational Content Configuration

```json
{
  "content_generation": {
    "prompt_processing": {
      "enhancement_level": "detailed"
    },
    "content_generation": {
      "tts_api": {
        "voice_id": "professional"
      }
    }
  },
  "video_editing": {
    "caption_generation": {
      "caption_style": {
        "font": "Georgia",
        "size": 40,
        "color": "#FFFFFF",
        "background": "#000000CC",
        "position": "bottom",
        "margin": 60
      }
    },
    "effect_application": {
      "effect_settings": {
        "intensity": "low",
        "transitions": ["fade", "slide"],
        "visual_effects": ["zoom", "brightness"]
      }
    }
  },
  "upload_automation": {
    "metadata_generation": {
      "metadata_settings": {
        "hashtags_count": 5,
        "include_source_attribution": true
      }
    }
  }
}
```

### Entertainment Content Configuration

```json
{
  "content_generation": {
    "prompt_processing": {
      "enhancement_level": "standard"
    },
    "content_generation": {
      "tts_api": {
        "voice_id": "energetic"
      }
    }
  },
  "video_editing": {
    "caption_generation": {
      "caption_style": {
        "font": "Impact",
        "size": 44,
        "color": "#FFFF00",
        "background": "#000000AA",
        "position": "center",
        "margin": 40
      }
    },
    "effect_application": {
      "effect_settings": {
        "intensity": "high",
        "transitions": ["zoom", "slide", "fade"],
        "visual_effects": ["zoom", "pan", "brightness", "contrast"],
        "text_effects": ["pop", "slide", "fade"]
      }
    }
  },
  "upload_automation": {
    "metadata_generation": {
      "metadata_settings": {
        "hashtags_count": 7,
        "include_call_to_action": true
      }
    }
  }
}
```

## Troubleshooting

### Common Issues

#### Content Generation Issues

- **Error**: "API key not found"
  - **Solution**: Ensure you've set the appropriate API keys in your environment or configuration file

- **Error**: "Failed to generate content plan"
  - **Solution**: Check that your prompt is clear and specific, or try a different prompt

#### Video Editing Issues

- **Error**: "FFmpeg not found"
  - **Solution**: Install FFmpeg and ensure it's in your PATH

- **Error**: "Failed to compose sequence"
  - **Solution**: Check that the content package has all required assets

#### Upload Issues

- **Error**: "Authentication failed"
  - **Solution**: Verify your YouTube API credentials and ensure they have the correct permissions

- **Error**: "Upload failed"
  - **Solution**: Check your internet connection and YouTube API quota limits

### Getting Help

If you encounter issues not covered here:

1. Check the logs in the `logs` directory
2. Review the error messages in the terminal output
3. Check the GitHub repository for known issues
4. Submit a new issue with detailed information about the problem

---

This documentation is a comprehensive guide to the YouTube Shorts Autonomous Agent. For further assistance or to report issues, please contact the repository maintainers.

// JavaScript for YouTube Shorts Agent Web Interface

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Form validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    }

    // Character counter for prompt textarea
    const promptTextarea = document.getElementById('prompt');
    const charCounter = document.getElementById('char-counter');
    
    if (promptTextarea && charCounter) {
        promptTextarea.addEventListener('input', function() {
            const remaining = 500 - this.value.length;
            charCounter.textContent = remaining + ' characters remaining';
            
            if (remaining < 0) {
                charCounter.classList.add('text-danger');
                charCounter.classList.remove('text-muted');
            } else {
                charCounter.classList.remove('text-danger');
                charCounter.classList.add('text-muted');
            }
        });
        
        // Trigger on load
        promptTextarea.dispatchEvent(new Event('input'));
    }
});

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from datetime import datetime
import os
import json
import uuid
import threading
import time
import sys

# Add the code directories to the Python path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../code/content_generation"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../code/video_editing"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../code/upload_automation"))

# Import the controllers from each module
try:
    from content_generation.controller import ContentGenerationController
    from video_editing.controller import VideoEditingController
    from upload_automation.controller import UploadAutomationController
    MODULES_IMPORTED = True
except ImportError as e:
    print(f"Warning: Could not import agent modules: {e}")
    MODULES_IMPORTED = False

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Create necessary directories
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static/uploads")
RESULTS_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static/results")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# Store job status in memory (would use a database in production)
jobs = {}

# Register custom filters
@app.template_filter('datetime')
def format_datetime(timestamp):
    """Format a timestamp as a readable date and time"""
    return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

class YouTubeShortsAgentWeb:
    """Web wrapper for the YouTube Shorts Agent"""
    
    def __init__(self, config_path=None):
        """Initialize the agent with configuration"""
        self.config = self._load_config(config_path)
        
        # Initialize controllers if modules were imported
        if MODULES_IMPORTED:
            self.content_generator = ContentGenerationController(self.config.get("content_generation"))
            self.video_editor = VideoEditingController(self.config.get("video_editing"))
            self.upload_automator = UploadAutomationController(self.config.get("upload_automation"))
            print("YouTube Shorts Agent initialized for web interface")
        else:
            print("Running in demo mode: Agent modules not available")
    
    def _load_config(self, config_path):
        """Load configuration from file or use defaults"""
        default_config = {
            "content_generation": {},
            "video_editing": {},
            "upload_automation": {}
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    
                # Merge user config with defaults
                for section, settings in user_config.items():
                    if section in default_config:
                        default_config[section] = settings
                    else:
                        default_config[section] = settings
            except Exception as e:
                print(f"Error loading config from {config_path}: {e}")
                print("Using default configuration")
                
        return default_config
    
    def process_job(self, job_id, prompt, upload=False):
        """Process a job in a background thread"""
        try:
            # Update job status
            jobs[job_id]["status"] = "processing"
            jobs[job_id]["progress"] = 10
            jobs[job_id]["message"] = "Starting content generation..."
            
            # Step 1: Generate content from prompt (or simulate in demo mode)
            if MODULES_IMPORTED:
                # Actual implementation
                content_result = self.content_generator.generate_from_prompt(prompt)
                content_package_path = content_result["content_package_path"]
                content_id = content_result["content_id"]
                title = content_result["title"]
            else:
                # Demo implementation
                time.sleep(3)  # Simulate processing time
                content_id = f"short_{uuid.uuid4().hex[:8]}"
                title = f"YouTube Short about {prompt.split()[0]}"
                content_package_path = f"/path/to/{content_id}_content_package.json"
            
            # Update job status
            jobs[job_id]["progress"] = 40
            jobs[job_id]["message"] = "Content generated. Starting video creation..."
            
            # Step 2: Create video from content package (or simulate in demo mode)
            if MODULES_IMPORTED:
                # Extract script path from content package
                with open(content_package_path, 'r') as f:
                    content_package = json.load(f)
                    
                script_path = content_package.get("assets", {}).get("script", "")
                
                # Actual implementation
                video_result = self.video_editor.create_video(content_package_path, script_path)
                video_path = video_result["video_path"]
                sequence_id = video_result["sequence_id"]
            else:
                # Demo implementation
                time.sleep(5)  # Simulate processing time
                sequence_id = f"seq_{uuid.uuid4().hex[:8]}"
                video_path = f"/path/to/{sequence_id}_final_video.mp4"
            
            # Update job status
            jobs[job_id]["progress"] = 70
            jobs[job_id]["message"] = "Video created."
            
            # Step 3: Upload video if requested (or simulate in demo mode)
            if upload:
                jobs[job_id]["message"] = "Starting upload to YouTube..."
                
                if MODULES_IMPORTED:
                    # Actual implementation
                    upload_result = self.upload_automator.upload_video(video_path, content_package_path)
                    video_id = upload_result.get("video_id", "")
                    video_url = upload_result.get("video_url", "")
                else:
                    # Demo implementation
                    time.sleep(4)  # Simulate processing time
                    video_id = f"YT{uuid.uuid4().hex[:10]}"
                    video_url = f"https://www.youtube.com/shorts/{video_id}"
                
                # Update job status
                jobs[job_id]["progress"] = 100
                jobs[job_id]["message"] = "Upload complete!"
                jobs[job_id]["result"] = {
                    "content_id": content_id,
                    "sequence_id": sequence_id,
                    "video_id": video_id,
                    "video_url": video_url,
                    "title": title
                }
            else:
                # Update job status without upload
                jobs[job_id]["progress"] = 100
                jobs[job_id]["message"] = "Processing complete!"
                jobs[job_id]["result"] = {
                    "content_id": content_id,
                    "sequence_id": sequence_id,
                    "title": title
                }
            
            # Mark job as completed
            jobs[job_id]["status"] = "completed"
            
        except Exception as e:
            # Handle errors
            jobs[job_id]["status"] = "error"
            jobs[job_id]["message"] = f"Error: {str(e)}"
            print(f"Error processing job {job_id}: {e}")

# Initialize the agent
agent = YouTubeShortsAgentWeb()

@app.route('/')
def index():
    """Render the home page"""
    return render_template('index.html')

@app.route('/create', methods=['POST'])
def create_short():
    """Handle form submission to create a new Short"""
    prompt = request.form.get('prompt', '')
    upload = request.form.get('upload', 'false') == 'true'
    
    if not prompt:
        flash('Please enter a prompt', 'error')
        return redirect(url_for('index'))
    
    # Create a new job
    job_id = str(uuid.uuid4())
    jobs[job_id] = {
        "id": job_id,
        "prompt": prompt,
        "upload": upload,
        "status": "queued",
        "progress": 0,
        "message": "Job queued",
        "created_at": time.time(),
        "result": None
    }
    
    # Start processing in a background thread
    thread = threading.Thread(target=agent.process_job, args=(job_id, prompt, upload))
    thread.daemon = True
    thread.start()
    
    # Redirect to the job status page
    return redirect(url_for('job_status', job_id=job_id))

@app.route('/job/<job_id>')
def job_status(job_id):
    """Show the status of a job"""
    if job_id not in jobs:
        flash('Job not found', 'error')
        return redirect(url_for('index'))
    
    return render_template('job_status.html', job=jobs[job_id])

@app.route('/api/job/<job_id>')
def api_job_status(job_id):
    """API endpoint to get job status"""
    if job_id not in jobs:
        return jsonify({"error": "Job not found"}), 404
    
    return jsonify(jobs[job_id])

@app.route('/history')
def history():
    """Show job history"""
    # Sort jobs by creation time (newest first)
    sorted_jobs = sorted(jobs.values(), key=lambda x: x.get('created_at', 0), reverse=True)
    return render_template('history.html', jobs=sorted_jobs)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

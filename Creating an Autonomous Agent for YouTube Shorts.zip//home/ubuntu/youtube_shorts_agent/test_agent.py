#!/usr/bin/env python3
"""
YouTube Shorts Autonomous Agent - Test Script

This script demonstrates the full pipeline of the YouTube Shorts autonomous agent,
from text prompt to final upload.
"""

import os
import sys
import json
import argparse
from datetime import datetime

# Add the code directories to the Python path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "code/content_generation"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "code/video_editing"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "code/upload_automation"))

# Import the controllers from each module
from content_generation.controller import ContentGenerationController
from video_editing.controller import VideoEditingController
from upload_automation.controller import UploadAutomationController

class YouTubeShortsAgent:
    """
    Main class for the YouTube Shorts Autonomous Agent
    Integrates all three modules: content generation, video editing, and upload automation
    """
    
    def __init__(self, config_path=None):
        """
        Initialize the YouTube Shorts Agent
        
        Args:
            config_path: Path to configuration file (optional)
        """
        self.config = self._load_config(config_path)
        
        # Create necessary directories
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.output_dir = os.path.join(self.base_dir, "output")
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize the controllers for each module
        self.content_generator = ContentGenerationController(self.config.get("content_generation"))
        self.video_editor = VideoEditingController(self.config.get("video_editing"))
        self.upload_automator = UploadAutomationController(self.config.get("upload_automation"))
        
        print("YouTube Shorts Autonomous Agent initialized!")
        
    def _load_config(self, config_path):
        """
        Load configuration from file or use defaults
        
        Args:
            config_path: Path to configuration file
            
        Returns:
            Configuration dictionary
        """
        default_config = {
            "content_generation": {},
            "video_editing": {},
            "upload_automation": {}
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    
                # Merge user config with defaults
                for section, settings in user_config.items():
                    if section in default_config:
                        default_config[section] = settings
                    else:
                        default_config[section] = settings
            except Exception as e:
                print(f"Error loading config from {config_path}: {e}")
                print("Using default configuration")
                
        return default_config
        
    def create_short_from_prompt(self, prompt, upload=False):
        """
        Create a YouTube Short from a text prompt
        
        Args:
            prompt: Text prompt describing the desired content
            upload: Whether to upload the video to YouTube
            
        Returns:
            Dictionary with information about the created Short
        """
        try:
            # Step 1: Generate content from prompt
            print("\n=== STEP 1: CONTENT GENERATION ===")
            print(f"Generating content from prompt: '{prompt}'")
            content_result = self.content_generator.generate_from_prompt(prompt)
            
            if not content_result or "content_package_path" not in content_result:
                raise ValueError("Content generation failed")
                
            content_package_path = content_result["content_package_path"]
            content_id = content_result["content_id"]
            
            print(f"Content generation successful!")
            print(f"Content ID: {content_id}")
            print(f"Title: {content_result['title']}")
            print(f"Estimated Duration: {content_result['estimated_duration']:.1f} seconds")
            print(f"Content Package: {content_package_path}")
            
            # Step 2: Create video from content package
            print("\n=== STEP 2: VIDEO EDITING ===")
            print(f"Creating video from content package: {content_package_path}")
            
            # Extract script path from content package
            with open(content_package_path, 'r') as f:
                content_package = json.load(f)
                
            script_path = content_package.get("assets", {}).get("script", "")
            if not script_path:
                raise ValueError("Script path not found in content package")
                
            video_result = self.video_editor.create_video(content_package_path, script_path)
            
            if not video_result or "video_path" not in video_result:
                raise ValueError("Video creation failed")
                
            video_path = video_result["video_path"]
            sequence_id = video_result["sequence_id"]
            
            print(f"Video creation successful!")
            print(f"Sequence ID: {sequence_id}")
            print(f"Title: {video_result['title']}")
            print(f"Duration: {video_result['duration']:.1f} seconds")
            print(f"Resolution: {video_result['resolution']}")
            print(f"Video Path: {video_path}")
            
            # Step 3: Upload video (if requested)
            if upload:
                print("\n=== STEP 3: UPLOAD AUTOMATION ===")
                print(f"Uploading video to YouTube: {video_path}")
                
                upload_result = self.upload_automator.upload_video(video_path, content_package_path, script_path)
                
                if not upload_result or "status" not in upload_result or upload_result["status"] == "error":
                    raise ValueError(f"Video upload failed: {upload_result.get('error', 'Unknown error')}")
                    
                print(f"Upload successful!")
                print(f"Video ID: {upload_result['video_id']}")
                print(f"Video URL: {upload_result['video_url']}")
                print(f"Title: {upload_result['title']}")
                print(f"Status: {upload_result['status']}")
                
                # Return the complete result
                return {
                    "content_id": content_id,
                    "sequence_id": sequence_id,
                    "video_id": upload_result["video_id"],
                    "video_url": upload_result["video_url"],
                    "title": upload_result["title"],
                    "duration": video_result["duration"],
                    "content_package_path": content_package_path,
                    "video_path": video_path,
                    "upload_status": upload_result["status"]
                }
            else:
                # Return result without upload information
                return {
                    "content_id": content_id,
                    "sequence_id": sequence_id,
                    "title": video_result["title"],
                    "duration": video_result["duration"],
                    "content_package_path": content_package_path,
                    "video_path": video_path
                }
        except Exception as e:
            print(f"Error creating Short from prompt: {e}")
            return {
                "error": str(e),
                "prompt": prompt
            }
            
    def save_result(self, result):
        """
        Save the result of the Short creation process
        
        Args:
            result: Dictionary with information about the created Short
            
        Returns:
            Path to the saved result file
        """
        # Generate a unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"short_{timestamp}.json"
        filepath = os.path.join(self.output_dir, filename)
        
        # Add timestamp to result
        result["timestamp"] = datetime.now().isoformat()
        
        # Save result to file
        with open(filepath, 'w') as f:
            json.dump(result, f, indent=2)
            
        print(f"\nResult saved to: {filepath}")
        return filepath


def main():
    """Main function to run the test script"""
    parser = argparse.ArgumentParser(description="YouTube Shorts Autonomous Agent Test Script")
    parser.add_argument("--prompt", type=str, default="Create a short about amazing space exploration facts",
                        help="Text prompt for the Short")
    parser.add_argument("--config", type=str, default=None,
                        help="Path to configuration file")
    parser.add_argument("--upload", action="store_true",
                        help="Upload the video to YouTube")
    
    args = parser.parse_args()
    
    print("=== YOUTUBE SHORTS AUTONOMOUS AGENT TEST ===")
    print(f"Prompt: {args.prompt}")
    print(f"Config: {args.config if args.config else 'Default'}")
    print(f"Upload: {'Yes' if args.upload else 'No'}")
    print("=" * 45)
    
    # Initialize the agent
    agent = YouTubeShortsAgent(args.config)
    
    # Create a Short from the prompt
    result = agent.create_short_from_prompt(args.prompt, args.upload)
    
    # Save the result
    agent.save_result(result)
    
    print("\n=== TEST COMPLETE ===")
    if "error" not in result:
        print("All steps completed successfully!")
    else:
        print(f"Test completed with errors: {result['error']}")


if __name__ == "__main__":
    main()
